-- MariaDB dump 10.18  Distrib 10.5.8-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: mobile_sps
-- ------------------------------------------------------
-- Server version	10.5.8-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `coremenu`
--

DROP TABLE IF EXISTS `coremenu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coremenu` (
  `id_coremenu` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `coremenu_name` varchar(100) NOT NULL,
  `coremenu_iconpath` varchar(100) DEFAULT NULL,
  `coremenu_status` enum('0','1','2','3','-9') NOT NULL DEFAULT '1',
  `coremenu_parent` smallint(5) unsigned DEFAULT 0,
  `root_path` varchar(30) NOT NULL,
  `coremenu_desc` varchar(150) DEFAULT NULL,
  `coremenu_colorbanner` varchar(100) DEFAULT NULL,
  `coremenu_colortext` varchar(20) DEFAULT NULL,
  `coremenu_order` smallint(5) NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_coremenu`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coremenu`
--

LOCK TABLES `coremenu` WRITE;
/*!40000 ALTER TABLE `coremenu` DISABLE KEYS */;
INSERT INTO `coremenu` VALUES (1,'Message','/resource/menu_icon/message.png','1',0,'sms','ระบบควบคุมและส่งข้อความแจ้งเตือน','( 174.6deg, rgb(214, 176, 255) 11.8%, rgb(152, 98, 211) 89.9%)','#FFFFFF',1,'2019-11-04 12:59:32','2020-07-02 17:41:09'),(2,'Mobile Admin','/resource/menu_icon/mobile_admin.png','1',0,'mobileadmin','ระบบควบคุมและจัดการแอปพลิเคชันทั้ง Mobile และ Web','( 109.4deg, rgba(69,127,202,1) 3.6%, rgba(23,77,145,1) 94.9% )','#FFFFFF',2,'2019-11-04 13:03:02','2020-06-24 14:36:04'),(3,'Line','/resource/menu_icon/line.png','3',0,'line','ระบบจัดการ Line Bot และ Line Notify','(90deg,#56ab2f,#a8e063)',NULL,3,'2019-11-04 13:03:02','2019-11-21 22:37:15'),(4,'Log','/resource/menu_icon/log.png','1',0,'log','ระบบเก็บประวัติการทำรายการบนแอปพลิเคชัน','( 109.6deg,  rgba(113,14,51,0.83) 15.2%, rgba(217,43,23,0.95) 96.8% )','#FFFFFF',4,'2019-11-04 13:03:11','2020-06-24 14:35:55'),(5,'Admin Control','/resource/menu_icon/admin_control.png','1',0,'admincontrol','ระบบควบคุมและจัดการสิทธิ์ภายใน','(90deg, rgba(15,156,168,1), rgba(0,95,104,1) )','#FFFFFF',5,'2019-11-04 13:03:36','2020-01-16 09:11:28'),(6,'Web Coop ','/resource/menu_icon/web_coop.png','-9',0,'webcoop','ระบบจัดการเว็ปไซต์สหกรณ์','(90deg, rgb(255, 79, 25), rgb(93, 43, 28))','#FFFFFF',6,'2020-09-01 13:58:14','2020-12-22 16:55:08'),(10,'Document','/resource/menu_icon/document.png','1',0,'document','ระบบควบคุมแฟ้มและเอกสาร','(90deg, rgb(227 203 55), rgb(225 149 56))','#FFFFFF',4,'2021-02-25 10:53:36','2021-02-25 10:53:36');
/*!40000 ALTER TABLE `coremenu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `corepermissionmenu`
--

DROP TABLE IF EXISTS `corepermissionmenu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `corepermissionmenu` (
  `id_permission_menu` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id_coremenu` smallint(5) unsigned NOT NULL,
  `username` varchar(20) NOT NULL,
  `is_use` enum('0','1','-9') NOT NULL DEFAULT '1',
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_permission_menu`),
  KEY `FK_CORE_MENU` (`id_coremenu`),
  KEY `FK_CONTROL_USER` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corepermissionmenu`
--

LOCK TABLES `corepermissionmenu` WRITE;
/*!40000 ALTER TABLE `corepermissionmenu` DISABLE KEYS */;
INSERT INTO `corepermissionmenu` VALUES (1,1,'spsadmin','1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(2,2,'spsadmin','1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(3,4,'spsadmin','1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(4,5,'spsadmin','1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(5,10,'spsadmin','1','2021-12-15 10:44:59','2021-12-15 10:44:59');
/*!40000 ALTER TABLE `corepermissionmenu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `corepermissionsubmenu`
--

DROP TABLE IF EXISTS `corepermissionsubmenu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `corepermissionsubmenu` (
  `id_permission_submenu` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `id_submenu` mediumint(8) unsigned NOT NULL,
  `id_permission_menu` mediumint(8) unsigned NOT NULL,
  `is_use` enum('0','1','-9') NOT NULL DEFAULT '1',
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_permission_submenu`),
  KEY `FK_PERMISSION_SUBMENU` (`id_submenu`),
  KEY `FK_PERMISSION_USER` (`id_permission_menu`),
  CONSTRAINT `FK_PERMISSION_SUBMENU` FOREIGN KEY (`id_submenu`) REFERENCES `coresubmenu` (`id_submenu`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_PERMISSION_USER` FOREIGN KEY (`id_permission_menu`) REFERENCES `corepermissionmenu` (`id_permission_menu`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corepermissionsubmenu`
--

LOCK TABLES `corepermissionsubmenu` WRITE;
/*!40000 ALTER TABLE `corepermissionsubmenu` DISABLE KEYS */;
INSERT INTO `corepermissionsubmenu` VALUES (1,12,1,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(2,13,1,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(3,14,1,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(4,15,1,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(5,46,1,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(6,80,1,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(7,91,1,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(8,98,1,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(9,100,1,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(10,113,1,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(11,120,1,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(12,156,1,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(13,159,1,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(14,160,1,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(15,161,1,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(16,178,1,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(17,64,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(18,65,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(19,67,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(20,69,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(21,71,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(22,76,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(23,77,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(24,78,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(25,79,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(26,88,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(27,94,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(28,101,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(29,110,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(30,119,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(31,137,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(32,145,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(33,146,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(34,150,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(35,191,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(36,192,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(37,193,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(38,194,2,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(39,122,3,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(40,123,3,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(41,125,3,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(42,126,3,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(43,127,3,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(44,128,3,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(45,129,3,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(46,132,3,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(47,133,3,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(48,134,3,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(49,135,3,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(50,136,3,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(51,139,3,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(52,140,3,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(53,141,3,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(54,148,3,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(55,149,3,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(56,157,3,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(57,190,3,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(58,97,4,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(59,107,4,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(60,112,4,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(61,186,5,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(62,187,5,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(63,188,5,'1','2021-12-15 10:44:59','2021-12-15 10:44:59'),(64,189,5,'1','2021-12-15 10:44:59','2021-12-15 10:44:59');
/*!40000 ALTER TABLE `corepermissionsubmenu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coresectionsystem`
--

DROP TABLE IF EXISTS `coresectionsystem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coresectionsystem` (
  `id_section_system` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `section_system` varchar(10) NOT NULL,
  `system_assign` varchar(50) NOT NULL,
  `is_use` enum('0','1') NOT NULL DEFAULT '1',
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_section_system`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coresectionsystem`
--

LOCK TABLES `coresectionsystem` WRITE;
/*!40000 ALTER TABLE `coresectionsystem` DISABLE KEYS */;
INSERT INTO `coresectionsystem` VALUES (1,'root','Root','1','2019-10-31 12:46:43','2019-11-04 12:17:23'),(2,'loan','ระบบเงินกู้','1','2019-11-04 12:19:43','2019-11-04 12:19:43'),(3,'deposit','ระบบเงินฝาก','1','2019-11-04 12:19:43','2019-11-04 12:19:43'),(4,'share','ระบบหุ้น','1','2019-11-04 12:37:26','2019-11-04 12:41:53'),(5,'assist','ระบบสวัสดิการ','1','2019-11-04 12:37:26','2019-11-04 12:37:26'),(6,'keeping','ระบบประมวล','1','2019-11-04 12:38:38','2019-11-04 12:38:38'),(7,'divavg','ระบบปันผล - เฉลี่ยคืน','1','2019-11-04 12:38:38','2019-11-04 12:38:38'),(8,'insure','ระบบประกัน','1','2019-11-04 12:39:55','2019-11-04 12:39:55'),(9,'hr','ระบบบริหารบุคคล','1','2019-11-04 12:39:55','2019-11-04 12:39:55'),(10,'mb','ระบบสมาชิก','1','2019-11-04 12:42:05','2019-11-04 12:42:05'),(11,'root_test','Root on Test','1','2019-11-04 12:53:49','2019-11-04 12:53:49');
/*!40000 ALTER TABLE `coresectionsystem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coresubmenu`
--

DROP TABLE IF EXISTS `coresubmenu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coresubmenu` (
  `id_submenu` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(100) NOT NULL,
  `menu_status` enum('0','1','2','3','-9') NOT NULL DEFAULT '1',
  `page_name` varchar(30) NOT NULL,
  `menu_order` smallint(5) NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `create_by` varchar(20) NOT NULL,
  `id_menuparent` smallint(5) unsigned NOT NULL DEFAULT 0,
  `id_coremenu` smallint(5) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_submenu`),
  KEY `FK_PARENT_MENU` (`id_coremenu`)
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coresubmenu`
--

LOCK TABLES `coresubmenu` WRITE;
/*!40000 ALTER TABLE `coresubmenu` DISABLE KEYS */;
INSERT INTO `coresubmenu` VALUES (8,'งานหลัก','1','mainwork',1,'2019-11-07 15:12:53','2019-11-07 15:23:26','demo',0,1),(9,'ส่งข้อความ','1','manual',2,'2019-11-07 15:13:20','2020-01-16 09:55:39','demo',0,1),(10,'รายงาน','1','report',5,'2019-11-07 15:13:20','2020-01-15 13:39:59','demo',0,1),(11,'ตั้งค่า','1','settings',3,'2019-11-07 15:14:25','2019-11-07 15:23:31','demo',0,1),(12,'จัดการเทมเพลต','1','managetemplate',1,'2019-11-07 15:20:07','2020-02-20 12:33:34','demo',11,1),(13,'จัดการหัวข้องาน','1','managetopic',14,'2019-11-07 15:22:48','2020-02-20 12:33:23','demo',11,1),(14,'จัดการกลุ่ม','1','managegroup',13,'2019-11-07 15:24:32','2020-02-20 12:33:23','demo',11,1),(15,'ส่งข้อความรายบุคคล','1','sendmessageperson',12,'2019-11-07 15:41:31','2020-02-20 12:33:23','demo',9,1),(46,'จัดการค่าคงที่ระบบ','1','manageconstant',15,'2019-11-30 17:55:53','2020-02-20 12:33:23','dev@mode',11,1),(63,'จัดการผู้ใช้','1','manageuser',1,'2019-11-19 09:56:42','2020-04-02 16:44:58','dev@mode',0,2),(64,'ผู้ใช้ที่กำลังออนไลน์','1','useronline',1,'2019-11-19 10:09:31','2020-07-03 10:06:55','dev@mode',63,2),(65,'ผู้ที่เข้าสู่ระบบ','1','userlogin',2,'2019-11-19 10:11:35','2020-04-02 16:46:00','dev@mode',63,2),(66,'ข่าวสารและกิจกรรม','1','activitiesandnews',3,'2019-11-20 09:36:18','2020-07-03 10:13:32','dev@mode',0,2),(67,'จัดการข่าวสาร','1','managenews',32,'2019-11-20 09:43:52','2020-01-22 10:33:54','dev@mode',66,2),(68,'จัดการกิจกรรม','-9','manageactivities',30,'2019-11-20 09:48:32','2020-01-26 17:03:45','dev@mode',66,2),(69,'แจ้งประกาศ','1','announce',33,'2019-11-21 16:51:50','2020-02-06 13:46:48','dev@mode',66,2),(71,'ปฏิทินสหกรณ์','1','calendarcoop',25,'2019-11-21 16:57:02','2020-02-20 12:33:23','dev@mode',66,2),(72,'จัดการแอปพลิเคชั่น','1','manageapplication',2,'2019-11-21 17:11:00','2020-04-02 16:44:58','dev@mode',0,2),(73,'จัดการถาดสี','-9','managepalette',4,'2019-11-21 17:13:05','2020-07-03 10:18:13','dev@mode',72,2),(74,'จัดการคลังรูปภาพ','-9','managegallery',25,'2019-11-21 17:14:31','2020-02-18 15:41:00','dev@mode',72,2),(76,'จัดการบัญชีผู้ใช้','1','manageuseraccount',4,'2019-11-25 10:00:36','2020-04-02 16:46:00','dev@mode',63,2),(77,'ค่าคงที่ระบบ','1','constantsystem',28,'2019-11-22 09:00:10','2020-02-20 12:33:23','dev@mode',106,2),(78,'จัดการเมนู','1','managemenu',5,'2019-11-22 09:01:26','2020-04-02 16:43:23','dev@mode',72,2),(79,'ค้นหาข้อมูลสมาชิก','1','searchmember',5,'2019-11-30 10:00:36','2020-04-02 16:46:00','dev@mode',63,2),(80,'จัดการส่งข้อความล่วงหน้า','1','manageahead',10,'2019-12-02 10:04:10','2020-02-20 12:33:23','dev@mode',11,1),(82,'ทดสอบหัวข้องาน2','-9','xo3nLH',1,'2019-12-02 13:34:09','2019-12-02 14:08:37','demo',8,1),(83,'จัดระบบ','-9','7UdS94',1,'2019-12-02 13:40:45','2019-12-02 14:08:40','demo',8,1),(84,'จัดการระบบงาน','-9','kJIzxe',1,'2019-12-02 13:42:31','2019-12-02 13:55:34','demo',8,1),(85,'ทดสอบระบบ','-9','9QgnuU',1,'2019-12-02 13:43:49','2019-12-07 22:23:52','demo',8,1),(86,'dsfsdfdsfds','-9','7ufu3x',1,'2019-12-02 14:08:53','2019-12-02 14:08:59','demo',8,1),(88,'ผู้ใช้ที่ยังไม่ได้ลงทะเบียน','1','usernotregistered',3,'2019-11-30 10:00:36','2020-04-02 16:46:00','dev@mode',63,2),(89,'ทดสอบไม่มี Query','-9','oZQ8pq',1,'2019-12-07 22:19:28','2019-12-07 22:36:17','dev@mode',8,1),(90,'ทดสอบส่งทุกคนใน HR','-9','AkxqNS',7,'2019-12-08 00:54:03','2020-01-30 14:00:56','dev@mode',8,1),(91,'จัดการเทมเพลตระบบ','1','managesystemtemplate',9,'2019-12-09 21:00:06','2020-02-20 12:33:23','dev@mode',11,1),(92,'ทดสอบแบบไม่มี Query','-9','0nxv2b',6,'2019-12-10 00:18:21','2020-01-21 13:36:41','dev@mode',8,1),(93,'ทดสอบแบบมี Bind Param','-9','cnXfZS',5,'2019-12-10 00:19:11','2020-01-30 14:03:08','dev@mode',8,1),(94,'ระบุแอดมิน','1','assignadmin',3,'2019-11-21 17:13:05','2020-04-02 16:43:23','dev@mode',72,2),(95,'จัดการค่าคงที่รายบุคคล','-9','manageconstperson',7,'2020-01-06 09:23:45','2020-07-07 09:36:26','dev@mode',11,1),(96,'จัดการเมนูและกำหนดสิทธิ์','1','managemenuandpermission',0,'2019-11-07 15:13:20','2020-01-14 08:51:04','demo',0,5),(97,'กำหนดสิทธิ์การเข้าถึงเมนู','1','permissionmenu',2,'2019-11-07 15:13:20','2020-04-15 16:56:02','demo',96,5),(98,'รายงาน SMS ที่ส่งได้','1','reportsmssuccess',6,'2019-11-07 15:22:48','2020-02-20 12:33:23','dev@mode',10,1),(99,'ประมวลผล','-9','process',4,'2020-01-15 13:39:28','2020-07-07 09:36:46','dev@mode',0,1),(100,'ประมวลผลค่าบริการ SMS','1','processsmsservicefee',5,'2020-01-15 13:39:28','2020-02-20 12:33:23','dev@mode',99,1),(101,'ค่าคงที่ประเภทบัญชีเงินฝาก','1','constantdeptaccount',22,'2020-01-15 17:48:10','2021-01-14 10:08:32','dev@mode',106,2),(102,'จัดการใบคำขอสวัสดิการ','0','manageassistance',1,'2020-01-16 09:21:30','2020-04-02 16:43:23','dev@mode',72,2),(103,'รายงาน','1','reportmobileadmin',6,'2020-01-16 09:23:19','2020-04-02 16:45:43','dev@mode',0,2),(104,'เพิ่มเติม','1','moremobileadmin',5,'2020-01-16 09:24:46','2021-03-08 09:34:47','dev@mode',0,2),(105,'สอบถามรายการธนาคาร','-9','abouttransactions',15,'2020-01-16 09:27:31','2020-02-18 17:48:04','dev@mode',104,2),(106,'ค่าคงที่','1','constmobileadmin',4,'2020-01-16 09:39:22','2020-07-03 10:13:32','dev@mode',0,2),(107,'จัดการเมนู ','1','managemenu',3,'2019-11-07 15:13:20','2020-04-15 16:56:02','demo',96,5),(108,'กำหนดสิทธิ์รายงาน','0','permissionreport',4,'2019-11-07 15:13:20','2020-03-25 16:53:04','demo',96,5),(109,'จัดการบัญชีที่ผูก','-9','manageaccbeenbind',2,'2020-01-16 09:44:01','2020-07-03 10:18:58','dev@mode',72,2),(110,'ค่าคงที่ประเภทเงินกู้','1','constanttypeloan',19,'2020-01-16 09:47:30','2020-02-20 12:33:23','dev@mode',106,2),(111,'ค่าคงที่บัญชีธนาคาร','-9','constantbankaccount',20,'2020-01-16 09:49:53','2020-07-03 10:16:10','dev@mode',106,2),(112,'จัดการผู้ใช้งาน','1','managecoreusers',1,'2019-11-07 15:13:20','2020-04-15 16:56:02','demo',96,5),(113,'ส่งข้อความทุกคน','1','sendmessageall',11,'2019-11-07 15:41:31','2020-02-20 12:33:23','demo',9,1),(114,'ส่งวันเกิด','-9','uTVFbE',1,'2020-01-31 15:19:21','2020-01-31 15:20:15','dev@mode',8,1),(115,'ทดสอบแบบไม่มี Query','-9','HcNT0s',3,'2020-01-31 16:30:11','2020-06-22 20:24:19','dev@mode',8,1),(116,'ทดสอบแบบมี Query แต่ไม่มี Bind Param','-9','TagMVk',2,'2020-01-31 17:07:53','2020-06-22 20:24:22','dev@mode',8,1),(117,'ทดสอบแบบมี Bind Param2','-9','agNOdM',1,'2020-02-03 12:47:14','2020-06-22 20:24:26','dev@mode',8,1),(118,'เทส','-9','TUCdi8',1,'2020-02-12 17:52:39','2020-02-12 17:52:43','dev@mode',8,1),(119,'รายการทำธุรกรรมออนไลน์ภายนอก','1','reconcile',17,'2020-01-16 09:27:31','2020-06-23 13:43:26','dev@mode',104,2),(120,'รายงาน SMS ที่ส่งไม่ได้','1','reportsmsnotsuccess',8,'2019-11-07 15:22:48','2020-02-20 12:33:23','dev@mode',10,1),(121,'Log การเข้าถึงระบบ				','1','systemaccess',1,'2020-02-25 09:41:44','2020-02-25 12:14:21','dev@mode',0,4),(122,'Log การเข้าสู่ระบบ		','1','loglogin',1,'2020-02-25 09:43:40','2020-02-26 16:24:45','dev@mode',121,4),(123,'Log การใช้งานแอปพลิเคชัน','1','logapplicationuse',2,'2020-02-25 09:43:40','2020-06-24 14:36:45','dev@mode',121,4),(124,'Log การทำธุรกรรมออนไลน์			','1','logonlinetransaction',2,'2020-02-25 16:26:42','2021-01-14 11:02:09','dev@mode',0,4),(125,'Log การผูกบัญชี	','1','logbindaccount',11,'2020-02-25 16:29:29','2020-04-01 11:56:55','dev@mode',124,4),(126,'Log การยกเลิกผูกบัญชี	','1','logunbindaccount',12,'2020-02-26 16:29:29','2020-04-01 11:56:55','dev@mode',124,4),(127,'Log การถอนเงินออนไลน์	','1','logwithdrawonline',2,'2020-02-26 16:29:29','2020-04-01 11:56:55','dev@mode',124,4),(128,'Log การฝากเงินออนไลน์	','1','logdepositonline',5,'2020-02-26 16:29:29','2020-04-01 11:56:55','dev@mode',124,4),(129,'Log การโอนเงิน			','1','logtransfer',8,'2020-02-26 16:29:29','2020-04-01 11:56:55','dev@mode',124,4),(130,'Log การใช้งานล้มเหลว					','1','logusageerror',3,'2020-02-25 16:26:42','2020-04-02 16:43:43','dev@mode',0,4),(132,'Log โอนเงินภายในสหกรณ์ล้มเหลว','1','logtranferinsidecooperror',3,'2020-02-26 16:03:15','2021-01-14 11:02:05','dev@mode',130,4),(133,'Log ฝากเงินล้มเหลว		','1','logdepositerror',9,'2020-02-26 16:03:15','2021-01-14 11:02:02','dev@mode',130,4),(134,'Log ผูกบัญชีล้มเหลว				','1','logbindaccounterror',10,'2020-02-26 16:03:15','2021-01-14 11:00:48','dev@mode',130,4),(135,'Log ถอนเงินล้มเหลว		','1','logwithdrawerror',6,'2020-02-26 16:03:15','2021-01-14 11:00:51','dev@mode',130,4),(136,'Log โอนเงินภายนอกล้มเหลว','1','logdepttransbankerror',4,'2020-03-23 15:37:04','2021-01-14 11:00:53','dev@mode',130,4),(137,'รายงานการใช้งานระบบบริการสมาชิก','1','userusagereport',1,'2020-03-23 15:38:10','2020-03-23 15:38:10','dev@mode',103,2),(138,'Log การทำรายการของเจ้าหน้าที่','1','logeditdata',3,'2020-02-25 09:43:40','2020-04-06 17:37:04','dev@mode',0,4),(139,'Log การแก้ไขระบบ Mobile Admin','1','logeditmobileadmin',3,'2020-02-25 09:43:40','2020-04-06 16:45:34','dev@mode',138,4),(140,'Log การแก้ไขระบบ Admin Control','1','logeditadmincontrol',4,'2020-02-25 09:43:40','2020-04-13 14:44:57','dev@mode',138,4),(141,'Log ผู้ใช้งานที่ถูกล็อคบัญชี','1','loglockaccount',4,'2020-02-25 09:43:40','2020-04-14 10:11:51','dev@mode',121,4),(145,'บัญชีดำอุปกรณ์','1','blacklistdevice',6,'2019-11-30 10:00:36','2020-07-03 16:16:21','dev@mode',63,2),(146,'รายการใบคำขอสวัสดิการ','1','welfarerequest',17,'2020-01-16 09:27:31','2020-02-20 12:33:23','dev@mode',104,2),(147,'Log การทำธุรกรรมล้วเหลว			','1','logtransactionerror',4,'2020-06-22 16:26:42','2021-01-14 11:01:01','dev@mode',0,4),(148,'Log ซื้อหุ้นล้มเหลว','1','logbuyshareerror',1,'2020-01-22 09:27:31','2021-01-14 11:01:03','dev@mode',130,4),(149,'log ชำระหนี้ล้มเหลว','1','logrepayloanerror',1,'2020-01-22 09:27:31','2021-01-14 11:01:06','dev@mode',130,4),(150,'รายการทำธุรกรรมออนไลน์ภายใน','1','depttransaction',2,'2020-01-16 09:27:31','2020-02-20 12:33:23','dev@mode',104,2),(151,'ูรายการขอกู้','-9','loanrequestlist',18,'2020-01-16 09:27:31','2020-07-14 15:12:25','dev@mode',104,2),(153,'ทดสอบชื่อ','-9','tNp8lt',1,'2020-06-24 17:23:19','2020-06-24 18:42:38','dev@mode',8,1),(154,'แจ้งรหัส COOP-PHONE ให้กับสมาชิก','-9','iyPaTI',1,'2020-06-24 21:45:01','2020-07-14 11:04:23','dev@mode',8,1),(155,'แจ้งอนุมัติการใช้บัตร ATM กรุงไทย เพื่อถอนเงินสหกร','-9','6InFa1',1,'2020-06-24 23:07:26','2020-07-14 11:04:24','dev@mode',8,1),(156,'ส่งข้อความอัปโหลดรายบุคคล','1','sendmessagepersonimp',12,'2019-11-07 15:41:31','2020-06-25 16:06:43','demo',9,1),(157,'Log การใช้งานล้มเหลว','1','logerrorusage',10,'2020-07-03 11:00:04','2020-07-03 11:00:47','dev@mode',130,4),(158,'ค่าคงที่แจ้งเตือน','1','constantsms',3,'2020-07-14 15:12:44','2020-07-14 15:12:44','dev@mode',0,1),(159,'ค่าคงที่รายการเงินฝาก','1','constantsmsdeposit',1,'2020-07-14 15:13:09','2020-07-14 15:13:09','dev@mode',158,1),(160,'ค่าคงที่รายการเงินกู้','1','constantsmsloan',4,'2020-08-16 14:10:13','2020-08-16 14:10:13','dev@mode',158,1),(161,'ค่าคงที่รายการหุ้น','1','constantsmsshare',5,'2020-08-16 14:10:13','2020-08-16 14:10:13','dev@mode',158,1),(162,'กิจกรรมและข่าวสาร','1','activityandnews',1,'2020-09-01 14:05:09','2020-09-01 14:05:09','dev@mode',0,6),(163,'จัดการข่าวสารสหกรณ์','1','managenewswebcoop',1,'2020-09-01 14:17:03','2020-09-01 14:17:24','dev@mode',162,6),(164,'จัดการกิจกรรมสหกรณ์','1','manageactivitywebcoop',2,'2020-09-01 14:17:03','2020-09-01 14:17:24','dev@mode',162,6),(165,'จัดการวารสาร','1','managemagazin',3,'2020-09-01 14:17:03','2020-09-01 14:17:24','dev@mode',162,6),(166,'จัดการวาระประชุม','1','managemeetingagenda',4,'2020-09-01 14:17:03','2020-09-01 15:07:57','dev@mode',162,6),(167,'การจัดการบทความ','1','managewebbord',5,'2020-09-01 14:17:03','2020-09-01 15:07:57','dev@mode',162,6),(168,'ตั้งค่า','1','websetting',2,'2020-09-01 14:05:09','2020-09-01 14:05:09','dev@mode',0,6),(169,'จัดการข้อมูลเกี่ยวกับสหกรณ์','1','managecoopprofile',1,'2020-09-01 14:17:03','2020-09-01 15:24:14','dev@mode',168,6),(170,'แบนเนอร์','1','managebanner',2,'2020-09-01 14:17:03','2020-09-01 15:24:14','dev@mode',168,6),(171,'หน่วงานที่เกี่ยข้อง','1','managepartner',3,'2020-09-01 14:17:03','2020-09-01 15:24:14','dev@mode',168,6),(172,'จักการงบดุล','1','managebalancesheet',4,'2020-09-01 14:17:03','2020-09-01 15:24:14','dev@mode',168,6),(173,'ไฟล์เอกสารคำร้อง','1','managedocumentfile',5,'2020-09-01 14:17:03','2020-09-01 15:24:14','dev@mode',168,6),(174,'ไฟล์ข้อบังคับและระเบียบ','1','managerulefile',6,'2020-09-01 14:17:03','2020-09-01 15:24:14','dev@mode',168,6),(175,'คณะกรรมการ','1','manageboard',7,'2020-09-01 14:17:03','2020-09-01 15:24:14','dev@mode',168,6),(176,'ผลงานของคณะกรรมการ','-9','manageboardperformance',9,'2020-09-01 14:17:03','2020-10-06 10:17:06','dev@mode',168,6),(177,'ค่าคงที่แก้ไขข้อมูล','0','constantchangeinfo',29,'2020-09-01 17:57:49','2020-10-06 10:11:24','dev@mode',106,2),(178,'รายงานแจ้งเตือนที่ส่งได้','1','reportnotifysuccess',8,'2020-09-08 10:03:23','2020-09-08 10:03:23','dev@mode',10,1),(179,'ตารางผลการดำเนินงาน','1','manageoperatingresults',9,'2020-09-01 14:17:03','2020-09-01 15:24:14','dev@mode',168,6),(180,'เจ้าหน้าที่สหกรณ์','1','manageofficer',8,'2020-09-01 14:17:03','2020-10-05 13:41:40','dev@mode',168,6),(181,'อัตราดอกเบี้ย','1','manageinterestrate',13,'2020-09-01 14:17:03','2020-10-05 13:41:40','dev@mode',168,6),(182,'ปฏิทินสหกรณ์','1','calandarwebcoop',6,'2020-09-01 14:17:03','2020-10-13 09:27:50','dev@mode',162,6),(183,'แฟ้มเอกสาร','1','documents',3,'2021-02-25 11:08:44','2021-02-25 11:08:44','dev@mode',0,10),(184,'ตั้งค่าเอกสาร','1','settingsdocument',4,'2021-02-25 11:08:44','2021-02-25 11:08:44','dev@mode',0,10),(185,'ค่าคงที่เอกสาร','1','constdocument',5,'2021-02-25 11:09:07','2021-02-25 11:09:07','dev@mode',0,10),(186,'เอกสารทั้งหมด','1','viewdocuments',8,'2021-02-25 11:10:48','2021-02-25 11:10:48','dev@mode',183,10),(187,'จัดการแฟ้มเอกสาร','1','managedocuments',8,'2021-02-25 11:10:48','2021-02-25 11:10:48','dev@mode',184,10),(188,'ค่าคงที่อัพโหลดเอกสาร','1','manageuploadconst',2,'2021-02-25 11:11:40','2021-02-25 11:11:40','dev@mode',185,10),(189,'จัดการการควบคุมเอกสาร','1','managedoccontrolid',3,'2021-02-25 11:11:40','2021-02-25 11:11:40','dev@mode',184,10),(190,'Log การแก้ไขระบบ Document','1','logeditdocument',5,'2021-02-25 11:12:06','2021-02-25 11:12:06','dev@mode',138,4),(191,'รายการใบคำขอกู้','1','loanrequestform',3,'2020-01-16 09:27:31','2020-06-23 13:43:26','dev@mode',104,2),(192,'ค่าคงที่เมนูธุรกรรม','1','constanttransactionmenu',20,'2021-05-27 16:28:41','2021-05-27 16:28:41','dev@mode',106,2),(193,'ค่าคงที่ธนาคาร','1','constantbank',20,'2021-05-27 16:30:06','2021-05-27 16:30:06','dev@mode',106,2),(194,'รายงานธุรกรรมออนไลน์','1','onlinetransactionreport',2,'2020-03-23 15:38:10','2020-03-23 15:38:10','dev@mode',103,2);
/*!40000 ALTER TABLE `coresubmenu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coreuser`
--

DROP TABLE IF EXISTS `coreuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coreuser` (
  `username` varchar(20) NOT NULL,
  `password` varchar(200) NOT NULL,
  `id_section_system` tinyint(3) unsigned NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `user_status` enum('0','1','-9') NOT NULL DEFAULT '1',
  PRIMARY KEY (`username`),
  KEY `FK_SECTION_SYSTEM` (`id_section_system`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coreuser`
--

LOCK TABLES `coreuser` WRITE;
/*!40000 ALTER TABLE `coreuser` DISABLE KEYS */;
INSERT INTO `coreuser` VALUES ('demo','$2y$10$83U8iIi.mbCXcpfTLE.GNewdRx/3ft89dG7rx29IkQJu81VqC3S8e',2,'2020-07-03 09:59:31','2021-12-15 10:44:24','-9'),('demo2','$2y$10$m.WbzrLwBRn4ilfKeVDTzuEBjrg9THUcCBy1q1LKSHq6Vw/5qbyjC',3,'2020-07-03 10:00:44','2020-07-03 10:00:59','-9'),('dev@mode','$2y$10$3S5TNPvzNLV8tvhOrfoDkuB4FRAzNrkK5DVdK4u05xpialXRGt11S',1,'2020-07-02 17:28:11','2020-07-02 17:28:11','1'),('Omsubsaman','$2y$10$xd91bYgkS0bDnWSrhL1/1OJPzLx2C8JrbdEKeiTx9XWtFQVJ.1Zam',6,'2020-07-08 09:07:24','2021-12-15 10:44:26','-9'),('spsadmin','$2y$10$9AJtRJFFG06jM3Q9XnpOBuvx89kD/fCWkUq9NXxgr.32Cly8tcrBO',6,'2021-12-15 10:44:49','2021-12-15 10:44:54','1'),('system','$2y$10$bwKITciX6En3wbZ5JFpJjux3IU4qnwbsBhj1temi3RWq/Z2LJIR8m',1,'2020-09-01 17:57:37','2020-09-01 17:57:37','1');
/*!40000 ALTER TABLE `coreuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coreuserlogin`
--

DROP TABLE IF EXISTS `coreuserlogin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coreuserlogin` (
  `id_userlogin` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `unique_id` varchar(50) NOT NULL,
  `is_login` enum('0','1') NOT NULL DEFAULT '1',
  `device_name` text NOT NULL,
  `login_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `auth_token` text NOT NULL,
  `logout_date` datetime NOT NULL,
  PRIMARY KEY (`id_userlogin`),
  KEY `FK_USERNAME_LOGIN` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coreuserlogin`
--

LOCK TABLES `coreuserlogin` WRITE;
/*!40000 ALTER TABLE `coreuserlogin` DISABLE KEYS */;
INSERT INTO `coreuserlogin` VALUES (1,'dev@mode','4sqm7wx0rnJe173F','1','Chrome V.87 on Windows 10','2020-12-22 16:48:03','2020-12-22 16:48:03','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjA4NjUyMDgzfQ.MI7semyogbwtEorIVe232C1xEr6kbHDjTQpVSH4MZbs','2020-12-22 17:48:03'),(2,'dev@mode','4sqm7wx0rnJe173F','1','Chrome V.87 on Windows 10','2020-12-22 16:54:02','2020-12-22 16:54:02','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjA4NjUyNDQyfQ.hjnpYaO95koN4lOi5bOxgVErTt8KO6XF2_q3qY-ukps','2020-12-22 17:54:02'),(3,'dev@mode','4sqm7wx0rnJe173F','1','Chrome V.87 on Windows 10','2020-12-22 17:01:35','2020-12-22 17:01:35','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjA4NjUyODk1fQ.3xiudScJbC4ffTamiqx1yQyyDRQYXMwe9K1H038Te7s','2020-12-22 18:01:35'),(4,'dev@mode','I0HKUfrX3q0m0uJ3','1','Chrome V.87 on Windows 10','2020-12-23 12:09:59','2020-12-23 12:09:59','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjA4NzIxNzk5fQ.MWc-7Wm1t2_t-_529Kl6PlP6WQyUUlltLvY2WGdiDx8','2020-12-23 13:09:59'),(5,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.87 on Windows 10','2020-12-23 16:31:22','2020-12-23 16:31:22','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjA4NzM3NDgyfQ.-cGNTY8094Gz26DfawClXKEb3o2LiJWy9ZHhnASeE58','2020-12-23 17:31:22'),(6,'dev@mode','ucZNvZUbZ0D4UVv6','1','Chrome V.87 on Windows 10','2020-12-23 17:05:48','2020-12-23 17:05:48','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjA4NzM5NTQ4fQ.HzLS_suQs_QDd7PPEfu0Aoh_myjHg5h0iTQhLjIdm8Q','2020-12-23 18:05:48'),(7,'dev@mode','I0HKUfrX3q0m0uJ3','1','Chrome V.87 on Windows 10','2020-12-23 17:22:41','2020-12-23 17:22:41','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjA4NzQwNTYxfQ.rB93i0clxzysZB3lutR3jYOJS64zSfcTlFq9vJ91hV8','2020-12-23 18:22:41'),(8,'dev@mode','I0HKUfrX3q0m0uJ3','1','Chrome V.87 on Windows 10','2020-12-23 17:24:47','2020-12-23 17:24:47','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjA4NzQwNjg3fQ.Kecx5ogN0Zpu_cRWHZ1SL298x6sGyJQCRpRYgEIyp0Y','2020-12-23 18:24:47'),(9,'dev@mode','2rsPVOtr94gW6JBA','1','Mobile Safari V.14 on iOS 14.3','2020-12-23 17:25:55','2020-12-23 17:25:55','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjA4NzQwNzU1fQ.Oitd86CKPwIjcv5Ua3PZUnENvAUF2AzOz8hVOCqlHA4','2020-12-23 18:25:55'),(10,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.87 on Windows 10','2021-01-04 14:21:44','2021-01-04 14:21:44','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjA5NzY2NTA0fQ.l7WIDjESPMWjcYpiZdLq5i9PX_SrqSvn1RHnZd5ZDpE','2021-01-04 15:21:44'),(11,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.87 on Windows 10','2021-01-04 15:14:48','2021-01-04 15:14:48','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjA5NzY5Njg4fQ.Lm1xj0YpvX3en4C7wXCY3TP81IWhKURwIUo_76AYSpc','2021-01-04 16:14:48'),(12,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.87 on Windows 10','2021-01-14 09:58:08','2021-01-14 09:58:08','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjEwNjE0Njg4fQ.FGACcB6N_4-Eh8YPmjTlnd5jL0Sa0rUPVWITDuQffOU','2021-01-14 10:58:08'),(13,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.87 on Windows 10','2021-01-14 14:03:30','2021-01-14 14:03:30','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjEwNjI5NDEwfQ.MggKK9OlVVXLxSTkXu0wOyxGYcXKn4TebB4TE_rrxYE','2021-01-14 15:03:30'),(14,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.87 on Windows 10','2021-01-14 17:29:18','2021-01-14 17:29:18','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjEwNjQxNzU4fQ.wruJhGlYXDagmoQAygJzOEF1iZL7CwzSdTlinnUeSM8','2021-01-14 18:29:18'),(15,'dev@mode','38ieVNyQRmR1iKv8','1','Chrome V.88 on Windows 10','2021-02-25 10:49:51','2021-02-25 10:49:51','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjE0MjQ2NTkxfQ.R8RZ-L_6thKOuA-K3FYoJIrWlNu4qzaL-sLiAI7HtG8','2021-02-25 11:49:51'),(16,'dev@mode','AknM7MXR9g48N53v','1','Chrome V.89 on Android 10','2021-03-08 08:20:34','2021-03-08 08:20:34','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjE1MTg4MDM0fQ.VYgz0BBWJX-PS4J68ZEMlMxw7tC_6vnGt_brYbZeaTA','2021-03-08 09:20:34'),(17,'dev@mode','AknM7MXR9g48N53v','1','Chrome V.89 on Android 10','2021-03-08 08:59:23','2021-03-08 08:59:23','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjE1MTkwMzYzfQ.PBmWjW8xUWjDgDfY5wHi1fw94F_S5e7ORWsZEaNHtys','2021-03-08 09:59:23'),(18,'dev@mode','Kz2PIOf6AZ79YPcN','1','Edge V.89 on Windows 10','2021-03-08 09:11:49','2021-03-08 09:11:49','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjE1MTkxMTA5fQ.T1032N8oAR7_FFexWO5c4kCc0xoi1bN4s86DNc_aNAY','2021-03-08 10:11:49'),(19,'dev@mode','Kz2PIOf6AZ79YPcN','1','Edge V.89 on Windows 10','2021-03-08 09:27:49','2021-03-08 09:27:49','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjE1MTkyMDY5fQ.nCdu9JffLPcr-L_p8eybtId51QnwxlDBQBDZUJSOj5o','2021-03-08 10:27:49'),(20,'dev@mode','Kz2PIOf6AZ79YPcN','1','Edge V.89 on Windows 10','2021-03-08 09:45:44','2021-03-08 09:45:44','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjE1MTkzMTQ0fQ.Hww8WnQ51QtPnpV_XOWIWZwGLMFrFqqI3n7u7OVcmzI','2021-03-08 10:45:44'),(21,'dev@mode','AknM7MXR9g48N53v','1','Chrome V.89 on Android 10','2021-03-08 10:10:28','2021-03-08 10:10:28','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjE1MTk0NjI4fQ.TGqJAHWgk8LE9bKZ37DxFwL1c6GFLJe6SxtANQbqsF8','2021-03-08 11:10:28'),(22,'dev@mode','fxDWAODu29RvONCz','1','Chrome V.89 on Windows 10','2021-03-30 10:01:21','2021-03-30 10:01:21','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjE3MDk0ODgxfQ.OhQhz66ez0rTMTXyJE8nw9pgpzBLPCEUthh_T8_ZEjE','2021-03-30 11:01:21'),(23,'dev@mode','38ieVNyQRmR1iKv8','1','Chrome V.89 on Windows 10','2021-03-30 13:25:55','2021-03-30 13:25:55','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjE3MTA3MTU1fQ.C8XpwqHbwOZfIQNuLrb-UqZOj8NNLx_i42jse5-P0OA','2021-03-30 14:25:55'),(24,'dev@mode','I0HKUfrX3q0m0uJ3','1','Chrome V.89 on Windows 10','2021-03-30 14:33:00','2021-03-30 14:33:00','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjE3MTExMTgwfQ.Qi-FjiNmVMwxG7iNRvemSsTz2gT0IGp27QRmvmLiCxI','2021-03-30 15:33:00'),(25,'dev@mode','38ieVNyQRmR1iKv8','1','Chrome V.89 on Windows 10','2021-03-31 09:11:26','2021-03-31 09:11:26','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjE3MTc4Mjg2fQ.W4GRqhnGCpQ6eW36yzvMz9kskGp-bULtRzW05tDoEvM','2021-03-31 10:11:26'),(26,'dev@mode','I0HKUfrX3q0m0uJ3','1','Chrome V.89 on Windows 10','2021-03-31 10:43:25','2021-03-31 10:43:25','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjE3MTgzODA1fQ.Noy-TgXj5Be1BNEHtQFipj5_NemuAfUeG3asaR3kHm8','2021-03-31 11:43:25'),(27,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.90 on Windows 10','2021-05-07 10:26:30','2021-05-07 10:26:30','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjIwMzc5NTkwfQ.UXDyxEgcIvUiCSdz2UPpFki3s5QgTOJQhOYRtrhZEic','2021-05-07 11:26:30'),(28,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.90 on Windows 10','2021-05-10 10:56:36','2021-05-10 10:56:36','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjIwNjQwNTk2fQ.Ams4y-il7_DQquU_fSodSAVibTU2NB-rYAv68GCVhkw','2021-05-10 11:56:36'),(29,'dev@mode','I0HKUfrX3q0m0uJ3','1','Chrome V.90 on Windows 10','2021-05-10 11:02:53','2021-05-10 11:02:53','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjIwNjQwOTczfQ.92t4FP8zrOkYR-OHCY16Fc7Rsn5_EamObGz3KUQAiKk','2021-05-10 12:02:53'),(30,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.90 on Windows 10','2021-05-11 10:12:20','2021-05-11 10:12:20','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjIwNzI0MzQwfQ.QaxdfLGD5uVx5lFZVWJj0qOhfp-5RYlwuO8jDutNuNg','2021-05-11 11:12:20'),(31,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.90 on Windows 10','2021-05-11 17:11:25','2021-05-11 17:11:25','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjIwNzQ5NDg1fQ.PjB_N6rd2jr-OMr68-XRGvoZ4XmmsEKenAFJVMQ7GxA','2021-05-11 18:11:25'),(32,'dev@mode','ucZNvZUbZ0D4UVv6','1','Chrome V.90 on Windows 10','2021-05-11 17:46:07','2021-05-11 17:46:07','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjIwNzUxNTY3fQ.ynryl0lNjRSKqQT6-HjdQlRQQdCDEj4BDnE95ZRAUJc','2021-05-11 18:46:07'),(33,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.90 on Windows 10','2021-05-25 16:26:05','2021-05-25 16:26:05','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjIxOTU2MzY1fQ.ouB3kLhKVZxO5tAX0X4XD1djeDDrXvvYrm6vbZhq0OI','2021-05-25 17:26:05'),(34,'dev@mode','SbUsrXz7RNoeZeld','1','Chrome V.90 on Windows 10','2021-05-27 09:38:49','2021-05-27 09:38:49','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjIyMTA0NzI5fQ.Sj2rbkY6xbbeziqCp7oiNNc9qGg0mgPE5rlmQzq61jg','2021-05-27 10:38:49'),(35,'dev@mode','SbUsrXz7RNoeZeld','1','Chrome V.90 on Windows 10','2021-05-27 09:44:06','2021-05-27 09:44:06','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjIyMTA1MDQ2fQ.4_TMkFQ15LFAasq3Gd9tFjyJXHHPhjttN0Al2uzvvLs','2021-05-27 10:44:06'),(36,'dev@mode','SbUsrXz7RNoeZeld','1','Chrome V.90 on Windows 10','2021-05-27 09:53:41','2021-05-27 09:53:41','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjIyMTA1NjIxfQ.KEoFf84Wf-XEjxaiSMYBFI46YzgK85fEgY05my3cGl4','2021-05-27 10:53:41'),(37,'dev@mode','SbUsrXz7RNoeZeld','1','Chrome V.90 on Windows 10','2021-05-27 09:54:32','2021-05-27 09:54:32','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjIyMTA1NjcyfQ.x8kwIwFfyYdlb6RdCUZX5wjZuCd0FEZpXRXmZ1g87tE','2021-05-27 10:54:32'),(38,'dev@mode','SbUsrXz7RNoeZeld','1','Chrome V.90 on Windows 10','2021-05-27 09:56:59','2021-05-27 09:56:59','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjIyMTA1ODE5fQ.hAQBY2Y2TQIGvLKXU1QBQ4_qlMnl3x2VP5tbVWbGQUM','2021-05-27 10:56:59'),(39,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.90 on Windows 10','2021-05-27 10:48:24','2021-05-27 10:48:24','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjIyMTA4OTA0fQ.UiNAPIZw-EbdLISFYY43xRbLdQ5HgFHhcSq6Jdwm2qI','2021-05-27 11:48:24'),(40,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.90 on Windows 10','2021-05-27 16:53:26','2021-05-27 16:53:26','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjIyMTMwODA2fQ.yguQKg3MrUeZ3EsCwadVBsTlpxBqUTeMaE-e4PZYizY','2021-05-27 17:53:26'),(41,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.90 on Windows 10','2021-05-28 09:21:49','2021-05-28 09:21:49','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjIyMTkwMTA5fQ.F6OM3fssJs0JPNS_WAdxgaD8lr41e9xFWfVA_rhsPZk','2021-05-28 10:21:49'),(42,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.91 on Windows 10','2021-06-18 13:46:25','2021-06-18 13:46:25','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI0MDIwMzg1fQ.42FL_S2Y9e2yOb4OXpYiVQfwTDRbICmDQ5iB0cBPaYI','2021-06-18 14:46:25'),(43,'dev@mode','SbUsrXz7RNoeZeld','1','Chrome V.91 on Windows 10','2021-06-21 09:24:30','2021-06-21 09:24:30','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI0MjYzODcwfQ.xuhQlj_3U8GPxqqx4PX1It7xLpBxf2izT0bns5rLaAc','2021-06-21 10:24:30'),(44,'dev@mode','I0HKUfrX3q0m0uJ3','1','Chrome V.91 on Windows 10','2021-06-21 10:26:16','2021-06-21 10:26:16','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI0MjY3NTc2fQ.cE41-WJnQOunEMzDdCVYIUwO2eX8YtFnc8O6vMXaxfg','2021-06-21 11:26:16'),(45,'dev@mode','I0HKUfrX3q0m0uJ3','1','Chrome V.91 on Windows 10','2021-06-23 09:22:07','2021-06-23 09:22:07','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI0NDM2NTI3fQ.tGCfFS6cWTxdIhWy6jGM1ZnPf0VM7w874-Stgs-kvqc','2021-06-23 10:22:07'),(46,'dev@mode','SbUsrXz7RNoeZeld','1','Chrome V.91 on Windows 10','2021-06-23 09:42:42','2021-06-23 09:42:42','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI0NDM3NzYyfQ.LUcnZeUjgCnz30AwPlwPnH_52EOsU2vebQNhs23KEgY','2021-06-23 10:42:42'),(47,'dev@mode','I0HKUfrX3q0m0uJ3','1','Chrome V.91 on Windows 10','2021-06-23 10:08:50','2021-06-23 10:08:50','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI0NDM5MzMwfQ.r7CaeO2q3xRCF2p9Q1tJp6kLyoRGeIZGwAxbJ-XzrAo','2021-06-23 11:08:50'),(48,'dev@mode','SbUsrXz7RNoeZeld','1','Chrome V.91 on Windows 10','2021-06-23 13:53:18','2021-06-23 13:53:18','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI0NDUyNzk4fQ.qQKuCFGUM-uVA1KpRgWcOyUZCv_WLIxOHs1W3uw7MzA','2021-06-23 14:53:18'),(49,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.91 on Windows 10','2021-06-23 14:43:40','2021-06-23 14:43:40','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI0NDU1ODIwfQ.2BLK_TAk8amLtFt74V4LYbyXugOoXlycN__-n0AFBKs','2021-06-23 15:43:40'),(50,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.91 on Windows 10','2021-06-23 16:51:35','2021-06-23 16:51:35','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI0NDYzNDk1fQ.rBW2y_rcVWjKTl_5dKe--nhGAaPeRxwvTJAG3WVCc-w','2021-06-23 17:51:35'),(51,'dev@mode','fxDWAODu29RvONCz','1','Chrome V.91 on Windows 10','2021-06-24 11:12:59','2021-06-24 11:12:59','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI0NTI5NTc5fQ.sblfSmUB1EBs6AQKZXEho0KbsYGZBgYnbaO2jAp3dhk','2021-06-24 12:12:59'),(52,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.91 on Windows 10','2021-06-24 16:10:37','2021-06-24 16:10:37','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI0NTQ3NDM3fQ.tS176wCG-poPBDrbo9czkLjdps5rErb6tquI5i1Mcj8','2021-06-24 17:10:37'),(53,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.91 on Windows 10','2021-06-25 12:00:31','2021-06-25 12:00:31','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI0NjE4ODMxfQ.h14teKvd7TK4xsf3UleuyHTzFWLuY_oUPOsT2ENz7Ac','2021-06-25 13:00:31'),(54,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.91 on Windows 10','2021-06-29 09:40:17','2021-06-29 09:40:17','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI0OTU2MDE3fQ.pAGiqJCLa0LNGHcoRj34WD5qOgsjAVNfdS4_W2CkDq0','2021-06-29 10:40:17'),(55,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.91 on Windows 10','2021-06-30 15:16:27','2021-06-30 15:16:27','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI1MDYyNTg3fQ.P13q0ZCrGdnIobdByyU1Low5aVqljdkI2qQEi0BuLVM','2021-06-30 16:16:27'),(56,'dev@mode','ORpqNIXl9eNejWKo','1','Chrome V.91 on Windows 10','2021-06-30 18:14:37','2021-06-30 18:14:37','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI1MDczMjc3fQ.EIPRrLa5hnfye8qWYD_JEk3-OBGZ_deaxObqibkbsyA','2021-06-30 19:14:37'),(57,'dev@mode','DZKuxuBrYMhDhkO3','1','Chrome V.91 on Windows 10','2021-07-02 14:48:41','2021-07-02 14:48:41','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI1MjMzNzIxfQ.D970-yLaIba65FYGsTlubTtr0rApJ-hw92urdlRaq_Q','2021-07-02 15:48:41'),(58,'dev@mode','I0HKUfrX3q0m0uJ3','1','Chrome V.91 on Windows 10','2021-07-02 15:05:49','2021-07-02 15:05:49','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI1MjM0NzQ5fQ.u_zbDBTgyi37OHjfec75VZxgxrC_-qVUDCOHwZGN6T4','2021-07-02 16:05:49'),(59,'dev@mode','DZKuxuBrYMhDhkO3','1','Chrome V.91 on Windows 10','2021-07-05 15:38:55','2021-07-05 15:38:55','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI1NDk1OTM1fQ.J1kRt8Ur5ITkA8sK1l7vnSdMz3BT3qFmZImxyEPGz1A','2021-07-05 16:38:55'),(60,'dev@mode','I0HKUfrX3q0m0uJ3','1','Chrome V.91 on Windows 10','2021-07-05 15:51:40','2021-07-05 15:51:40','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI1NDk2NzAwfQ.5C1GW-CoCU3NuEcAhr0THIVyWzCQcnhScEMPIezPBsg','2021-07-05 16:51:40'),(61,'dev@mode','DZKuxuBrYMhDhkO3','1','Chrome V.91 on Windows 10','2021-07-06 10:03:50','2021-07-06 10:03:50','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI1NTYyMjMwfQ.AtmSo_gfBqE8wGBUi9ZpLmgNTsLCDw1xKQeuS6n8kDI','2021-07-06 11:03:50'),(62,'dev@mode','I0HKUfrX3q0m0uJ3','1','Chrome V.91 on Windows 10','2021-07-09 09:13:11','2021-07-09 09:13:11','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI1ODE4MzkxfQ.KRy-Y0QhcCkbhadoHSV_m32OPKZBcr_qYFGd7WgTvEI','2021-07-09 10:13:11'),(63,'dev@mode','I0HKUfrX3q0m0uJ3','1','Chrome V.91 on Windows 10','2021-07-09 09:13:33','2021-07-09 09:13:33','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI1ODE4NDEzfQ.IHc-MgrfIwKwp_EPM69mSad2gU2XLC4wCLZ57s_907w','2021-07-09 10:13:33'),(64,'dev@mode','ILp1smYYOFtb6VYp','1','Chrome V.91 on Windows 10','2021-07-14 11:14:03','2021-07-14 11:14:03','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI2MjU3NjQzfQ.AYS3IZnG0cmvDRsURZQWYXLFivRl4U2r4orJsNCGTJY','2021-07-14 12:14:03'),(65,'dev@mode','ILp1smYYOFtb6VYp','1','Chrome V.91 on Windows 10','2021-07-14 11:23:21','2021-07-14 11:23:21','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI2MjU4MjAxfQ.1eggf0u4KhW1CxsHHHMmDGm-TbScEpMliCUDnitASWg','2021-07-14 12:23:21'),(66,'dev@mode','ILp1smYYOFtb6VYp','1','Chrome V.91 on Windows 10','2021-07-14 11:38:07','2021-07-14 11:38:07','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI2MjU5MDg3fQ.b7XllbhYg_MjDTOMoCExILucaKadSNAv7ain772oDvs','2021-07-14 12:38:07'),(67,'dev@mode','NacOkmmOEmFFuqNM','1','Chrome V.91 on Windows 10','2021-07-14 17:20:32','2021-07-14 17:20:32','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI2Mjc5NjMyfQ.37KNcZhP0aUSV1cbqqQiOvj8CWyet_WSC2bV4QX0Ks8','2021-07-14 18:20:32'),(68,'dev@mode','9JjDt6YdOELmuZuQ','1','Chrome V.91 on Windows 10','2021-07-21 11:44:01','2021-07-21 11:44:01','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI2ODY0MjQxfQ.9PttsGVWzNn3g7DJSjl1kKYUEiFHg9xO_-JprNnSPdg','2021-07-21 12:44:01'),(69,'dev@mode','9JjDt6YdOELmuZuQ','1','Chrome V.92 on Windows 10','2021-07-22 14:58:20','2021-07-22 14:58:20','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI2OTYyMzAwfQ.LIvoHVUUdpEHgb7hMixF7oz6k8NEHGqiHclq4xPP_PI','2021-07-22 15:58:20'),(70,'dev@mode','AZD9Qu3sML9KMPab','1','Chrome V.92 on Windows 10','2021-07-29 12:02:09','2021-07-29 12:02:09','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI3NTU2NTI5fQ.wTsILDRFoiN6vQVP3smtCbJtAP8qoQG5ludv_Bt1umk','2021-07-29 13:02:09'),(71,'dev@mode','9JjDt6YdOELmuZuQ','1','Chrome V.92 on Windows 10','2021-08-03 15:03:28','2021-08-03 15:03:28','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjI3OTk5NDA4fQ.XGIRbYnUOw2P_QN33fqTz8CpHnsIvBU4Joyp10W-Y_s','2021-08-03 16:03:28'),(72,'dev@mode','9JjDt6YdOELmuZuQ','1','Chrome V.93 on Windows 10','2021-09-27 09:56:44','2021-09-27 09:56:44','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjMyNzMzMDA0fQ.OGNrhZq-HBaxmZh2Bb7mAkRzNVDBVAks1bThfc6LUJU','2021-09-27 10:56:44'),(73,'dev@mode','9JjDt6YdOELmuZuQ','1','Chrome V.94 on Windows 10','2021-10-04 11:39:04','2021-10-04 11:39:04','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjMzMzQzOTQ0fQ.CmHlJ4_uxgwEoh9VADj941CYIFSzbNwgpoZg8HaWG3k','2021-10-04 12:39:04'),(74,'dev@mode','9JjDt6YdOELmuZuQ','1','Chrome V.94 on Windows 10','2021-10-05 09:48:01','2021-10-05 09:48:01','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjMzNDIzNjgxfQ.J1T9DXvpF0JiBYmx6bAWG0VfjMoIwEZd4ZeDBalrSvQ','2021-10-05 10:48:01'),(75,'dev@mode','NacOkmmOEmFFuqNM','1','Chrome V.94 on Windows 10','2021-10-06 13:38:31','2021-10-06 13:38:31','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjMzNTIzOTExfQ.2IHbcBgJqPqOUKCRQlu-iKscNwaimTDNdiHi_NUmCNk','2021-10-06 14:38:31'),(76,'dev@mode','NacOkmmOEmFFuqNM','1','Chrome V.94 on Windows 10','2021-10-06 14:37:42','2021-10-06 14:37:42','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjMzNTI3NDYyfQ.fdvFHYRiNhuZphmUoWB2HDUltHVDOKBxF0yIvnX6nkU','2021-10-06 15:37:42'),(77,'dev@mode','NacOkmmOEmFFuqNM','1','Chrome V.94 on Windows 10','2021-10-06 16:42:15','2021-10-06 16:42:15','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjMzNTM0OTM1fQ.rzVB2p8Tq5R-qEofZQqAMVDQMsCMg5NyfXoqsD5qjaI','2021-10-06 17:42:15'),(78,'dev@mode','9JjDt6YdOELmuZuQ','1','Chrome V.94 on Windows 10','2021-10-07 16:01:35','2021-10-07 16:01:35','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjMzNjE4ODk1fQ.59aUaNSnL7jO9g7ur9U7qysexwuMakMAXHiDVAM1yzw','2021-10-07 17:01:35'),(79,'dev@mode','MgbKuIKvJxZ6UR9w','1','Chrome V.94 on Windows 10','2021-10-08 09:23:07','2021-10-08 09:23:07','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjMzNjgxMzg3fQ.2lR1ZQUpeKdMuYvEggnxhklgw0OpNmQaEDMnf0ZiEkE','2021-10-08 10:23:07'),(80,'dev@mode','ILp1smYYOFtb6VYp','1','Chrome V.96 on Windows 10','2021-11-22 12:01:19','2021-11-22 12:01:19','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjM3NTc4ODc5fQ.QkxH4JHI00EfgsB9CL4sOFL2x1sLDE8TH1NvKPrCZqs','2021-11-22 13:01:19'),(81,'dev@mode','lhCtYeAL4h0I7Cvh','1','Chrome V.96 on Windows 10','2021-11-22 12:15:48','2021-11-22 12:15:48','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjM3NTc5NzQ4fQ.qykgW2WC4qysjdc3kLzv-gIQm4-aMsXdhL1srBJlPsg','2021-11-22 13:15:48'),(82,'dev@mode','fmydraNemCDH8ye0','1','Chrome V.96 on Windows 10','2021-11-22 12:16:28','2021-11-22 12:16:28','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjM3NTc5Nzg4fQ.eYaax0oaevvZKkSlNqospnA9-xAvj98mlgRjIpW1PUc','2021-11-22 13:16:28'),(83,'dev@mode','fmydraNemCDH8ye0','1','Chrome V.96 on Windows 10','2021-12-08 21:50:35','2021-12-08 21:50:35','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjM4OTk2NjM1fQ.nzHo_Mvec7_PJSquWCwmdbak2jJpP4jsNtz-lfaFnfc','2021-12-08 22:50:35'),(84,'dev@mode','fmydraNemCDH8ye0','1','Chrome V.96 on Windows 10','2021-12-15 10:43:55','2021-12-15 10:43:55','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjM5NTYxNDM1fQ.8jp1Q9eVvsVW54mfSB_GPn-3Ia2-GCv9Nn6B17PPTlw','2021-12-15 11:43:55'),(85,'spsadmin','6qwx3Cikrvs2MiuQ','0','Edge V.96 on Windows 10','2021-12-15 10:47:01','2021-12-15 10:47:39','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjM5NTYxNjIxfQ.KiEz0Gfa7BT68F9ET9_bQUPpDKtTrXM2QZbEyO8rnd4','2021-12-15 11:47:01'),(86,'spsadmin','osJFYprH6M6PHuhR','0','Chrome V.96 on Android 11','2021-12-15 10:47:39','2021-12-15 11:03:36','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjM5NTYxNjU5fQ.iQIwSOsdNAkVh1EP1Gw4ZMc93khEY5dmjy-GLBy8Kis','2021-12-15 11:47:39'),(87,'spsadmin','TexdmjIlx4F8jf79','0','Firefox V.95 on Windows 10','2021-12-15 11:03:36','2021-12-15 15:42:57','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjM5NTYyNjE2fQ.A9sO-Jd0n0iDmWkd3l5C4t1zmAR0OmGWUXVmmu0Lf-E','2021-12-15 12:03:36'),(88,'dev@mode','0dGTVUKz7ImLgYVb','1','Chrome V.96 on Mac OS 10.15.7','2021-12-15 11:38:30','2021-12-15 11:38:30','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjM5NTY0NzEwfQ.tqKu0WPexAUVlk-uVkYRIVm9R7mmVjfpe2F0jLaVczo','2021-12-15 12:38:30'),(89,'spsadmin','TexdmjIlx4F8jf79','0','Firefox V.95 on Windows 10','2021-12-15 15:42:57','2021-12-20 09:01:11','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjM5NTc5Mzc3fQ.Uc0Rpv6TwAdFtun2-V5uoANpZiKABE2m5vONGHAcXJI','2021-12-15 16:42:57'),(90,'spsadmin','TexdmjIlx4F8jf79','0','Firefox V.95 on Windows 10','2021-12-20 09:01:11','2022-01-13 08:29:54','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjM5OTg3MjcxfQ.IS_WJBXXaIHbKRRpEssbjBBMFlNEX76zr8-vIy9tYuw','2021-12-20 10:01:11'),(91,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.95 on Windows 10','2022-01-13 08:29:54','2022-01-14 09:44:39','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQyMDU4OTk0fQ.I_ZPMk_xkLev0BbD5f50mRSyZE8aiR7ZzX1Lxii1w2M','2022-01-13 09:29:54'),(92,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.96 on Windows 10','2022-01-14 09:44:39','2022-01-24 09:10:34','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQyMTQ5ODc5fQ.A-NjSKDC4mgnrGMBABLlvE89tduixMVxEAPmQ_rSLS8','2022-01-14 10:44:39'),(93,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.96 on Windows 10','2022-01-24 09:10:34','2022-01-24 16:51:44','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQzMDExODM0fQ.HoaZDH5vw8R9-x6L4qMyS_HdlVy6cLcc5HOCs5gORC0','2022-01-24 10:10:34'),(94,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.96 on Windows 10','2022-01-24 16:51:44','2022-01-24 17:11:07','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQzMDM5NTA0fQ.ZC5g3wtSowB4jtxfRLCHfrqFba230humNXO-weSFqVU','2022-01-24 17:51:44'),(95,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.96 on Windows 10','2022-01-24 17:11:07','2022-01-25 10:57:50','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQzMDQwNjY3fQ.I2NF35XUv2OpMfe20wHwU9yrudrzhJWR76AQ1WeccP0','2022-01-24 18:11:07'),(96,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.96 on Windows 10','2022-01-25 10:57:50','2022-01-27 15:57:11','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQzMTA0NjcwfQ._3h5PxaFGBRDJ7CPiXXhpCDuvX2XRD9HU9Tqr6c_t_0','2022-01-25 11:57:50'),(97,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.96 on Windows 10','2022-01-27 15:57:11','2022-01-31 12:45:52','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQzMjk1NDMxfQ.sxZrCciEDTGjfk4pD17cc1iSGnX6hQn9D_5vKoxxOic','2022-01-27 16:57:11'),(98,'spsadmin','5nrQMIEB9xLBUIHt','0','Edge V.97 on Windows 10','2022-01-31 12:45:52','2022-02-03 14:22:35','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQzNjI5NTUyfQ.-2OPIX4YEwXsbD9pLoJCkgDGK_--TWLimaS-Lp5xweM','2022-01-31 13:45:52'),(99,'dev@mode','fmydraNemCDH8ye0','1','Chrome V.97 on Windows 10','2022-02-01 14:02:47','2022-02-01 14:02:47','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjQzNzIwNTY3fQ.D3O2Ct8lwzUPuHltWT3vTBtp-_JVefQr7r4p1A5QNr0','2022-02-01 15:02:47'),(100,'spsadmin','5nrQMIEB9xLBUIHt','0','Edge V.97 on Windows 10','2022-02-03 14:22:35','2022-02-08 10:32:09','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQzODk0NTU1fQ.bn3n8JXc_Tz2_Et6vYIXvoaKP4uxaSUHSMiqVNfH9Y4','2022-02-03 15:22:35'),(101,'spsadmin','5nrQMIEB9xLBUIHt','0','Edge V.98 on Windows 10','2022-02-08 10:32:09','2022-02-10 13:33:51','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ0MzEyNzI5fQ.wnPq9RoewPlf2ClaEdMLjiYad81KWs8DckJDs6vuKs4','2022-02-08 11:32:09'),(102,'spsadmin','5nrQMIEB9xLBUIHt','0','Edge V.98 on Windows 10','2022-02-10 13:33:51','2022-02-14 09:12:47','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ0NDk2NDMxfQ.fdlMsCIxK8M4KEdaLfHJrbWaHwq7otpoLAeJEDYiLQk','2022-02-10 14:33:51'),(103,'spsadmin','5nrQMIEB9xLBUIHt','0','Edge V.98 on Windows 10','2022-02-14 09:12:47','2022-02-17 16:55:43','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ0ODI2MzY3fQ.6oorPFQfNXDMdTiN3ZhbP-1SIThGsbE-0reyLsGSXGc','2022-02-14 10:12:47'),(104,'spsadmin','5nrQMIEB9xLBUIHt','0','Edge V.98 on Windows 10','2022-02-17 16:55:43','2022-02-25 10:15:39','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ1MTEzMzQzfQ.saTgdxg_9HEAjJwGtvNb_LtUMZq50o7HgzOucTW52CU','2022-02-17 17:55:43'),(105,'spsadmin','5nrQMIEB9xLBUIHt','0','Edge V.98 on Windows 10','2022-02-25 10:15:39','2022-02-25 14:40:39','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ1NzgwNTM5fQ.LagIe4CyT0Xi2RmlJgDHr8hw3y9AWTIo3A2Z6V_ITE4','2022-02-25 11:15:39'),(106,'spsadmin','5nrQMIEB9xLBUIHt','0','Edge V.98 on Windows 10','2022-02-25 14:40:39','2022-02-25 16:26:03','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ1Nzk2NDM5fQ.Smn0uqYWCy52XWszF5GCzKyOnFLZWNNeD-w_0iP-AhQ','2022-02-25 15:40:39'),(107,'spsadmin','5nrQMIEB9xLBUIHt','0','Edge V.98 on Windows 10','2022-02-25 16:26:03','2022-02-28 14:01:46','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ1ODAyNzYzfQ.3G8k3ONJf77g2LQTxwAcnzgS9-ox1LZHPV1mtwVxI1E','2022-02-25 17:26:03'),(108,'spsadmin','5nrQMIEB9xLBUIHt','0','Edge V.98 on Windows 10','2022-02-28 14:01:46','2022-03-02 09:34:12','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ2MDUzMzA2fQ.i_IotF4Z6lls_FZeQ4Nmmu-npmRMhJSk_a64OrR1Ioo','2022-02-28 15:01:46'),(109,'dev@mode','qoyGzIQGyPOyQx7d','1','Chrome V.98 on Windows 10','2022-03-01 12:34:50','2022-03-01 12:34:50','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjQ2MTM0NDkwfQ.xJPxYaR77uC0n1jFDtHsFlQpV_Wj7IFUDsN9tJuh3Ig','2022-03-01 13:34:50'),(110,'spsadmin','5nrQMIEB9xLBUIHt','0','Edge V.98 on Windows 10','2022-03-02 09:34:12','2022-03-03 08:52:08','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ2MjEwMDUyfQ.oxtqOG6WETOaaqp18_SKHCBSBic_7HpLFXvMfb0D4aY','2022-03-02 10:34:12'),(111,'spsadmin','5nrQMIEB9xLBUIHt','0','Edge V.98 on Windows 10','2022-03-03 08:52:08','2022-03-03 09:22:18','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ2MjkzOTI4fQ.DwADOkHNLTDv_KcHG8IQ93utYbJYV8D5GDUQEuRRXe8','2022-03-03 09:52:08'),(112,'spsadmin','5nrQMIEB9xLBUIHt','0','Edge V.98 on Windows 10','2022-03-03 09:22:18','2022-03-04 12:33:00','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ2Mjk1NzM4fQ.Ji4NLrUPC_8jac0_XFquKzDnCVs4KAx_bi9Cs77EcZ8','2022-03-03 10:22:18'),(113,'spsadmin','5nrQMIEB9xLBUIHt','0','Edge V.98 on Windows 10','2022-03-04 12:33:00','2022-03-08 16:51:30','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ2MzkzNTgwfQ.gB86VG1Cvg8p7JFP4A6psKGCtCP0Eoaru5gjBGeAHu8','2022-03-04 13:33:00'),(114,'spsadmin','5nrQMIEB9xLBUIHt','0','Edge V.99 on Windows 10','2022-03-08 16:51:30','2022-03-09 09:54:15','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ2NzU0NjkwfQ.1B58KWelaPPPfxkDAdq4mqMZNeJkVSI9-pCISAweMqk','2022-03-08 17:51:30'),(115,'spsadmin','5nrQMIEB9xLBUIHt','0','Edge V.99 on Windows 10','2022-03-09 09:54:15','2022-03-14 11:01:04','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ2ODE2MDU1fQ.kuZiydBscE3hm96fuObuZ-uGZFhQ_RXue3sNy0APhn4','2022-03-09 10:54:15'),(116,'spsadmin','5nrQMIEB9xLBUIHt','0','Edge V.99 on Windows 10','2022-03-14 11:01:04','2022-03-14 13:34:00','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ3MjUyMDY0fQ.Pa_dLZ9OO8lHoGL6rbok7l8tSuOQLXz1MjQnGuviiQc','2022-03-14 12:01:04'),(117,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.99 on Windows 10','2022-03-14 13:34:00','2022-03-15 09:39:30','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ3MjYxMjQwfQ.Hd0jWpenbRikghoTPeJI8MyF_CI0XcqvraoBK7YGsDc','2022-03-14 14:34:00'),(118,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.99 on Windows 10','2022-03-15 09:39:30','2022-03-15 12:18:27','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ3MzMzNTcwfQ.i46tB9jo2fZMuQQCnnZkRuhdqmvFaurWuahI5la_vGE','2022-03-15 10:39:30'),(119,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.99 on Windows 10','2022-03-15 12:18:27','2022-03-15 13:36:25','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ3MzQzMTA3fQ._y-ZsaJ-vJPVqjByiXLLuxYKrJlfGU96cgX5tVQhCOM','2022-03-15 13:18:27'),(120,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.99 on Windows 10','2022-03-15 13:36:25','2022-03-18 14:15:54','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ3MzQ3Nzg1fQ.4ZG9wuUTJZ5f3529fFrPexBRu11y0bJTmZsnPJeeBIk','2022-03-15 14:36:25'),(121,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.99 on Windows 10','2022-03-18 14:15:54','2022-03-21 11:05:04','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ3NjA5MzU0fQ.HJGKf9BAkScZk9T5uySOftdbGu7xDqNPgwI8OP2jyQA','2022-03-18 15:15:54'),(122,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.99 on Windows 10','2022-03-21 11:05:05','2022-03-21 16:26:13','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ3ODU3MTA0fQ.IKpyTJYvgOfznudKJM-wM8Etbpy0K4G83UbajN9XQyg','2022-03-21 12:05:05'),(123,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.99 on Windows 10','2022-03-21 16:26:13','2022-03-23 16:25:17','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ3ODc2MzczfQ.Zify6Lji6azEDl8N3vBoDNlPckoO_p5dTVHwRF53JYU','2022-03-21 17:26:13'),(124,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.99 on Windows 10','2022-03-23 16:25:17','2022-03-25 09:04:38','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ4MDQ5MTE3fQ.lf01vvtLHEVcYt7R-xBZkq1AIU073JuBbw8xpzUv3fI','2022-03-23 17:25:17'),(125,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.99 on Windows 10','2022-03-25 09:04:38','2022-03-30 10:49:35','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ4MTk1NDc4fQ.dF0YTOHWIvd53lMtto5s03b2MQari9DW59GqfA6liuw','2022-03-25 10:04:38'),(126,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.99 on Windows 10','2022-03-30 10:49:35','2022-03-31 15:12:40','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ4NjMzNzc1fQ.rocEj_DIE9OyVqIF_3OBIGq-JxiomwZmswG9UsTqwDM','2022-03-30 11:49:35'),(127,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.99 on Windows 10','2022-03-31 15:12:40','2022-04-01 15:30:19','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ4NzM1OTYwfQ.whLEEuin_0yTq2Zv1COWqPm4VFlGZc1x5nk7Yrv9S4Q','2022-03-31 16:12:40'),(128,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.99 on Windows 10','2022-04-01 15:30:19','2022-04-04 16:02:22','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ4ODIzNDE5fQ.Bzi3rYDO2X4nG_LjtxdiYmZlgbgZaH83GzhyDMBvqCI','2022-04-01 16:30:19'),(129,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.100 on Windows 10','2022-04-04 16:02:22','2022-04-05 09:53:41','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ5MDg0NTQyfQ.-AtLc4Lvu8GrbD2X3Qp3AySYNSomjQbqbL4gJZI0fUI','2022-04-04 17:02:22'),(130,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.100 on Windows 10','2022-04-05 09:53:41','2022-04-18 10:13:31','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjQ5MTQ4ODIxfQ.GsyQGxVLP6GO-uIStaNzcKatHSE10pnep0xESMApQ_Q','2022-04-05 10:53:41'),(131,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.100 on Windows 10','2022-04-18 10:13:31','2022-04-22 14:17:34','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUwMjczMjExfQ.D3vl2J4Jlyha9y9tBwZQQEVIxKmLQtisKZ52Er9kgEM','2022-04-18 11:13:31'),(132,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.100 on Windows 10','2022-04-22 14:17:34','2022-04-25 10:10:15','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUwNjMzNDU0fQ.vLw9cMaGJu62Xa-WoJIZzKrOB2zB0SpJpCmtsibqhBM','2022-04-22 15:17:34'),(133,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.100 on Windows 10','2022-04-25 10:10:15','2022-04-27 14:54:39','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUwODc3ODE1fQ.scgDHtPgHvvQLhYWQG1C8Ucgkz1mlk-61SOY-vfaEh0','2022-04-25 11:10:15'),(134,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.100 on Windows 10','2022-04-27 14:54:39','2022-04-29 14:51:36','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUxMDY3Njc5fQ.tqLTcOsZESSCMWZt7eqekdG6_NUt2aQRQUzUd_RvS-w','2022-04-27 15:54:39'),(135,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.100 on Windows 10','2022-04-29 14:51:36','2022-05-05 09:39:48','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUxMjQwMjk2fQ.NP73Agmq7Asq-b07VpWQsw_EEaVrPssQgmyUucLD-MU','2022-04-29 15:51:36'),(136,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.100 on Windows 10','2022-05-05 09:39:48','2022-05-05 16:22:15','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUxNzM5OTg4fQ.CGPYnX8pDIUjwjEF74i2ULranJBEvQhRJjHHW3CqL-0','2022-05-05 10:39:48'),(137,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.100 on Windows 10','2022-05-05 16:22:15','2022-05-06 14:30:18','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUxNzY0MTM1fQ.mpbO8jZct3pU-2_YFWfYHMBzVDEkMywY2Ahkr4vHJR8','2022-05-05 17:22:15'),(138,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.101 on Windows 10','2022-05-06 14:30:18','2022-05-06 15:29:17','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUxODQzODE4fQ.p2Kylgen6Hb1FhV-k5owfkkkV9ha0EDVJ35TbVGwRX4','2022-05-06 15:30:18'),(139,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.101 on Windows 10','2022-05-06 15:29:17','2022-05-10 11:55:34','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUxODQ3MzU3fQ.dVItlBWKV0QXrWeLiMMsttSnE63kk4bZg49gJOxs7Fg','2022-05-06 16:29:17'),(140,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.100 on Windows 10','2022-05-10 11:55:34','2022-05-10 14:19:43','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUyMTgwMTM0fQ.EMp5BQ1g7ECQKbfg0Y52LYTTfIOktxdp2lrrPE8Myd0','2022-05-10 12:55:34'),(141,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.101 on Windows 10','2022-05-10 14:19:43','2022-05-17 08:58:43','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUyMTg4NzgzfQ.wIoa1lNpGi99luEQig2mt3qKrsfLmzl149xVvJ7znSo','2022-05-10 15:19:43'),(142,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.101 on Windows 10','2022-05-17 08:58:43','2022-05-17 12:05:52','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUyNzc0MzIzfQ.yJ_KUKmIdQWuYWMF8qUjc4M32hHAjeTTYle5UKntnYQ','2022-05-17 09:58:43'),(143,'dev@mode','uwr2qWkfAsVZPfCV','1','Chrome V.101 on Mac OS 10.15.7','2022-05-17 11:18:48','2022-05-17 11:18:48','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6InJvb3QiLCJ1c2VybmFtZSI6ImRldkBtb2RlIiwiZXhwIjoxNjUyNzgyNzI4fQ.zNtBHXdbxaqVLm5H07gmN4K_V0uv3Hd9JOZqyVBURFA','2022-05-17 12:18:48'),(144,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.101 on Windows 10','2022-05-17 12:05:52','2022-05-17 14:42:42','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUyNzg1NTUyfQ.X3VnB3q54rflb7b2_3nUH_3UTyb__VzGfPJOpdDjCA4','2022-05-17 13:05:52'),(145,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.101 on Windows 10','2022-05-17 14:42:42','2022-05-20 13:12:51','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUyNzk0OTYyfQ.lz2r8eDQUdpRLIwIk19awgdniHgu2ifuV47hjxix_1A','2022-05-17 15:42:42'),(146,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.101 on Windows 10','2022-05-20 13:12:51','2022-05-23 10:33:50','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUzMDQ4NzcxfQ.Esg2QupcEq6ff0YGg1efhXodLGUpcH1Ze6cKE6gpSXM','2022-05-20 14:12:51'),(147,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.101 on Windows 10','2022-05-23 10:33:50','2022-05-25 09:38:21','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUzMjk4NDMwfQ.MW6xrGSyv5WzacxaKywCVY02H5zsj0j8nJubPbeJNEo','2022-05-23 11:33:50'),(148,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.101 on Windows 10','2022-05-25 09:38:21','2022-05-27 09:06:05','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUzNDY3OTAxfQ.3RIe5GKwCp77jK60jNlQjUjPhW5o8Q-xrZEbOKtdeuU','2022-05-25 10:38:21'),(149,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.100 on Windows 10','2022-05-27 09:06:05','2022-05-27 10:37:39','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUzNjM4NzY1fQ.-wef26jIXsWJyem4PzWV9_9If1Uhu_4pvbuJ1DtcpSM','2022-05-27 10:06:05'),(150,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.100 on Windows 10','2022-05-27 10:37:39','2022-05-30 11:23:23','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUzNjQ0MjU5fQ.SGRhVMMlvbsDIEXQRnrwvGX2E9mtYJ8-Ohz-Dl3Ez8w','2022-05-27 11:37:39'),(151,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.100 on Windows 10','2022-05-30 11:23:23','2022-05-31 10:11:13','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUzOTA2MjAzfQ.FQmq1IvzOO4TUmNUlBmKylg_-xlfCazzQMDpyrFgQ4w','2022-05-30 12:23:23'),(152,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.100 on Windows 10','2022-05-31 10:11:13','2022-06-01 15:41:30','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjUzOTg4MjczfQ.jgGL8iFqPAMN2WXjnSZbiVDwTuFaCdZ-IPRg2xyfG-k','2022-05-31 11:11:13'),(153,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.100 on Windows 10','2022-06-01 15:41:30','2022-06-01 15:47:32','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU0MDk0NDkwfQ.LSoU2V95E_l7cfIUr3tqCtrtvIL4EDW4PAqXOZaYVX8','2022-06-01 16:41:30'),(154,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.100 on Windows 10','2022-06-01 15:47:32','2022-06-02 08:13:48','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU0MDk0ODUyfQ.YfcZwzH6xXzJvBuPO7bRk9BzzEvj-giUE1ul1BC71rI','2022-06-01 16:47:32'),(155,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.101 on Windows 10','2022-06-02 08:13:48','2022-06-06 10:04:20','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU0MTU0MDI4fQ.jRMuaVVvU0LWmhfc2Rr-LOFEh__7azAvSzc5grZ3p9U','2022-06-02 09:13:48'),(156,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.102 on Windows 10','2022-06-06 10:04:20','2022-06-09 10:34:13','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU0NTA2MjYwfQ.Ap3Wy06PF-zL-p9HuZZ0zPyBDEUyxUe-HPi-gO4-JeE','2022-06-06 11:04:20'),(157,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.101 on Windows 10','2022-06-09 10:34:13','2022-06-10 15:04:04','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU0NzY3MjUzfQ.HxghtNX0KZMcBy2Pis_nXVJIHMkzr2x6KIHlKog5Hqg','2022-06-09 11:34:13'),(158,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.101 on Windows 10','2022-06-10 15:04:04','2022-06-10 15:26:36','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU0ODY5ODQ0fQ.DzCpT2JTsPGvpjq43OB5sL6OuTwBlnlDnzcP-l2YfOw','2022-06-10 16:04:04'),(159,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.101 on Windows 10','2022-06-10 15:26:36','2022-06-14 11:50:27','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU0ODcxMTk2fQ.1ouQD0T5q_ByeTY29axzqDkOIR8ehRP7H-zPHCYd8Xk','2022-06-10 16:26:36'),(160,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.101 on Windows 10','2022-06-14 11:50:27','2022-06-17 10:05:29','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU1MjAzODI2fQ.bPwJNt8KfCacpBKr_xiEef7RjgYBonJT1FH3Ww_dsQo','2022-06-14 12:50:27'),(161,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.102 on Windows 10','2022-06-17 10:05:29','2022-06-22 08:52:00','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU1NDU2NzI5fQ.87x2v3Fx_YB_06vMJRcvrqHlTqCrtle-iKjoXucD0Ss','2022-06-17 11:05:29'),(162,'spsadmin','0l9v16o1xDdkY9QL','0','Chrome V.102 on Windows 10','2022-06-22 08:52:00','2022-06-22 14:58:39','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU1ODg0MzIwfQ.ZlLWIrTEsTnEZ9n5nBx0wyBXcs4WgH069F2snwIuosM','2022-06-22 09:52:00'),(163,'spsadmin','Qm6aATL0Dm1BJQxR','0','Chrome V.102 on Windows 10','2022-06-22 14:58:39','2022-06-23 15:05:02','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU1OTA2MzE5fQ.marMkLznzRoKvQHRu63rn6sdeMauGSLuqcFs4g8-6no','2022-06-22 15:58:39'),(164,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.101 on Windows 10','2022-06-23 15:05:02','2022-06-24 10:07:36','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU1OTkzMTAyfQ.fEyq221oxyV3jhs8XimeCx_JMfQ3GB00aJYODeuj2rI','2022-06-23 16:05:02'),(165,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.101 on Windows 10','2022-06-24 10:07:36','2022-06-27 10:14:51','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU2MDYxNjU2fQ.-EhAA7pMBwiM774ft4VpGq9Ou7j4mF9wokXwqTqMqEU','2022-06-24 11:07:36'),(166,'spsadmin','Qm6aATL0Dm1BJQxR','0','Chrome V.102 on Windows 10','2022-06-27 10:14:51','2022-06-27 12:04:53','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU2MzIxMjkxfQ.cRUCyCy_xb5NlrPGcAFJ-3Kg8AUf3kxRek6PDZHIV30','2022-06-27 11:14:51'),(167,'spsadmin','Qm6aATL0Dm1BJQxR','0','Chrome V.102 on Windows 10','2022-06-27 12:04:53','2022-06-27 13:43:30','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU2MzI3ODkzfQ.CeQhl_dASyLC-RFnSiTRWLhXTk58DSfQ3eqz9Ver0Uo','2022-06-27 13:04:53'),(168,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.101 on Windows 10','2022-06-27 13:43:30','2022-06-27 14:58:24','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU2MzMzODEwfQ.Z0_crEwWusRhjFfP9JRxpdi51RL_nhdlNAplsU8AZbE','2022-06-27 14:43:30'),(169,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.101 on Windows 10','2022-06-27 14:58:24','2022-07-05 10:43:26','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU2MzM4MzA0fQ.rLd_lGBn4uK4aS1BCuGvD87J6HTZ2z0hLpsURAJSBPY','2022-06-27 15:58:24'),(170,'spsadmin','Qm6aATL0Dm1BJQxR','0','Chrome V.103 on Windows 10','2022-07-05 10:43:26','2022-07-05 13:56:53','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU3MDE0MjA2fQ.fw8_Yzens1yiWRCYkwobnTTgyjs9oLMo8EG7Cdy9ch0','2022-07-05 11:43:26'),(171,'spsadmin','Qm6aATL0Dm1BJQxR','0','Chrome V.103 on Windows 10','2022-07-05 13:56:53','2022-07-05 15:20:45','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU3MDI1ODEzfQ.CpA37p3jZrgaNV7WCedmZXKjq39Nd5zoi0ggrSjUzKM','2022-07-05 14:56:53'),(172,'spsadmin','Qm6aATL0Dm1BJQxR','0','Chrome V.103 on Windows 10','2022-07-05 15:20:45','2022-07-06 09:37:16','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU3MDMwODQ1fQ.tsU116E5rn7fhBMR2ec3qTpCRnyAC_V7pvJjm1W2M5U','2022-07-05 16:20:45'),(173,'spsadmin','Qm6aATL0Dm1BJQxR','0','Chrome V.103 on Windows 10','2022-07-06 09:37:16','2022-07-06 10:14:26','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU3MDk2NjM2fQ.KkYiiF-VccF31MEtR0_H5nRVJ3KTI8Ymw2UEmuHM6_U','2022-07-06 10:37:16'),(174,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.102 on Windows 10','2022-07-06 10:14:26','2022-07-06 11:12:10','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU3MDk4ODY2fQ.vSxjimYglOJivEtQooGfJoPr7MHnJjMe5Ab4fWN0L1U','2022-07-06 11:14:26'),(175,'spsadmin','ZZn7CklH8i4uT1UY','0','Firefox V.102 on Windows 10','2022-07-06 11:12:10','2022-07-11 10:13:33','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU3MTAyMzMwfQ.9-tNYhLAFlZrByJGMUWzcnx_owy3AXekPYaza5MfPEs','2022-07-06 12:12:10'),(176,'spsadmin','Qm6aATL0Dm1BJQxR','0','Chrome V.103 on Windows 10','2022-07-11 10:13:33','2022-07-12 10:26:31','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU3NTMwODEzfQ.J_mrHRZ1bGWbBvLUMW4lVX9FyXdgXs2Cz2YGILmkOfY','2022-07-11 11:13:33'),(177,'spsadmin','Qm6aATL0Dm1BJQxR','1','Chrome V.103 on Windows 10','2022-07-12 10:26:31','2022-07-12 10:26:31','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWN0aW9uX3N5c3RlbSI6ImtlZXBpbmciLCJ1c2VybmFtZSI6InNwc2FkbWluIiwiZXhwIjoxNjU3NjE3OTkxfQ.sTr3QiBzLpP0BDGCoydZYbwq8zeiNFDHy20QklaytIM','2022-07-12 11:26:31');
/*!40000 ALTER TABLE `coreuserlogin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `csbankdisplay`
--

DROP TABLE IF EXISTS `csbankdisplay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `csbankdisplay` (
  `bank_code` char(3) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `bank_short_name` varchar(100) NOT NULL,
  `bank_short_ename` varchar(20) NOT NULL,
  `bank_logo_path` varchar(100) NOT NULL,
  `bank_format_account` varchar(15) NOT NULL,
  `bank_format_account_hide` varchar(15) NOT NULL,
  `id_palette` tinyint(3) unsigned NOT NULL,
  `itemtype_wtd` varchar(5) DEFAULT NULL,
  `itemtype_dep` varchar(5) DEFAULT NULL,
  `link_deposit_coopdirect` varchar(250) DEFAULT NULL,
  `link_withdraw_coopdirect` varchar(250) DEFAULT NULL,
  `link_inquirydep_coopdirect` varchar(250) DEFAULT NULL,
  `link_inquirywithd_coopdirect` varchar(250) DEFAULT NULL,
  `link_unbindaccount` varchar(250) DEFAULT NULL,
  `fee_deposit` decimal(10,2) NOT NULL DEFAULT 0.00,
  `fee_withdraw` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`bank_code`),
  KEY `FK_PALETTE_BANK_COLOR` (`id_palette`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `csbankdisplay`
--

LOCK TABLES `csbankdisplay` WRITE;
/*!40000 ALTER TABLE `csbankdisplay` DISABLE KEYS */;
INSERT INTO `csbankdisplay` VALUES ('006','ธนาคารกรุงไทย จำกัด (มหาชน)','ธนาคารกรุงไทย','KTB','/resource/utility_icon/bank_icon/ktb.png','xxx-x-xxxxx-x','hhh-h-hxxxx-h',1,'WTX','DTX','ktb/ePaynetDeposit/deposit_epaynet','ktb/withdraw/FundTransfer',NULL,'/ktb/withdraw/Inquiry','/ktb/unbind_consent_non_direct',0.00,7.00);
/*!40000 ALTER TABLE `csbankdisplay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doccontrolid`
--

DROP TABLE IF EXISTS `doccontrolid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doccontrolid` (
  `short_prefix` varchar(4) CHARACTER SET utf8 NOT NULL,
  `description` varchar(200) CHARACTER SET utf8 NOT NULL,
  `amount_prefix` varchar(4) CHARACTER SET utf8 NOT NULL,
  `prefix_data_type` enum('string','running','year','month','day','column') CHARACTER SET utf8 NOT NULL,
  `data_value_column` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `data_desc_column` varchar(200) DEFAULT NULL,
  `connection_db` enum('mysql','oracle','mssql') DEFAULT NULL,
  `query_string` text DEFAULT NULL,
  `is_use` enum('0','1') CHARACTER SET utf8 NOT NULL DEFAULT '1',
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`short_prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doccontrolid`
--

LOCK TABLES `doccontrolid` WRITE;
/*!40000 ALTER TABLE `doccontrolid` DISABLE KEYS */;
INSERT INTO `doccontrolid` VALUES ('D','วันที่','2','day',NULL,NULL,NULL,NULL,'1','2020-12-09 16:29:21'),('L','ประเภทเงินกู้','2','column','LOANTYPE_CODE','LOANTYPE_DESC','mssql','SELECT LOANTYPE_CODE,LOANTYPE_DESC FROM LNLOANTYPE ORDER BY LOANTYPE_CODE ASC','1','2021-02-25 14:54:23'),('M','เดือน','2','month',NULL,NULL,NULL,NULL,'1','2020-12-09 16:29:20'),('R','เลขรันนิ่งนับจากจำนวนเอกสาร','6','running','c_reqloan',NULL,'mysql','SELECT COUNT(*) as c_reqloan FROM gcreqloan','1','2021-02-25 15:53:04'),('S','คำระบุแฟ้มเอกสารเป็นตัวหนังสืออะไรก็ได้','1','string',NULL,NULL,NULL,NULL,'1','2020-12-10 09:29:26'),('Y','ปี','4','year',NULL,NULL,NULL,NULL,'1','2020-12-09 16:29:18'),('YA','ปีบัญชี','4','column','AC_YEAR',NULL,'mssql','SELECT MAX(account_year) as ac_year FROM cmaccountyear WHERE CONVERT(DATETIME, CONVERT(DATE, GETDATE())) BETWEEN CONVERT(DATETIME, CONVERT(DATE, ACCSTART_DATE)) and CONVERT(DATETIME, CONVERT(DATE, ACCEND_DATE))','1','2021-02-25 14:59:48');
/*!40000 ALTER TABLE `doccontrolid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `docgroupcontrol`
--

DROP TABLE IF EXISTS `docgroupcontrol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `docgroupcontrol` (
  `docgrp_no` varchar(50) CHARACTER SET utf8 NOT NULL,
  `docgrp_name` varchar(200) NOT NULL,
  `docgrp_ref` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `is_use` enum('0','1') CHARACTER SET utf8 NOT NULL DEFAULT '1',
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `create_by` varchar(20) CHARACTER SET utf8 NOT NULL,
  `is_lock` enum('0','1') CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `menu_component` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`docgrp_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `docgroupcontrol`
--

LOCK TABLES `docgroupcontrol` WRITE;
/*!40000 ALTER TABLE `docgroupcontrol` DISABLE KEYS */;
INSERT INTO `docgroupcontrol` VALUES ('10','แฟ้มเก็บใบคำขอกู้และหลักฐานประกอบการกู้',NULL,'1','2020-12-09 17:07:58','2020-12-17 15:09:14','dev@mode','0','LoanRequestForm'),('100','ทดสอบเพิ่มแฟ้มเอกสาร',NULL,'0','2020-12-22 09:20:30','2020-12-22 10:44:50','dev@mode','0',NULL),('1001','ทดสอบเพิ่มแฟ้มเอกสาร','100','0','2020-12-21 13:52:11','2020-12-21 17:17:59','dev@mode','0',NULL),('1002','ก',NULL,'0','2020-12-23 10:44:20','2020-12-23 10:44:31','dev@mode','0',NULL),('1002qwe','ทดสอบเพิ่มแฟ้มเอกสาร',NULL,'0','2020-12-22 10:42:54','2020-12-23 10:42:47','dev@mode','0','LoanRequestForm'),('100er','ทดสอบเพิ่มแฟ้มเอกสาร',NULL,'0','2020-12-21 17:38:28','2020-12-23 10:43:21','dev@mode','0',NULL),('100ere','ทดสอบเพิ่มแฟ้มเอกสาร',NULL,'0','2020-12-21 17:39:14','2020-12-21 17:39:25','dev@mode','0',NULL),('10CITIZEN','แฟ้มเก็บสำเนาเลขบัตรประชาชน','10','0','2020-12-09 17:36:07','2020-12-23 10:42:37','dev@mode','0','citizen'),('10SALARY','แฟ้มเก็บสำเนาสลิปเงินเดือน','10','1','2021-05-10 10:58:41','2021-05-10 10:59:44','dev@mode','0','salary'),('FetchDocData','asdasd','1002qwe','0','2020-12-22 10:43:13','2020-12-23 10:42:42','dev@mode','0','CITIZEN'),('FetchDocDatawe','ทดสอบเพิ่มแฟ้มเอกสาร','1002qwe','0','2020-12-22 10:44:00','2020-12-23 10:42:44','dev@mode','0',NULL),('TestFolder1','ทดสอบเพิ่มแฟ้มเอกสาร','1001','0','2020-12-21 16:22:58','2020-12-21 17:17:18','dev@mode','0',NULL);
/*!40000 ALTER TABLE `docgroupcontrol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doclistdetail`
--

DROP TABLE IF EXISTS `doclistdetail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doclistdetail` (
  `id_detail` int(12) NOT NULL AUTO_INCREMENT,
  `doc_no` varchar(50) CHARACTER SET utf8 NOT NULL,
  `upload_date` datetime NOT NULL DEFAULT current_timestamp(),
  `member_no` char(8) CHARACTER SET utf8 NOT NULL,
  `source_filename` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `new_filename` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `id_userlogin` mediumint(8) unsigned DEFAULT NULL,
  PRIMARY KEY (`id_detail`)
) ENGINE=InnoDB AUTO_INCREMENT=268 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doclistdetail`
--

LOCK TABLES `doclistdetail` WRITE;
/*!40000 ALTER TABLE `doclistdetail` DISABLE KEYS */;
INSERT INTO `doclistdetail` VALUES (1,'000001','2021-02-25 15:12:57','etnmode1',NULL,'000001.pdf',23),(2,'000002','2021-02-25 15:53:54','etnmode1',NULL,'000002.pdf',23),(3,'000003','2021-02-25 15:56:49','etnmode1',NULL,'000003.pdf',23),(4,'000004','2021-03-03 16:48:47','dev@mode',NULL,'000004.pdf',25),(5,'000005','2021-03-08 10:08:41','dev@mode',NULL,'000005.pdf',26),(6,'000006','2021-04-01 10:11:42','etnmode2',NULL,'000006.pdf',28),(7,'000007salary','2021-05-10 10:50:47','etnmode3',NULL,'salary.jpeg',33),(8,'000007','2021-05-10 10:50:49','etnmode3',NULL,'000007.pdf',33),(9,'000008salary','2021-05-10 10:51:50','etnmode3',NULL,'salary.jpeg',33),(10,'000008','2021-05-10 10:51:51','etnmode3',NULL,'000008.pdf',33),(11,'000009salary','2021-05-10 11:07:09','etnmode3',NULL,'salary.jpeg',33),(12,'000009','2021-05-10 11:07:09','etnmode3',NULL,'000009.pdf',33),(13,'000010salary','2021-05-10 11:25:30','etnmode3',NULL,'salary.jpeg',33),(14,'000010','2021-05-10 11:25:31','etnmode3',NULL,'000010.pdf',33),(15,'000011salary','2021-05-10 13:11:48','etnmode3',NULL,'salary.jpeg',33),(16,'000011','2021-05-10 13:11:48','etnmode3',NULL,'000011.pdf',33),(17,'000011salary','2021-05-10 13:13:38','etnmode3',NULL,'salary.jpeg',33),(18,'000011','2021-05-10 13:13:39','etnmode3',NULL,'000011.pdf',33),(19,'000011salary','2021-05-10 13:14:10','etnmode3',NULL,'salary.jpeg',33),(20,'000011','2021-05-10 13:14:11','etnmode3',NULL,'000011.pdf',33),(21,'000011salary','2021-05-10 13:16:05','etnmode3',NULL,'salary.jpeg',33),(22,'000011','2021-05-10 13:16:05','etnmode3',NULL,'000011.pdf',33),(23,'000011salary','2021-05-10 13:16:41','etnmode3',NULL,'salary.jpeg',33),(24,'000011','2021-05-10 13:16:41','etnmode3',NULL,'000011.pdf',33),(25,'000011salary','2021-05-10 13:17:17','etnmode3',NULL,'salary.jpeg',33),(26,'000011','2021-05-10 13:17:17','etnmode3',NULL,'000011.pdf',33),(27,'000011salary','2021-05-10 13:17:56','etnmode3',NULL,'salary.jpeg',33),(28,'000011','2021-05-10 13:17:56','etnmode3',NULL,'000011.pdf',33),(29,'000011salary','2021-05-10 13:18:59','etnmode3',NULL,'salary.jpeg',33),(30,'000011','2021-05-10 13:18:59','etnmode3',NULL,'000011.pdf',33),(31,'000011salary','2021-05-10 13:20:03','etnmode3',NULL,'salary.jpeg',33),(32,'000011','2021-05-10 13:20:03','etnmode3',NULL,'000011.pdf',33),(33,'000011salary','2021-05-10 13:20:46','etnmode3',NULL,'salary.jpeg',33),(34,'000011','2021-05-10 13:20:47','etnmode3',NULL,'000011.pdf',33),(35,'000011salary','2021-05-10 13:23:05','etnmode3',NULL,'salary.jpeg',33),(36,'000011','2021-05-10 13:23:06','etnmode3',NULL,'000011.pdf',33),(37,'000011salary','2021-05-10 13:23:41','etnmode3',NULL,'salary.jpeg',33),(38,'000011','2021-05-10 13:23:42','etnmode3',NULL,'000011.pdf',33),(39,'000011salary','2021-05-10 13:24:22','etnmode3',NULL,'salary.jpeg',33),(40,'000011','2021-05-10 13:24:23','etnmode3',NULL,'000011.pdf',33),(41,'000011salary','2021-05-10 13:24:57','etnmode3',NULL,'salary.jpeg',33),(42,'000011','2021-05-10 13:24:57','etnmode3',NULL,'000011.pdf',33),(43,'000011salary','2021-05-10 13:25:59','etnmode3',NULL,'salary.jpeg',33),(44,'000011','2021-05-10 13:25:59','etnmode3',NULL,'000011.pdf',33),(45,'000011salary','2021-05-10 13:29:22','etnmode3',NULL,'salary.jpeg',33),(46,'000011','2021-05-10 13:29:22','etnmode3',NULL,'000011.pdf',33),(47,'000011salary','2021-05-10 13:30:01','etnmode3',NULL,'salary.jpeg',33),(48,'000011','2021-05-10 13:30:02','etnmode3',NULL,'000011.pdf',33),(49,'000011salary','2021-05-10 13:30:46','etnmode3',NULL,'salary.jpeg',33),(50,'000011','2021-05-10 13:30:47','etnmode3',NULL,'000011.pdf',33),(51,'000011salary','2021-05-10 13:31:34','etnmode3',NULL,'salary.jpeg',33),(52,'000011','2021-05-10 13:31:35','etnmode3',NULL,'000011.pdf',33),(53,'000011salary','2021-05-10 13:32:10','etnmode3',NULL,'salary.jpeg',33),(54,'000011','2021-05-10 13:32:11','etnmode3',NULL,'000011.pdf',33),(55,'000011salary','2021-05-10 13:33:13','etnmode3',NULL,'salary.jpeg',33),(56,'000011','2021-05-10 13:33:14','etnmode3',NULL,'000011.pdf',33),(57,'000011salary','2021-05-10 13:34:04','etnmode3',NULL,'salary.jpeg',33),(58,'000011','2021-05-10 13:34:05','etnmode3',NULL,'000011.pdf',33),(59,'000011salary','2021-05-10 13:44:15','etnmode3',NULL,'salary.jpeg',33),(60,'000011','2021-05-10 13:44:15','etnmode3',NULL,'000011.pdf',33),(61,'000011salary','2021-05-10 13:48:08','etnmode3',NULL,'salary.jpeg',33),(62,'000011salary','2021-05-10 13:48:49','etnmode3',NULL,'salary.jpeg',33),(63,'000011','2021-05-10 13:48:49','etnmode3',NULL,'000011.pdf',33),(64,'000011salary','2021-05-10 13:50:54','etnmode3',NULL,'salary.jpeg',33),(65,'000011','2021-05-10 13:50:55','etnmode3',NULL,'000011.pdf',33),(66,'000011salary','2021-05-10 13:51:35','etnmode3',NULL,'salary.jpeg',33),(67,'000011','2021-05-10 13:51:36','etnmode3',NULL,'000011.pdf',33),(68,'000011salary','2021-05-10 13:52:09','etnmode3',NULL,'salary.jpeg',33),(69,'000011','2021-05-10 13:52:10','etnmode3',NULL,'000011.pdf',33),(70,'000011salary','2021-05-10 13:54:05','etnmode3',NULL,'salary.jpeg',33),(71,'000011','2021-05-10 13:54:05','etnmode3',NULL,'000011.pdf',33),(72,'000011salary','2021-05-10 13:55:28','etnmode3',NULL,'salary.jpeg',33),(73,'000011','2021-05-10 13:55:29','etnmode3',NULL,'000011.pdf',33),(74,'000011salary','2021-05-10 13:57:38','etnmode3',NULL,'salary.jpeg',33),(75,'000011','2021-05-10 13:57:39','etnmode3',NULL,'000011.pdf',33),(76,'000011salary','2021-05-10 13:58:26','etnmode3',NULL,'salary.jpeg',33),(77,'000011','2021-05-10 13:58:27','etnmode3',NULL,'000011.pdf',33),(78,'000011salary','2021-05-10 14:02:58','etnmode3',NULL,'salary.jpeg',33),(79,'000011','2021-05-10 14:02:59','etnmode3',NULL,'000011.pdf',33),(80,'000011salary','2021-05-10 14:04:47','etnmode3',NULL,'salary.jpeg',33),(81,'000011','2021-05-10 14:04:48','etnmode3',NULL,'000011.pdf',33),(82,'000011salary','2021-05-10 14:07:47','etnmode3',NULL,'salary.jpeg',33),(83,'000011','2021-05-10 14:07:47','etnmode3',NULL,'000011.pdf',33),(84,'000011salary','2021-05-10 14:11:19','etnmode3',NULL,'salary.jpeg',33),(85,'000011','2021-05-10 14:11:19','etnmode3',NULL,'000011.pdf',33),(86,'000011salary','2021-05-10 14:12:49','etnmode3',NULL,'salary.jpeg',33),(87,'000011','2021-05-10 14:12:49','etnmode3',NULL,'000011.pdf',33),(88,'000011salary','2021-05-10 14:13:44','etnmode3',NULL,'salary.jpeg',33),(89,'000011','2021-05-10 14:13:44','etnmode3',NULL,'000011.pdf',33),(90,'000011salary','2021-05-10 14:14:12','etnmode3',NULL,'salary.jpeg',33),(91,'000011','2021-05-10 14:14:12','etnmode3',NULL,'000011.pdf',33),(92,'000011salary','2021-05-10 14:15:16','etnmode3',NULL,'salary.jpeg',33),(93,'000011','2021-05-10 14:15:16','etnmode3',NULL,'000011.pdf',33),(94,'000011salary','2021-05-10 14:17:28','etnmode3',NULL,'salary.jpeg',33),(95,'000011','2021-05-10 14:17:28','etnmode3',NULL,'000011.pdf',33),(96,'000011salary','2021-05-10 14:18:11','etnmode3',NULL,'salary.jpeg',33),(97,'000011','2021-05-10 14:18:11','etnmode3',NULL,'000011.pdf',33),(98,'000011salary','2021-05-10 14:19:03','etnmode3',NULL,'salary.jpeg',33),(99,'000011','2021-05-10 14:19:04','etnmode3',NULL,'000011.pdf',33),(100,'000011salary','2021-05-10 14:22:31','etnmode3',NULL,'salary.jpeg',33),(101,'000011','2021-05-10 14:22:31','etnmode3',NULL,'000011.pdf',33),(102,'000011salary','2021-05-10 14:23:56','etnmode3',NULL,'salary.jpeg',33),(103,'000011','2021-05-10 14:23:56','etnmode3',NULL,'000011.pdf',33),(104,'000011salary','2021-05-10 14:28:00','etnmode3',NULL,'salary.jpeg',33),(105,'000011','2021-05-10 14:28:00','etnmode3',NULL,'000011.pdf',33),(106,'000011salary','2021-05-10 14:41:34','etnmode3',NULL,'salary.jpeg',33),(107,'000011','2021-05-10 14:41:35','etnmode3',NULL,'000011.pdf',33),(108,'000011salary','2021-05-10 14:43:34','etnmode3',NULL,'salary.jpeg',33),(109,'000011','2021-05-10 14:43:35','etnmode3',NULL,'000011.pdf',33),(110,'000011salary','2021-05-10 14:45:09','etnmode3',NULL,'salary.jpeg',33),(111,'000011','2021-05-10 14:45:10','etnmode3',NULL,'000011.pdf',33),(112,'000011salary','2021-05-10 14:59:51','etnmode3',NULL,'salary.jpeg',33),(113,'000011','2021-05-10 14:59:51','etnmode3',NULL,'000011.pdf',33),(114,'000011salary','2021-05-10 15:03:56','etnmode3',NULL,'salary.jpeg',33),(115,'000011','2021-05-10 15:03:57','etnmode3',NULL,'000011.pdf',33),(116,'000011salary','2021-05-10 15:05:55','etnmode3',NULL,'salary.jpeg',33),(117,'000011','2021-05-10 15:05:55','etnmode3',NULL,'000011.pdf',33),(118,'000011salary','2021-05-10 15:06:38','etnmode3',NULL,'salary.jpeg',33),(119,'000011','2021-05-10 15:06:38','etnmode3',NULL,'000011.pdf',33),(120,'000011salary','2021-05-10 15:08:43','etnmode3',NULL,'salary.jpeg',33),(121,'000011','2021-05-10 15:08:43','etnmode3',NULL,'000011.pdf',33),(122,'000011salary','2021-05-10 15:14:21','etnmode3',NULL,'salary.jpeg',33),(123,'000011','2021-05-10 15:14:21','etnmode3',NULL,'000011.pdf',33),(124,'000011salary','2021-05-10 15:15:07','etnmode3',NULL,'salary.jpeg',33),(125,'000011','2021-05-10 15:15:08','etnmode3',NULL,'000011.pdf',33),(126,'000011salary','2021-05-10 15:17:34','etnmode3',NULL,'salary.jpeg',33),(127,'000011','2021-05-10 15:17:35','etnmode3',NULL,'000011.pdf',33),(128,'000011salary','2021-05-10 15:55:41','etnmode3',NULL,'salary.jpeg',33),(129,'000011','2021-05-10 15:55:41','etnmode3',NULL,'000011.pdf',33),(130,'000011salary','2021-05-10 15:57:23','etnmode3',NULL,'salary.jpeg',33),(131,'000011','2021-05-10 15:57:24','etnmode3',NULL,'000011.pdf',33),(132,'000011salary','2021-05-10 16:15:51','etnmode3',NULL,'salary.jpeg',33),(133,'000011','2021-05-10 16:15:51','etnmode3',NULL,'000011.pdf',33),(134,'000011salary','2021-05-10 16:17:50','etnmode3',NULL,'salary.jpeg',33),(135,'000011','2021-05-10 16:17:51','etnmode3',NULL,'000011.pdf',33),(136,'000011salary','2021-05-10 16:18:15','etnmode3',NULL,'salary.jpeg',33),(137,'000011','2021-05-10 16:18:15','etnmode3',NULL,'000011.pdf',33),(138,'000011salary','2021-05-10 16:18:59','etnmode3',NULL,'salary.jpeg',33),(139,'000011','2021-05-10 16:19:00','etnmode3',NULL,'000011.pdf',33),(140,'000011salary','2021-05-10 16:20:12','etnmode3',NULL,'salary.jpeg',33),(141,'000011','2021-05-10 16:20:13','etnmode3',NULL,'000011.pdf',33),(142,'000011salary','2021-05-10 16:21:24','etnmode3',NULL,'salary.jpeg',33),(143,'000011','2021-05-10 16:21:25','etnmode3',NULL,'000011.pdf',33),(144,'000011salary','2021-05-10 16:21:51','etnmode3',NULL,'salary.jpeg',33),(145,'000011','2021-05-10 16:21:51','etnmode3',NULL,'000011.pdf',33),(146,'000011salary','2021-05-10 16:22:11','etnmode3',NULL,'salary.jpeg',33),(147,'000011','2021-05-10 16:22:12','etnmode3',NULL,'000011.pdf',33),(148,'000011salary','2021-05-10 16:22:43','etnmode3',NULL,'salary.jpeg',33),(149,'000011','2021-05-10 16:22:44','etnmode3',NULL,'000011.pdf',33),(150,'000011salary','2021-05-10 16:23:25','etnmode3',NULL,'salary.jpeg',33),(151,'000011','2021-05-10 16:23:25','etnmode3',NULL,'000011.pdf',33),(152,'000011salary','2021-05-10 16:24:33','etnmode3',NULL,'salary.jpeg',33),(153,'000011','2021-05-10 16:24:34','etnmode3',NULL,'000011.pdf',33),(154,'000011salary','2021-05-10 16:25:26','etnmode3',NULL,'salary.jpeg',33),(155,'000011','2021-05-10 16:25:27','etnmode3',NULL,'000011.pdf',33),(156,'000011salary','2021-05-10 16:30:13','etnmode3',NULL,'salary.jpeg',33),(157,'000011','2021-05-10 16:30:13','etnmode3',NULL,'000011.pdf',33),(158,'000011salary','2021-05-10 16:31:28','etnmode3',NULL,'salary.jpeg',33),(159,'000011','2021-05-10 16:31:28','etnmode3',NULL,'000011.pdf',33),(160,'000011salary','2021-05-10 16:32:36','etnmode3',NULL,'salary.jpeg',33),(161,'000011','2021-05-10 16:32:37','etnmode3',NULL,'000011.pdf',33),(162,'000011salary','2021-05-10 16:33:12','etnmode3',NULL,'salary.jpeg',33),(163,'000011','2021-05-10 16:33:13','etnmode3',NULL,'000011.pdf',33),(164,'000011salary','2021-05-10 16:34:48','etnmode3',NULL,'salary.jpeg',33),(165,'000011','2021-05-10 16:34:48','etnmode3',NULL,'000011.pdf',33),(166,'000011salary','2021-05-10 16:35:16','etnmode3',NULL,'salary.jpeg',33),(167,'000011','2021-05-10 16:35:17','etnmode3',NULL,'000011.pdf',33),(168,'000011salary','2021-05-10 16:35:42','etnmode3',NULL,'salary.jpeg',33),(169,'000011','2021-05-10 16:35:43','etnmode3',NULL,'000011.pdf',33),(170,'000011salary','2021-05-10 16:37:32','etnmode3',NULL,'salary.jpeg',33),(171,'000011','2021-05-10 16:37:33','etnmode3',NULL,'000011.pdf',33),(172,'000011salary','2021-05-10 16:38:06','etnmode3',NULL,'salary.jpeg',33),(173,'000011','2021-05-10 16:38:07','etnmode3',NULL,'000011.pdf',33),(174,'000011salary','2021-05-10 16:38:55','etnmode3',NULL,'salary.jpeg',33),(175,'000011','2021-05-10 16:38:55','etnmode3',NULL,'000011.pdf',33),(176,'000011salary','2021-05-10 16:40:20','etnmode3',NULL,'salary.jpeg',33),(177,'000011','2021-05-10 16:40:21','etnmode3',NULL,'000011.pdf',33),(178,'000011salary','2021-05-10 16:40:56','etnmode3',NULL,'salary.jpeg',33),(179,'000011','2021-05-10 16:40:57','etnmode3',NULL,'000011.pdf',33),(180,'000011salary','2021-05-10 16:41:51','etnmode3',NULL,'salary.jpeg',33),(181,'000011','2021-05-10 16:41:51','etnmode3',NULL,'000011.pdf',33),(182,'000011salary','2021-05-10 16:42:18','etnmode3',NULL,'salary.jpeg',33),(183,'000011','2021-05-10 16:42:18','etnmode3',NULL,'000011.pdf',33),(184,'000011salary','2021-05-10 16:42:53','etnmode3',NULL,'salary.jpeg',33),(185,'000011','2021-05-10 16:42:54','etnmode3',NULL,'000011.pdf',33),(186,'000011salary','2021-05-10 16:43:16','etnmode3',NULL,'salary.jpeg',33),(187,'000011','2021-05-10 16:43:17','etnmode3',NULL,'000011.pdf',33),(188,'000011salary','2021-05-10 16:44:16','etnmode3',NULL,'salary.jpeg',33),(189,'000011','2021-05-10 16:44:16','etnmode3',NULL,'000011.pdf',33),(190,'000011salary','2021-05-10 16:44:51','etnmode3',NULL,'salary.jpeg',33),(191,'000011','2021-05-10 16:44:51','etnmode3',NULL,'000011.pdf',33),(192,'000011salary','2021-05-10 16:45:27','etnmode3',NULL,'salary.jpeg',33),(193,'000011','2021-05-10 16:45:27','etnmode3',NULL,'000011.pdf',33),(194,'000011salary','2021-05-10 16:46:32','etnmode3',NULL,'salary.jpeg',33),(195,'000011','2021-05-10 16:46:32','etnmode3',NULL,'000011.pdf',33),(196,'000011salary','2021-05-10 16:47:38','etnmode3',NULL,'salary.jpeg',33),(197,'000011','2021-05-10 16:47:39','etnmode3',NULL,'000011.pdf',33),(198,'000011salary','2021-05-10 16:51:12','etnmode3',NULL,'salary.jpeg',33),(199,'000011','2021-05-10 16:51:12','etnmode3',NULL,'000011.pdf',33),(200,'000011salary','2021-05-10 16:59:22','etnmode3',NULL,'salary.jpeg',33),(201,'000011','2021-05-10 16:59:23','etnmode3',NULL,'000011.pdf',33),(202,'000011salary','2021-05-10 16:59:44','etnmode3',NULL,'salary.jpeg',33),(203,'000011','2021-05-10 16:59:44','etnmode3',NULL,'000011.pdf',33),(204,'000011salary','2021-05-10 17:00:08','etnmode3',NULL,'salary.jpeg',33),(205,'000011','2021-05-10 17:00:09','etnmode3',NULL,'000011.pdf',33),(206,'000011salary','2021-05-10 17:01:06','etnmode3',NULL,'salary.jpeg',33),(207,'000011','2021-05-10 17:01:06','etnmode3',NULL,'000011.pdf',33),(208,'000011salary','2021-05-10 17:02:13','etnmode3',NULL,'salary.jpeg',33),(209,'000011','2021-05-10 17:02:13','etnmode3',NULL,'000011.pdf',33),(210,'000011salary','2021-05-10 17:04:46','etnmode3',NULL,'salary.jpeg',33),(211,'000011','2021-05-10 17:04:47','etnmode3',NULL,'000011.pdf',33),(212,'000011salary','2021-05-10 17:05:37','etnmode3',NULL,'salary.jpeg',33),(213,'000011','2021-05-10 17:05:37','etnmode3',NULL,'000011.pdf',33),(214,'000011salary','2021-05-10 17:06:23','etnmode3',NULL,'salary.jpeg',33),(215,'000011','2021-05-10 17:06:24','etnmode3',NULL,'000011.pdf',33),(216,'000011salary','2021-05-10 17:08:24','etnmode3',NULL,'salary.jpeg',33),(217,'000011','2021-05-10 17:08:24','etnmode3',NULL,'000011.pdf',33),(218,'000011salary','2021-05-10 17:08:59','etnmode3',NULL,'salary.jpeg',33),(219,'000011','2021-05-10 17:08:59','etnmode3',NULL,'000011.pdf',33),(220,'000011salary','2021-05-10 17:09:34','etnmode3',NULL,'salary.jpeg',33),(221,'000011','2021-05-10 17:09:35','etnmode3',NULL,'000011.pdf',33),(222,'000011salary','2021-05-10 17:10:06','etnmode3',NULL,'salary.jpeg',33),(223,'000011','2021-05-10 17:10:07','etnmode3',NULL,'000011.pdf',33),(224,'000011salary','2021-05-10 17:10:36','etnmode3',NULL,'salary.jpeg',33),(225,'000011','2021-05-10 17:10:36','etnmode3',NULL,'000011.pdf',33),(226,'000011salary','2021-05-10 17:10:58','etnmode3',NULL,'salary.jpeg',33),(227,'000011','2021-05-10 17:10:58','etnmode3',NULL,'000011.pdf',33),(228,'000011salary','2021-05-10 17:13:44','etnmode3',NULL,'salary.jpeg',33),(229,'000011','2021-05-10 17:13:45','etnmode3',NULL,'000011.pdf',33),(230,'000011salary','2021-05-10 17:14:05','etnmode3',NULL,'salary.jpeg',33),(231,'000011','2021-05-10 17:14:05','etnmode3',NULL,'000011.pdf',33),(232,'000011salary','2021-05-10 17:17:01','etnmode3',NULL,'salary.jpeg',33),(233,'000011','2021-05-10 17:17:01','etnmode3',NULL,'000011.pdf',33),(234,'000011salary','2021-05-10 17:18:05','etnmode3',NULL,'salary.jpeg',33),(235,'000011','2021-05-10 17:18:06','etnmode3',NULL,'000011.pdf',33),(236,'000011salary','2021-05-10 17:18:33','etnmode3',NULL,'salary.jpeg',33),(237,'000011','2021-05-10 17:18:34','etnmode3',NULL,'000011.pdf',33),(238,'000011salary','2021-05-11 13:06:50','etnmode3',NULL,'salary.jpeg',33),(239,'000011','2021-05-11 13:06:52','etnmode3',NULL,'000011.pdf',33),(240,'000012salary','2021-05-11 13:09:58','etnmode3',NULL,'salary.jpeg',33),(241,'000012','2021-05-11 13:09:59','etnmode3',NULL,'000012.pdf',33),(242,'000013salary','2021-05-11 13:12:46','etnmode3',NULL,'salary.jpeg',33),(243,'000013','2021-05-11 13:12:47','etnmode3',NULL,'000013.pdf',33),(244,'000014salary','2021-05-11 17:03:12','etnmode3',NULL,'salary.jpeg',33),(245,'000014','2021-05-11 17:03:14','etnmode3',NULL,'000014.pdf',33),(246,'000015salary','2021-05-11 17:04:10','etnmode3',NULL,'salary.jpeg',33),(247,'000015','2021-05-11 17:04:10','etnmode3',NULL,'000015.pdf',33),(248,'000016salary','2021-05-11 17:04:43','etnmode3',NULL,'salary.jpeg',33),(249,'000016','2021-05-11 17:04:43','etnmode3',NULL,'000016.pdf',33),(250,'000017salary','2021-05-11 17:05:18','etnmode3',NULL,'salary.jpeg',33),(251,'000017','2021-05-11 17:05:18','etnmode3',NULL,'000017.pdf',33),(252,'000018salary','2021-05-11 17:05:53','etnmode3',NULL,'salary.jpeg',33),(253,'000018','2021-05-11 17:05:54','etnmode3',NULL,'000018.pdf',33),(254,'000019salary','2021-05-11 17:06:59','etnmode3',NULL,'salary.jpeg',33),(255,'000019','2021-05-11 17:07:00','etnmode3',NULL,'000019.pdf',33),(256,'000020salary','2021-05-11 17:09:14','etnmode3',NULL,'salary.jpeg',33),(257,'000020','2021-05-11 17:09:15','etnmode3',NULL,'000020.pdf',33),(258,'000021salary','2021-05-11 17:10:11','etnmode3',NULL,'salary.jpeg',33),(259,'000021','2021-05-11 17:10:11','etnmode3',NULL,'000021.pdf',33),(260,'000022salary','2021-05-11 17:10:51','etnmode3',NULL,'salary.jpeg',33),(261,'000022','2021-05-11 17:10:52','etnmode3',NULL,'000022.pdf',33),(262,'000023salary','2021-05-11 17:11:55','etnmode3',NULL,'salary.jpeg',33),(263,'000023','2021-05-11 17:11:56','etnmode3',NULL,'000023.pdf',33),(264,'000024salary','2021-05-12 11:06:11','etnmode3',NULL,'salary.jpeg',39),(265,'000024','2021-05-12 11:06:14','etnmode3',NULL,'000024.pdf',39),(266,'000025salary','2021-05-12 16:54:25','etnmode3',NULL,'salary.jpeg',40),(267,'000025','2021-05-12 16:54:26','etnmode3',NULL,'000025.pdf',40);
/*!40000 ALTER TABLE `doclistdetail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doclistmaster`
--

DROP TABLE IF EXISTS `doclistmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doclistmaster` (
  `doc_no` varchar(50) CHARACTER SET utf8 NOT NULL,
  `docgrp_no` varchar(50) CHARACTER SET utf8 NOT NULL,
  `doc_filename` varchar(200) CHARACTER SET utf8 NOT NULL,
  `doc_type` varchar(20) CHARACTER SET utf8 NOT NULL,
  `source_ref` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `doc_address` text CHARACTER SET utf8 NOT NULL,
  `member_no` char(8) CHARACTER SET utf8 NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `doc_status` enum('0','1','-9') CHARACTER SET utf8 NOT NULL DEFAULT '1',
  PRIMARY KEY (`doc_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doclistmaster`
--

LOCK TABLES `doclistmaster` WRITE;
/*!40000 ALTER TABLE `doclistmaster` DISABLE KEYS */;
INSERT INTO `doclistmaster` VALUES ('000001','10','000001','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000001.pdf?v=1614240775','etnmode1','2021-02-25 15:12:57','2021-02-25 15:12:57','1'),('000003','10','000003','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000003.pdf?v=1614243409','etnmode1','2021-02-25 15:56:49','2021-02-25 15:56:49','1'),('000004','10','000004','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000004.pdf?v=1614764927','dev@mode','2021-03-03 16:48:47','2021-03-03 16:48:47','1'),('000005','10','000005','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000005.pdf?v=1615172920','dev@mode','2021-03-08 10:08:41','2021-03-08 10:08:41','1'),('000006','10','000006','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000006.pdf?v=1617246700','etnmode2','2021-04-01 10:11:42','2021-04-01 10:11:42','1'),('000007','10','000007','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000007.pdf?v=1620618647','etnmode3','2021-05-10 10:50:49','2021-05-10 10:50:49','1'),('000008','10','000008','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000008.pdf?v=1620618710','etnmode3','2021-05-10 10:51:51','2021-05-10 10:51:51','1'),('000009','10','000009','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000009.pdf?v=1620619629','etnmode3','2021-05-10 11:07:09','2021-05-10 11:07:09','1'),('000009salary','10SALARY','000009salary','jpeg',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000009/salary.jpeg','etnmode3','2021-05-10 11:07:09','2021-05-10 11:07:09','1'),('000010','10','000010','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000010.pdf?v=1620620730','etnmode3','2021-05-10 11:25:31','2021-05-10 11:25:31','1'),('000010salary','10SALARY','000010salary','jpeg',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000010/salary.jpeg','etnmode3','2021-05-10 11:25:30','2021-05-10 11:25:30','1'),('000011','10','000011','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000011.pdf?v=1620627108','etnmode3','2021-05-10 13:11:48','2021-05-10 13:11:48','1'),('000011salary','10SALARY','000011salary','jpeg',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000011/salary.jpeg','etnmode3','2021-05-10 13:11:48','2021-05-10 13:11:48','1'),('000012','10','000012','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000012.pdf?v=1620713398','etnmode3','2021-05-11 13:09:59','2021-05-11 13:09:59','1'),('000012salary','10SALARY','000012salary','jpeg',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000012/salary.jpeg','etnmode3','2021-05-11 13:09:58','2021-05-11 13:09:58','1'),('000013','10','000013','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000013.pdf?v=1620713566','etnmode3','2021-05-11 13:12:47','2021-05-11 13:12:47','1'),('000013salary','10SALARY','000013salary','jpeg',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000013/salary.jpeg','etnmode3','2021-05-11 13:12:46','2021-05-11 13:12:46','1'),('000014','10','000014','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000014.pdf?v=1620727392','etnmode3','2021-05-11 17:03:14','2021-05-11 17:03:14','1'),('000014salary','10SALARY','000014salary','jpeg',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000014/salary.jpeg','etnmode3','2021-05-11 17:03:12','2021-05-11 17:03:12','1'),('000015','10','000015','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000015.pdf?v=1620727450','etnmode3','2021-05-11 17:04:10','2021-05-11 17:04:10','1'),('000015salary','10SALARY','000015salary','jpeg',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000015/salary.jpeg','etnmode3','2021-05-11 17:04:10','2021-05-11 17:04:10','1'),('000016','10','000016','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000016.pdf?v=1620727483','etnmode3','2021-05-11 17:04:43','2021-05-11 17:04:43','1'),('000016salary','10SALARY','000016salary','jpeg',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000016/salary.jpeg','etnmode3','2021-05-11 17:04:43','2021-05-11 17:04:43','1'),('000017','10','000017','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000017.pdf?v=1620727518','etnmode3','2021-05-11 17:05:18','2021-05-11 17:05:18','1'),('000017salary','10SALARY','000017salary','jpeg',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000017/salary.jpeg','etnmode3','2021-05-11 17:05:18','2021-05-11 17:05:18','1'),('000018','10','000018','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000018.pdf?v=1620727553','etnmode3','2021-05-11 17:05:54','2021-05-11 17:05:54','1'),('000018salary','10SALARY','000018salary','jpeg',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000018/salary.jpeg','etnmode3','2021-05-11 17:05:53','2021-05-11 17:05:53','1'),('000019','10','000019','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000019.pdf?v=1620727619','etnmode3','2021-05-11 17:07:00','2021-05-11 17:07:00','1'),('000019salary','10SALARY','000019salary','jpeg',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000019/salary.jpeg','etnmode3','2021-05-11 17:06:59','2021-05-11 17:06:59','1'),('000020','10','000020','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000020.pdf?v=1620727754','etnmode3','2021-05-11 17:09:15','2021-05-11 17:09:15','1'),('000020salary','10SALARY','000020salary','jpeg',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000020/salary.jpeg','etnmode3','2021-05-11 17:09:14','2021-05-11 17:09:14','1'),('000021','10','000021','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000021.pdf?v=1620727811','etnmode3','2021-05-11 17:10:11','2021-05-11 17:10:11','1'),('000021salary','10SALARY','000021salary','jpeg',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000021/salary.jpeg','etnmode3','2021-05-11 17:10:11','2021-05-11 17:10:11','1'),('000022','10','000022','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000022.pdf?v=1620727851','etnmode3','2021-05-11 17:10:52','2021-05-11 17:10:52','1'),('000022salary','10SALARY','000022salary','jpeg',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000022/salary.jpeg','etnmode3','2021-05-11 17:10:51','2021-05-11 17:10:51','1'),('000023','10','000023','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000023.pdf?v=1620727915','etnmode3','2021-05-11 17:11:56','2021-05-11 17:11:56','1'),('000023salary','10SALARY','000023salary','jpeg',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000023/salary.jpeg','etnmode3','2021-05-11 17:11:55','2021-05-11 17:11:55','1'),('000024','10','000024','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000024.pdf?v=1620792372','etnmode3','2021-05-12 11:06:14','2021-05-12 11:06:14','1'),('000024salary','10SALARY','000024salary','jpeg',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000024/salary.jpeg','etnmode3','2021-05-12 11:06:11','2021-05-12 11:06:11','1'),('000025','10','000025','pdf',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000025.pdf?v=1620813265','etnmode3','2021-05-12 16:54:26','2021-05-12 16:54:26','1'),('000025salary','10SALARY','000025salary','jpeg',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000025/salary.jpeg','etnmode3','2021-05-12 16:54:25','2021-05-12 16:54:25','1');
/*!40000 ALTER TABLE `doclistmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `docsystemprefix`
--

DROP TABLE IF EXISTS `docsystemprefix`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `docsystemprefix` (
  `id_sysprefix` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `prefix_docno` varchar(20) CHARACTER SET utf8 NOT NULL,
  `menu_component` varchar(50) CHARACTER SET utf8 NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_use` enum('0','1') CHARACTER SET utf8 NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_sysprefix`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `docsystemprefix`
--

LOCK TABLES `docsystemprefix` WRITE;
/*!40000 ALTER TABLE `docsystemprefix` DISABLE KEYS */;
INSERT INTO `docsystemprefix` VALUES (1,'YA,R','LoanRequestForm','2020-12-16 17:23:18','2020-12-17 10:43:49','1');
/*!40000 ALTER TABLE `docsystemprefix` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `docuploadconstant`
--

DROP TABLE IF EXISTS `docuploadconstant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `docuploadconstant` (
  `id_upload` int(12) NOT NULL AUTO_INCREMENT,
  `upload_system` varchar(50) NOT NULL,
  `upload_system_desc` varchar(250) DEFAULT NULL,
  `menu_component` varchar(50) NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_use` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_upload`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `docuploadconstant`
--

LOCK TABLES `docuploadconstant` WRITE;
/*!40000 ALTER TABLE `docuploadconstant` DISABLE KEYS */;
/*!40000 ALTER TABLE `docuploadconstant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcacceptpolicy`
--

DROP TABLE IF EXISTS `gcacceptpolicy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcacceptpolicy` (
  `id_accept` int(11) NOT NULL AUTO_INCREMENT,
  `member_no` varchar(10) DEFAULT NULL,
  `is_accept` enum('0','1') NOT NULL DEFAULT '1' COMMENT '0 = ไม่ยอมรับ, 1 = ยอมรับ',
  `accept_date` datetime NOT NULL DEFAULT current_timestamp(),
  `cancel_date` datetime DEFAULT NULL,
  `url_policy` text NOT NULL,
  `policy_id` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_accept`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcacceptpolicy`
--

LOCK TABLES `gcacceptpolicy` WRITE;
/*!40000 ALTER TABLE `gcacceptpolicy` DISABLE KEYS */;
INSERT INTO `gcacceptpolicy` VALUES (1,'etnmode1','1','2022-06-06 10:41:54',NULL,'https://policy.thaicoop.co/index_v1.html?coop=sps','v1'),(2,'00004378','1','2022-06-08 13:49:15',NULL,'https://policy.thaicoop.co/index_v1.html?coop=sps','v1'),(3,'00004491','1','2022-06-08 13:51:10',NULL,'https://policy.thaicoop.co/index_v1.html?coop=sps','v1'),(4,'00004408','1','2022-06-09 06:58:10',NULL,'https://policy.thaicoop.co/index_v1.html?coop=sps','v1'),(5,'00005367','1','2022-06-10 08:41:39',NULL,'https://policy.thaicoop.co/index_v1.html?coop=sps','v1'),(6,'00003823','1','2022-06-11 14:05:48',NULL,'https://policy.thaicoop.co/index_v1.html?coop=sps','v1'),(7,'00005357','1','2022-06-11 20:27:06',NULL,'https://policy.thaicoop.co/index_v1.html?coop=sps','v1'),(8,'00003076','1','2022-06-13 14:03:16',NULL,'https://policy.thaicoop.co/index_v1.html?coop=sps','v1'),(9,'00003171','1','2022-06-14 06:17:10',NULL,'https://policy.thaicoop.co/index_v1.html?coop=sps','v1'),(10,'00002539','1','2022-06-17 12:44:36',NULL,'https://policy.thaicoop.co/index_v1.html?coop=sps','v1'),(11,'00002232','1','2022-06-27 11:50:19',NULL,'https://policy.thaicoop.co/index_v1.html?coop=sps','v1'),(12,'00004356','1','2022-07-01 21:34:23',NULL,'https://policy.thaicoop.co/index_v1.html?coop=sps','v1'),(13,'00003089','1','2022-07-04 14:00:15',NULL,'https://policy.thaicoop.co/index_v1.html?coop=sps','v1'),(14,'00002949','1','2022-07-15 17:29:13',NULL,'https://policy.thaicoop.co/index_v1.html?coop=sps','v1');
/*!40000 ALTER TABLE `gcacceptpolicy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcallowmemberreqloan`
--

DROP TABLE IF EXISTS `gcallowmemberreqloan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcallowmemberreqloan` (
  `member_no` char(8) NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `update_username` varchar(20) NOT NULL,
  `is_allow` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`member_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcallowmemberreqloan`
--

LOCK TABLES `gcallowmemberreqloan` WRITE;
/*!40000 ALTER TABLE `gcallowmemberreqloan` DISABLE KEYS */;
/*!40000 ALTER TABLE `gcallowmemberreqloan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcannounce`
--

DROP TABLE IF EXISTS `gcannounce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcannounce` (
  `id_announce` mediumint(8) NOT NULL AUTO_INCREMENT,
  `announce_cover` text DEFAULT NULL,
  `announce_title` varchar(200) DEFAULT NULL,
  `announce_detail` longtext DEFAULT NULL,
  `announce_html` longtext DEFAULT NULL,
  `announce_date` datetime NOT NULL DEFAULT current_timestamp(),
  `effect_date` datetime DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_update` enum('0','1') NOT NULL DEFAULT '0',
  `is_show_between_due` enum('0','1') NOT NULL DEFAULT '0',
  `priority` enum('low','mid','high','ask') NOT NULL,
  `flag_granted` enum('all','member','anonymous') NOT NULL DEFAULT 'member',
  `first_time` enum('1','0') NOT NULL DEFAULT '0',
  `is_check` enum('1','0') NOT NULL DEFAULT '0',
  `check_text` varchar(200) DEFAULT NULL,
  `accept_text` varchar(50) DEFAULT NULL,
  `cancel_text` varchar(50) DEFAULT NULL,
  `username` varchar(20) NOT NULL,
  PRIMARY KEY (`id_announce`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcannounce`
--

LOCK TABLES `gcannounce` WRITE;
/*!40000 ALTER TABLE `gcannounce` DISABLE KEYS */;
/*!40000 ALTER TABLE `gcannounce` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcbankconstant`
--

DROP TABLE IF EXISTS `gcbankconstant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcbankconstant` (
  `id_bankconstant` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_cycle` enum('day','month','year','time') NOT NULL DEFAULT 'time',
  `max_numof_deposit` varchar(20) NOT NULL DEFAULT '-1',
  `max_numof_withdraw` varchar(20) NOT NULL DEFAULT '-1',
  `min_deposit` varchar(20) NOT NULL DEFAULT '-1',
  `max_deposit` varchar(20) NOT NULL DEFAULT '-1',
  `min_withdraw` varchar(20) NOT NULL DEFAULT '-1',
  `max_withdraw` varchar(20) NOT NULL DEFAULT '-1',
  `each_bank` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_bankconstant`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcbankconstant`
--

LOCK TABLES `gcbankconstant` WRITE;
/*!40000 ALTER TABLE `gcbankconstant` DISABLE KEYS */;
/*!40000 ALTER TABLE `gcbankconstant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcbankconstantmapping`
--

DROP TABLE IF EXISTS `gcbankconstantmapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcbankconstantmapping` (
  `id_bankconstantmapping` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id_bankconstant` mediumint(8) NOT NULL,
  `bank_code` char(3) NOT NULL,
  `is_use` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_bankconstantmapping`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcbankconstantmapping`
--

LOCK TABLES `gcbankconstantmapping` WRITE;
/*!40000 ALTER TABLE `gcbankconstantmapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `gcbankconstantmapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcbindaccount`
--

DROP TABLE IF EXISTS `gcbindaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcbindaccount` (
  `id_bindaccount` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sigma_key` char(36) NOT NULL,
  `member_no` char(8) NOT NULL,
  `deptaccount_no_coop` varchar(15) NOT NULL,
  `deptaccount_no_bank` varchar(15) DEFAULT NULL,
  `citizen_id` char(13) NOT NULL,
  `mobile_no` char(10) DEFAULT NULL,
  `bank_account_name` varchar(100) NOT NULL,
  `bank_account_name_en` varchar(100) NOT NULL,
  `bank_code` char(3) NOT NULL,
  `consent_date` datetime NOT NULL DEFAULT current_timestamp(),
  `bind_date` datetime DEFAULT NULL,
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `unbind_date` datetime DEFAULT NULL,
  `bindaccount_status` enum('0','1','8','-9') NOT NULL DEFAULT '8',
  `id_token` mediumint(8) unsigned NOT NULL,
  `account_payfee` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id_bindaccount`),
  KEY `FK_BIND_IN_DEVICE` (`id_token`),
  KEY `FK_BANK_CODE_MATCH` (`bank_code`),
  KEY `sigma_key` (`sigma_key`),
  KEY `FK_MEMBER_BIND_ACC` (`member_no`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcbindaccount`
--

LOCK TABLES `gcbindaccount` WRITE;
/*!40000 ALTER TABLE `gcbindaccount` DISABLE KEYS */;
INSERT INTO `gcbindaccount` VALUES (4,'113e2df9-ef7e-4665-b737-0c5785907e90','00004491','00004491','8500242248','3340700799259',NULL,'นายสุชาติ ชนะมี','นายสุชาติ ชนะมี','006','2021-12-08 22:06:54','2021-12-08 22:06:54','2021-12-08 22:06:54',NULL,'1',3,NULL),(5,'f3164d11-f430-4a8a-b851-713de4b46839','00004378','00004378','9851006637','3341601230321',NULL,'นางสาวอุณาโลม พิลาชัย','นางสาวอุณาโลม พิลาชัย','006','2022-05-06 16:51:54','2022-05-06 16:51:54','2022-05-06 16:51:54',NULL,'1',6,NULL),(6,'d06adcb0-c9da-47f5-8b96-7a12901030de','00002232','00002232','3131104589','3349900414014',NULL,'นางฤดี แก้วคำไสย์','นางฤดี แก้วคำไสย์','006','2022-05-17 12:42:25','2022-05-17 12:42:25','2022-05-17 12:42:25',NULL,'1',61,NULL),(7,'1217736f-bccb-4a72-8662-4dc169085afa','00003171','00003171','3220492614','3341100585933',NULL,'นายพงษ์ศักดิ์ ศรีสุข','นายพงษ์ศักดิ์ ศรีสุข','006','2022-05-17 12:43:01','2022-05-17 12:43:01','2022-05-17 12:43:01',NULL,'1',60,NULL),(8,'b6bdcc77-b80b-4124-b48e-cce6e1895a0e','00003089','00003089','3131411724','3340400759936',NULL,'นายพรายจุมพล สายเสมา','นายพรายจุมพล สายเสมา','006','2022-05-17 12:43:07','2022-05-17 12:43:07','2022-05-17 12:43:07',NULL,'1',63,NULL),(9,'aff73fb2-4f5d-4822-b2b0-f03efe134f50','00003076','00003076','4520174716','3349900520442',NULL,'นางวิไล สมนึก','นางวิไล สมนึก','006','2022-05-17 14:18:11','2022-05-17 14:18:11','2022-05-17 14:18:11',NULL,'1',68,NULL),(10,'a315ecf8-9872-4b83-b5f1-03dd91aca5b2','00002799','00002799','9841238233','3349800036387',NULL,'นางสุดา เชื้อสิงห์','นางสุดา เชื้อสิงห์','006','2022-05-17 14:26:36','2022-05-17 14:26:36','2022-05-17 14:26:36',NULL,'1',64,NULL),(11,'b6798936-081b-4eb2-b37b-c5bb5ad03124','00005367','00005367','9835118337','1349900677167',NULL,'นางสาวฑุลิกา รูปทอง','นางสาวฑุลิกา รูปทอง','006','2022-05-17 15:55:45','2022-05-17 15:55:45','2022-05-19 16:02:51','2022-05-19 16:02:51','-9',59,NULL),(12,'99033118-5f16-403d-b081-6aace2ce2abf','00005367','00005367','7730241242','1349900677167',NULL,'นางสาวฑุลิกา รูปทอง','นางสาวฑุลิกา รูปทอง','006','2022-05-19 16:03:32','2022-05-19 16:03:32','2022-05-24 14:34:09','2022-05-24 14:34:09','-9',59,NULL),(13,'1edbe0ae-7a8b-4cf0-8b4e-35bc9372a44d','00005367','00005367','7730241242','1349900677167',NULL,'นางสาวฑุลิกา รูปทอง','นางสาวฑุลิกา รูปทอง','006','2022-05-24 14:34:48','2022-05-24 14:34:48','2022-05-25 14:02:57','2022-05-25 14:02:57','-9',59,NULL),(14,'aa837b5e-08d6-4363-ba44-7db38af55b9b','00005367','00005367','9835118337','1349900677167',NULL,'นางสาวฑุลิกา รูปทอง','นางสาวฑุลิกา รูปทอง','006','2022-05-25 14:03:53','2022-05-25 14:03:53','2022-05-25 14:04:59','2022-05-25 14:04:59','-9',59,NULL),(15,'74f20ae0-9483-4c20-ab6a-b9527ee17050','00005367','00005367','7730241242','1349900677167',NULL,'นางสาวฑุลิกา รูปทอง','นางสาวฑุลิกา รูปทอง','006','2022-05-25 14:09:07','2022-05-25 14:09:07','2022-07-07 15:29:09','2022-07-07 15:29:09','-9',59,NULL),(16,'30224aa9-0fc7-4b32-b045-9fd76c1b8215','00005367','00005367','7730241242','1349900677167',NULL,'นางสาวฑุลิกา รูปทอง','นางสาวฑุลิกา รูปทอง','006','2022-07-07 15:30:10','2022-07-07 15:30:10','2022-07-07 15:30:10',NULL,'1',59,NULL);
/*!40000 ALTER TABLE `gcbindaccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcconstant`
--

DROP TABLE IF EXISTS `gcconstant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcconstant` (
  `id_constant` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `constant_name` varchar(50) NOT NULL,
  `constant_desc` varchar(200) DEFAULT NULL,
  `constant_value` varchar(20) NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_use` enum('0','1','-9') NOT NULL DEFAULT '1',
  `is_dropdown` enum('0','1') NOT NULL DEFAULT '0',
  `initial_value` longtext DEFAULT NULL,
  PRIMARY KEY (`id_constant`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcconstant`
--

LOCK TABLES `gcconstant` WRITE;
/*!40000 ALTER TABLE `gcconstant` DISABLE KEYS */;
INSERT INTO `gcconstant` VALUES (1,'limit_stmshare','แสดงรายการเคลื่อนไหวหุ้นมากสุด (เดือน)','24','2019-07-26 10:29:58','2020-03-23 16:03:14','1','0',NULL),(2,'dep_format','รูปแบบการแสดงเลขบัญชีเงินฝากสหกรณ์','xxx-xx-xxxxx','2019-07-26 16:01:41','2019-12-10 20:40:28','1','0',NULL),(3,'loan_format','รูปแบบการแสดงเลขสัญญาเงินกู้','xxxx/xxxxxx','2019-07-30 11:49:38','2020-01-22 11:21:09','-9','0',NULL),(4,'limit_stmdeposit','แสดงรายการเคลื่อนไหวเงินฝากมากสุด (เดือน)','24','2019-07-30 13:32:19','2019-12-10 20:57:13','1','0',NULL),(5,'limit_stmloan','แสดงรายการเคลื่อนไหวเงินกู้มากสุด (เดือน)','24','2019-07-30 13:32:19','2020-05-20 17:16:56','1','0',NULL),(6,'limit_dividend','แสดงรายการปีปันผลมากสุด (ปี)','3','2019-07-31 09:46:52','2019-07-31 09:46:52','1','0',NULL),(7,'limit_kpmonth','แสดงรายการเคลื่อนไหวเรียกเก็บประจำเดือน (งวด)','12','2019-07-31 15:32:41','2020-04-02 13:57:47','1','0',NULL),(8,'dateshow_kpmonth','วันที่ที่ต้องการแสดงรายการเรียกเก็บของเดือนนั้น','1','2019-07-31 15:37:20','2020-04-02 14:22:23','1','0',NULL),(9,'hidden_dep','รูปแบบการซ่อนเลขบัญชีเงินฝาก x = ปกติ h = ซ่อน','hhh-xx-xxxhh','2019-09-12 10:22:17','2019-09-12 10:22:17','1','0',NULL),(11,'limit_stmassist','แสดงรายการเคลื่อนไหวสวัสดิการมากสุด (เดือน)','100','2019-11-11 10:19:42','2019-11-25 23:10:14','1','0',NULL),(12,'cal_start_pay_date','วันที่เริ่มชำระเงินกู้','next','2019-11-13 09:31:07','2020-05-20 17:15:32','1','1','{\"this\" : \"คิดเดือนนี้\",\"next\" : \"คิดเดือนถัดไป\"}'),(13,'duration_otp_expire','ระยะเวลาหมดอายุของ OTP (นาที)','5','2019-12-09 15:06:51','2020-03-23 13:24:33','1','0',NULL),(14,'limit_amount_transaction','วงเงินสูงสุดในการถอนเงินออกจากบัญชีสหกรณ์','2000000','2019-12-26 16:21:14','2020-04-29 13:43:43','1','0',NULL),(16,'include_penalty','หักค่าปรับในบัญชีหรือยอดทำรายการ','1','2020-01-14 11:09:25','2020-04-27 11:55:19','1','1','{\"1\" : \"หักค่าปรับในบัญชี\",\"2\" : \"หักในยอดทำรายการ\"}'),(17,'limit_fetch_stm_loan','แสดงข้อมูลรายการเคลื่อนไหวของเงินกู้ทีละส่วนตามจำนวน SEQ_NO ที่กำหนด','20','2020-01-14 12:16:00','2020-01-27 12:08:30','1','0',NULL),(18,'limit_fetch_stm_dept','แสดงข้อมูลรายการเคลื่อนไหวของเงินฝากทีละส่วนตามจำนวน SEQ_NO ที่กำหนด','20','2020-01-14 12:16:23','2020-01-14 12:16:23','1','0',NULL),(19,'limit_fetch_history_trans','แสดงรายการประวัติการทำธุรกรรมย้อนหลัง (รายการ)','24','2020-03-18 16:30:55','2020-05-14 09:52:21','1','0',NULL),(20,'process_keep_forward','สถานะแสดงรายการประมวลเรียกเก็บล่วงหน้า 1 = แสดงเดือนถัดไป , 0 = แสดงตรงเดือน','1','2020-04-02 14:06:50','2020-06-25 21:36:31','1','1','{\"1\" : \"แสดงเดือนถัดไป\",\"0\" : \"แสดงตรงเดือน\"}'),(21,'min_amount_deposit','ขั้นต่ำในการฝากเงินเข้าสหกรณ์','100.00','2020-05-19 16:01:23','2020-05-19 16:06:33','1','0',NULL),(22,'operative_account','คู่บัญชีการทำธุรกรรมธนาคาร','11023901','2020-05-19 16:31:36','2020-05-19 16:31:36','1','0',NULL),(23,'news_incoming_period_new','จำนวนวันที่จะแสดงคำว่า New','3','2020-05-20 11:24:18','2020-05-20 11:24:18','1','0',NULL),(24,'date_process_kp','วันที่ประมวลผลเรียกเก็บได้','25','2020-06-01 16:38:08','2020-06-01 16:38:08','1','0',NULL),(25,'show_split_slip_report','แสดงใบเสร็จเรียกเก็บแยกของแต่ละรายการ','1','2020-08-20 13:20:24','2020-08-20 13:20:24','1','1','{\r\n\"0\" : \"แสดงรายการรวม\",\r\n\"1\" : \"แสดงแยกรายการ\"\r\n}'),(26,'limit_session_timeout','เวลาหมดอายุการใช้งาน (วินาที)','900','2020-12-23 12:12:31','2020-12-23 12:12:31','1','0',NULL),(27,'check_duplicate_pin','ห้ามตั้ง PIN ซ้ำกัน 3 ตัวหรือมากกว่า 3 ตัว','0','2021-05-07 14:32:30','2021-05-07 14:32:30','1','1','{\r\n\"0\" : \"ห้ามซ้ำ\",\r\n\"1\" : \"ซ้ำได้\"\r\n}'),(28,'pin_sequest_digit','ห้ามตั้งเรียงกัน 4 ตัวหรือมากกว่า 4 ตัวขึ้นไป','0','2021-05-07 14:32:30','2021-05-07 14:32:30','1','1','{\r\n\"0\" : \"ห้ามเรียง\",\r\n\"1\" : \"เรียงได้\"\r\n}'),(29,'map_account_id_ktb','คู่บัญชีธนาคารกรุงไทย','10122100','2021-05-27 16:39:40','2022-06-08 15:24:50','1','0',NULL),(30,'accidfee_receive','คู่บัญชีรายการค่าธรรมเนียมรายได้','10122100','2021-06-21 13:49:00','2022-06-27 13:40:18','1','0',NULL),(31,'accidfee_promotion','คู่บัญชีรายการค่าธรรมเนียมโปรโมชัน','51210100','2021-06-21 13:49:00','2021-06-23 14:31:20','1','0',NULL);
/*!40000 ALTER TABLE `gcconstant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcconstantaccountdept`
--

DROP TABLE IF EXISTS `gcconstantaccountdept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcconstantaccountdept` (
  `id_accountconstant` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `dept_type_code` char(2) NOT NULL,
  `member_cate_code` char(2) NOT NULL DEFAULT 'AL',
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `allow_deposit_inside` enum('0','1') NOT NULL DEFAULT '0',
  `allow_withdraw_inside` enum('0','1') NOT NULL DEFAULT '0',
  `allow_deposit_outside` enum('0','1') NOT NULL DEFAULT '0',
  `allow_withdraw_outside` enum('0','1') NOT NULL DEFAULT '0',
  `allow_buyshare` enum('0','1') NOT NULL DEFAULT '0',
  `allow_pay_loan` enum('0','1') NOT NULL DEFAULT '0',
  `allow_receive_loan` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_accountconstant`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcconstantaccountdept`
--

LOCK TABLES `gcconstantaccountdept` WRITE;
/*!40000 ALTER TABLE `gcconstantaccountdept` DISABLE KEYS */;
INSERT INTO `gcconstantaccountdept` VALUES (1,'00','AL','2021-12-08 21:52:19','2022-06-01 15:49:25','1','1','1','1','0','0','0'),(2,'01','AL','2021-12-08 21:52:19','2022-07-06 11:13:59','1','1','1','1','0','0','0'),(3,'02','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(4,'03','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(5,'04','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(6,'05','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(7,'06','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(8,'07','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(9,'08','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(10,'09','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(11,'11','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(12,'12','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(13,'13','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(14,'14','AL','2021-12-08 21:52:19','2022-07-05 15:22:28','1','1','1','1','0','0','0'),(15,'15','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(16,'16','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(17,'17','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(18,'18','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(19,'19','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(20,'20','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(21,'21','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(22,'22','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(23,'23','AL','2021-12-08 21:52:19','2021-12-08 21:52:19','0','0','0','0','0','0','0'),(24,'24','AL','2022-05-20 13:16:34','2022-05-20 13:16:34','0','0','0','0','0','0','0');
/*!40000 ALTER TABLE `gcconstantaccountdept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcconstantapprwithdrawal`
--

DROP TABLE IF EXISTS `gcconstantapprwithdrawal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcconstantapprwithdrawal` (
  `id_apprwd_constant` tinyint(3) NOT NULL AUTO_INCREMENT,
  `member_no` char(8) NOT NULL,
  `id_section_system` tinyint(3) NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp(),
  `is_use` enum('0','1','-9') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_apprwd_constant`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcconstantapprwithdrawal`
--

LOCK TABLES `gcconstantapprwithdrawal` WRITE;
/*!40000 ALTER TABLE `gcconstantapprwithdrawal` DISABLE KEYS */;
/*!40000 ALTER TABLE `gcconstantapprwithdrawal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcconstantbackground`
--

DROP TABLE IF EXISTS `gcconstantbackground`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcconstantbackground` (
  `id_background` smallint(3) NOT NULL AUTO_INCREMENT,
  `image` text NOT NULL,
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_use` enum('0','1','-9') NOT NULL DEFAULT '1',
  `update_by` varchar(20) NOT NULL,
  PRIMARY KEY (`id_background`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcconstantbackground`
--

LOCK TABLES `gcconstantbackground` WRITE;
/*!40000 ALTER TABLE `gcconstantbackground` DISABLE KEYS */;
/*!40000 ALTER TABLE `gcconstantbackground` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcconstantchangeinfo`
--

DROP TABLE IF EXISTS `gcconstantchangeinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcconstantchangeinfo` (
  `const_code` varchar(10) NOT NULL,
  `const_desc` varchar(100) NOT NULL,
  `is_change` enum('0','1') NOT NULL DEFAULT '0',
  `save_tablecore` enum('0','1') NOT NULL DEFAULT '0',
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`const_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcconstantchangeinfo`
--

LOCK TABLES `gcconstantchangeinfo` WRITE;
/*!40000 ALTER TABLE `gcconstantchangeinfo` DISABLE KEYS */;
INSERT INTO `gcconstantchangeinfo` VALUES ('email','แก้ไขอีเมล','1','0','2020-08-01 16:58:57'),('tel','แก้ไขเบอร์โทรศัพท์','1','0','2020-08-01 16:58:57');
/*!40000 ALTER TABLE `gcconstantchangeinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcconstantreqstatus`
--

DROP TABLE IF EXISTS `gcconstantreqstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcconstantreqstatus` (
  `id_reqstatus` smallint(3) unsigned NOT NULL AUTO_INCREMENT,
  `req_value` varchar(3) NOT NULL,
  `req_desc` varchar(50) NOT NULL,
  `menu_component` varchar(50) NOT NULL,
  `is_use` enum('0','1') NOT NULL DEFAULT '1',
  `create_by` varchar(20) DEFAULT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_by` varchar(20) DEFAULT NULL,
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_reqstatus`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcconstantreqstatus`
--

LOCK TABLES `gcconstantreqstatus` WRITE;
/*!40000 ALTER TABLE `gcconstantreqstatus` DISABLE KEYS */;
/*!40000 ALTER TABLE `gcconstantreqstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcconstanttypeloan`
--

DROP TABLE IF EXISTS `gcconstanttypeloan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcconstanttypeloan` (
  `loantype_code` varchar(5) NOT NULL,
  `is_creditloan` enum('0','1') NOT NULL DEFAULT '0',
  `is_loanrequest` enum('0','1') NOT NULL DEFAULT '0',
  `is_receive` enum('0','1') NOT NULL DEFAULT '0',
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`loantype_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcconstanttypeloan`
--

LOCK TABLES `gcconstanttypeloan` WRITE;
/*!40000 ALTER TABLE `gcconstanttypeloan` DISABLE KEYS */;
/*!40000 ALTER TABLE `gcconstanttypeloan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcconstantwelfare`
--

DROP TABLE IF EXISTS `gcconstantwelfare`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcconstantwelfare` (
  `id_const_welfare` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `welfare_type_code` char(2) NOT NULL,
  `member_cate_code` char(2) NOT NULL,
  `is_use` enum('0','1') NOT NULL DEFAULT '1',
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_const_welfare`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcconstantwelfare`
--

LOCK TABLES `gcconstantwelfare` WRITE;
/*!40000 ALTER TABLE `gcconstantwelfare` DISABLE KEYS */;
/*!40000 ALTER TABLE `gcconstantwelfare` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcconttypetransqrcode`
--

DROP TABLE IF EXISTS `gcconttypetransqrcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcconttypetransqrcode` (
  `id_conttranqr` smallint(3) unsigned NOT NULL AUTO_INCREMENT,
  `trans_code_qr` char(2) NOT NULL,
  `trans_desc_qr` varchar(30) NOT NULL,
  `operation_desc_th` varchar(100) NOT NULL,
  `operation_desc_en` varchar(100) NOT NULL,
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_use` enum('0','1','-9') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_conttranqr`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcconttypetransqrcode`
--

LOCK TABLES `gcconttypetransqrcode` WRITE;
/*!40000 ALTER TABLE `gcconttypetransqrcode` DISABLE KEYS */;
INSERT INTO `gcconttypetransqrcode` VALUES (1,'01','ฝากเงินเข้าบัญชีสหกรณ์','เลือกบัญชีเงินฝากสหกรณ์ที่ต้องการฝากเข้า','Choose deposit account that you want deposit','2022-04-06 16:15:01','1');
/*!40000 ALTER TABLE `gcconttypetransqrcode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcdeptalias`
--

DROP TABLE IF EXISTS `gcdeptalias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcdeptalias` (
  `id_acc_alias` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `deptaccount_no` varchar(15) NOT NULL,
  `alias_name` varchar(100) DEFAULT NULL,
  `path_alias_img` varchar(100) DEFAULT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_acc_alias`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcdeptalias`
--

LOCK TABLES `gcdeptalias` WRITE;
/*!40000 ALTER TABLE `gcdeptalias` DISABLE KEYS */;
INSERT INTO `gcdeptalias` VALUES (1,'1000006103','我的前 💰','/resource/alias_account_dept/1000006103.jpeg?v=xTZ50U','2021-12-11 12:16:55','2021-12-11 12:16:55'),(2,'4000001478','她是👧他的钱','/resource/alias_account_dept/4000001478.jpeg?v=o0OCgl','2021-12-11 12:19:55','2021-12-11 12:19:55'),(3,'0000016172','อุพาภรณ์',NULL,'2021-12-11 13:38:58','2021-12-11 13:38:58'),(4,'0100008474','อุบลทิพย วาจรัต',NULL,'2021-12-11 17:55:35','2021-12-11 17:55:35'),(5,'1000004780','นางปทุมพร เบิกบาน',NULL,'2021-12-11 18:52:10','2021-12-11 18:52:10'),(6,'0000015686','นางปทุมพร​ เบิกบานและคู่สมรส',NULL,'2021-12-11 18:53:08','2021-12-11 18:53:08');
/*!40000 ALTER TABLE `gcdeptalias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcdeviceblacklist`
--

DROP TABLE IF EXISTS `gcdeviceblacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcdeviceblacklist` (
  `id_blacklist` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `unique_id` varchar(50) NOT NULL,
  `member_no` char(8) NOT NULL,
  `type_blacklist` enum('0','1') NOT NULL DEFAULT '0',
  `is_blacklist` enum('0','1') NOT NULL DEFAULT '1',
  `blacklist_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `new_id_token` mediumint(8) unsigned DEFAULT NULL,
  `old_id_token` mediumint(8) unsigned DEFAULT NULL,
  PRIMARY KEY (`id_blacklist`),
  KEY `FK_NEW_TOKEN` (`new_id_token`),
  KEY `FK_OLD_TOKEN` (`old_id_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcdeviceblacklist`
--

LOCK TABLES `gcdeviceblacklist` WRITE;
/*!40000 ALTER TABLE `gcdeviceblacklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `gcdeviceblacklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcfavoritelist`
--

DROP TABLE IF EXISTS `gcfavoritelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcfavoritelist` (
  `fav_refno` char(20) NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `name_fav` varchar(100) NOT NULL,
  `flag_trans` enum('TRN','BPM') NOT NULL DEFAULT 'TRN',
  `destination` varchar(15) DEFAULT NULL,
  `member_no` char(8) NOT NULL,
  `show_menu` enum('0','1') NOT NULL DEFAULT '1',
  `is_use` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`fav_refno`),
  KEY `FK_MEMBER_FAV_LIST` (`member_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcfavoritelist`
--

LOCK TABLES `gcfavoritelist` WRITE;
/*!40000 ALTER TABLE `gcfavoritelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `gcfavoritelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcformatreqwelfare`
--

DROP TABLE IF EXISTS `gcformatreqwelfare`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcformatreqwelfare` (
  `id_format_req_welfare` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id_const_welfare` tinyint(3) unsigned NOT NULL,
  `input_type` enum('text','number','date','time','datetime','radio','checkbox','select','year') NOT NULL DEFAULT 'text',
  `input_length` varchar(50) DEFAULT NULL,
  `input_name` varchar(100) NOT NULL,
  `label_text` varchar(100) NOT NULL,
  `placeholder` varchar(100) DEFAULT NULL,
  `default_value` varchar(50) DEFAULT NULL,
  `input_format` longtext DEFAULT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_use` enum('0','1','-9') NOT NULL DEFAULT '1',
  `is_required` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_format_req_welfare`),
  KEY `welfare_type_code` (`id_const_welfare`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcformatreqwelfare`
--

LOCK TABLES `gcformatreqwelfare` WRITE;
/*!40000 ALTER TABLE `gcformatreqwelfare` DISABLE KEYS */;
/*!40000 ALTER TABLE `gcformatreqwelfare` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gchistory`
--

DROP TABLE IF EXISTS `gchistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gchistory` (
  `id_history` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `his_type` enum('1','2') NOT NULL DEFAULT '1',
  `his_title` varchar(250) NOT NULL,
  `his_detail` text NOT NULL,
  `his_path_image` text DEFAULT NULL,
  `his_read_status` enum('0','1') NOT NULL DEFAULT '0',
  `his_del_status` enum('0','1') NOT NULL DEFAULT '0',
  `member_no` char(8) NOT NULL,
  `receive_date` datetime NOT NULL DEFAULT current_timestamp(),
  `read_date` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `send_by` varchar(20) DEFAULT NULL,
  `id_smstemplate` smallint(5) DEFAULT NULL,
  `is_sendahead` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_history`),
  KEY `FK_MEMBER_HISTORY` (`member_no`)
) ENGINE=InnoDB AUTO_INCREMENT=190 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gchistory`
--

LOCK TABLES `gchistory` WRITE;
/*!40000 ALTER TABLE `gchistory` DISABLE KEYS */;
INSERT INTO `gchistory` VALUES (1,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00000047','2021-01-14 14:03:59',NULL,'dev@mode',NULL,'0'),(2,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00000406','2021-01-14 14:03:59',NULL,'dev@mode',NULL,'0'),(3,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00000596','2021-01-14 14:03:59',NULL,'dev@mode',NULL,'0'),(4,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00000738','2021-01-14 14:03:59',NULL,'dev@mode',NULL,'0'),(5,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00000845','2021-01-14 14:03:59',NULL,'dev@mode',NULL,'0'),(6,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00000977','2021-01-14 14:03:59',NULL,'dev@mode',NULL,'0'),(7,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00001001','2021-01-14 14:03:59',NULL,'dev@mode',NULL,'0'),(8,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00001219','2021-01-14 14:03:59',NULL,'dev@mode',NULL,'0'),(9,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00001510','2021-01-14 14:03:59',NULL,'dev@mode',NULL,'0'),(10,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00001558','2021-01-14 14:03:59',NULL,'dev@mode',NULL,'0'),(11,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00002215','2021-01-14 14:03:59',NULL,'dev@mode',NULL,'0'),(12,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','dev@mode','2021-01-14 14:03:59',NULL,'dev@mode',NULL,'0'),(13,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','1','etnmode1','2021-01-14 14:03:59','2021-12-07 11:41:10','dev@mode',NULL,'0'),(14,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','1','0','etnmode2','2021-01-14 14:03:59','2021-04-01 16:17:33','dev@mode',NULL,'0'),(15,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','1','0','etnmode3','2021-01-14 14:03:59','2021-05-27 14:30:53','dev@mode',NULL,'0'),(16,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','1','0','etnmode4','2021-01-14 14:03:59','2021-01-26 14:55:00','dev@mode',NULL,'0'),(17,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','salemode','2021-01-14 14:03:59',NULL,'dev@mode',NULL,'0'),(18,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00000047','2021-01-14 14:07:12',NULL,'dev@mode',NULL,'0'),(19,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00000406','2021-01-14 14:07:12',NULL,'dev@mode',NULL,'0'),(20,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00000596','2021-01-14 14:07:12',NULL,'dev@mode',NULL,'0'),(21,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00000738','2021-01-14 14:07:12',NULL,'dev@mode',NULL,'0'),(22,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00000845','2021-01-14 14:07:12',NULL,'dev@mode',NULL,'0'),(23,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00000977','2021-01-14 14:07:12',NULL,'dev@mode',NULL,'0'),(24,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00001001','2021-01-14 14:07:12',NULL,'dev@mode',NULL,'0'),(25,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00001219','2021-01-14 14:07:12',NULL,'dev@mode',NULL,'0'),(26,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00001510','2021-01-14 14:07:12',NULL,'dev@mode',NULL,'0'),(27,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00001558','2021-01-14 14:07:12',NULL,'dev@mode',NULL,'0'),(28,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','00002215','2021-01-14 14:07:12',NULL,'dev@mode',NULL,'0'),(29,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','dev@mode','2021-01-14 14:07:12',NULL,'dev@mode',NULL,'0'),(30,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','1','etnmode1','2021-01-14 14:07:12','2021-12-07 11:41:10','dev@mode',NULL,'0'),(31,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','1','0','etnmode2','2021-01-14 14:07:12','2021-04-02 16:06:19','dev@mode',NULL,'0'),(32,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','1','0','etnmode3','2021-01-14 14:07:12','2021-05-27 14:30:53','dev@mode',NULL,'0'),(33,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','1','0','etnmode4','2021-01-14 14:07:12','2021-01-26 14:54:58','dev@mode',NULL,'0'),(34,'1','ทดสอบเบสเทส','ทดสอบเบสเทส','','0','0','salemode','2021-01-14 14:07:12',NULL,'dev@mode',NULL,'0'),(35,'1','df','sdfdsfd','','1','0','etnmode3','2021-01-14 14:20:33','2021-05-27 14:30:53','dev@mode',NULL,'0'),(36,'2','','','','0','0','dev@mode','2021-03-08 10:14:51',NULL,'dev@mode',NULL,'0'),(37,'2','','','','0','0','dev@mode','2021-03-08 10:15:57',NULL,'dev@mode',NULL,'0'),(38,'2','','','','0','1','etnmode1','2021-03-30 13:34:26','2021-12-07 11:41:20','dev@mode',NULL,'0'),(39,'2','','','','0','1','etnmode1','2021-03-30 14:32:04','2021-12-07 11:41:20','dev@mode',NULL,'0'),(40,'2','','','','0','1','etnmode1','2021-03-30 17:55:17','2021-12-07 11:41:20','dev@mode',NULL,'0'),(41,'2','','','','0','1','etnmode1','2021-03-30 17:55:22','2021-12-07 11:41:20','dev@mode',NULL,'0'),(42,'2','','','','0','1','etnmode1','2021-03-30 17:55:26','2021-12-07 11:41:20','dev@mode',NULL,'0'),(43,'2','','','','0','1','etnmode1','2021-03-31 09:13:35','2021-12-07 11:41:20','dev@mode',NULL,'0'),(44,'2','','','','0','1','etnmode1','2021-03-31 09:14:32','2021-12-07 11:41:20','dev@mode',NULL,'0'),(45,'2','คำขอกู้ของท่าน${REQ_STATUS_DESC}','ใบคำขอเลขที่ 000003 ${REQ_STATUS_DESC} ท่านสามารถตรวจสอบใบคำขอกู้ได้ที่เมนูตรวจสอบสถานะใบคำขอกู้','','0','1','etnmode1','2021-03-31 09:39:22','2021-12-07 11:41:20','dev@mode',NULL,'0'),(46,'2','คำขอกู้ของท่าน${REQ_STATUS_DESC}','ใบคำขอเลขที่ 000003 ${REQ_STATUS_DESC} ท่านสามารถตรวจสอบใบคำขอกู้ได้ที่เมนูตรวจสอบสถานะใบคำขอกู้','','0','1','etnmode1','2021-03-31 09:39:35','2021-12-07 11:41:20','dev@mode',NULL,'0'),(47,'2','คำขอกู้ของท่าน${REQ_STATUS_DESC}','ใบคำขอเลขที่ 000003 ${REQ_STATUS_DESC} ท่านสามารถตรวจสอบใบคำขอกู้ได้ที่เมนูตรวจสอบสถานะใบคำขอกู้','','0','1','etnmode1','2021-03-31 09:40:18','2021-12-07 11:41:20','dev@mode',NULL,'0'),(48,'2','คำขอกู้ของท่านรอเซ็นต์สัญญา/รอประกัน','ใบคำขอเลขที่ 000003 รอเซ็นต์สัญญา/รอประกัน ท่านสามารถตรวจสอบใบคำขอกู้ได้ที่เมนูตรวจสอบสถานะใบคำขอกู้','','0','1','etnmode1','2021-03-31 09:46:39','2021-12-07 11:41:20','dev@mode',NULL,'0'),(49,'2','คำขอกู้ของท่านพิมพ์คำขอกู้','ใบคำขอเลขที่ 000001 พิมพ์คำขอกู้ ท่านสามารถตรวจสอบใบคำขอกู้ได้ที่เมนูตรวจสอบสถานะใบคำขอกู้','','0','1','etnmode1','2021-03-31 09:54:41','2021-12-07 11:41:20','dev@mode',NULL,'0'),(50,'2','คำขอกู้ของท่านไม่อนุมัติ','ใบคำขอเลขที่ 000001 ไม่อนุมัติ ท่านสามารถตรวจสอบใบคำขอกู้ได้ที่เมนูตรวจสอบสถานะใบคำขอกู้','','0','1','etnmode1','2021-05-11 11:02:32','2021-12-07 11:41:20','dev@mode',NULL,'0'),(51,'2','คำขอกู้ของท่านไม่อนุมัติ','ใบคำขอเลขที่ 000022 ไม่อนุมัติ ท่านสามารถตรวจสอบใบคำขอกู้ได้ที่เมนูตรวจสอบสถานะใบคำขอกู้','','1','0','etnmode3','2021-05-11 17:11:37','2021-05-27 14:30:38','dev@mode',NULL,'0'),(52,'2','ทำรายการโอนเงินสำเร็จ','ทำรายการโอนเงินจากบัญชี : xxx-00-002xx เป็นจำนวนเงิน 11.00 บาท เมื่อวันที่ 27 พ.ค. 2564 14:30 น.','','1','0','etnmode3','2021-05-27 14:30:00','2021-05-27 14:30:38','system',NULL,'0'),(53,'2','ทำรายการโอนเงินสำเร็จ','ทำรายการโอนเงินจากบัญชี : xxx-00-002xx เป็นจำนวนเงิน 18.00 บาท เมื่อวันที่ 27 พ.ค. 2564 14:30:30 น.','','1','0','etnmode3','2021-05-27 14:30:30','2021-05-27 14:30:38','system',NULL,'0'),(54,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-002xx จำนวน : 150.00 บาท เมื่อวันที่ 27 พ.ค. 2564 16:40:42 น.','','0','0','etnmode3','2021-05-27 16:40:45',NULL,'system',NULL,'0'),(55,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-002xx จำนวน : 1.00 บาท เมื่อวันที่ 27 พ.ค. 2564 16:42:27 น.','','0','0','etnmode3','2021-05-27 16:42:28',NULL,'system',NULL,'0'),(56,'2','ฝากเงินผ่านโมบาย','ฝากเงินเข้าบัญชี : xxx-00-002xx จำนวน : 10,000.00 บาท เมื่อวันที่ 28 พ.ค. 2564 16:20:36 น.','','0','0','etnmode3','2021-05-28 16:20:36',NULL,'system',NULL,'0'),(57,'2','ทำรายการโอนเงินสำเร็จ','ทำรายการโอนเงินจากบัญชี : xxx-00-015xx เป็นจำนวนเงิน 100.00 บาท เมื่อวันที่ 21 มิ.ย. 2564 16:41:41 น.','','0','0','etnmode3','2021-06-21 16:41:41',NULL,'system',NULL,'0'),(58,'2','ทำรายการโอนเงินสำเร็จ','ทำรายการโอนเงินจากบัญชี : xxx-00-003xx เป็นจำนวนเงิน 100.00 บาท เมื่อวันที่ 21 มิ.ย. 2564 17:35:14 น.','','0','0','etnmode3','2021-06-21 17:35:14',NULL,'system',NULL,'0'),(59,'2','ทำรายการโอนเงินสำเร็จ','ทำรายการโอนเงินจากบัญชี : xxx-00-015xx เป็นจำนวนเงิน 100.00 บาท เมื่อวันที่ 21 มิ.ย. 2564 17:38:28 น.','','0','0','etnmode3','2021-06-21 17:38:28',NULL,'system',NULL,'0'),(60,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 10.00 บาท เมื่อวันที่ 22 มิ.ย. 2564 19:30:48 น.','','0','0','etnmode3','2021-06-22 19:31:11',NULL,'system',NULL,'0'),(61,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 13.00 บาท เมื่อวันที่ 22 มิ.ย. 2564 19:33:45 น.','','0','0','etnmode3','2021-06-22 19:34:07',NULL,'system',NULL,'0'),(62,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 10.00 บาท เมื่อวันที่ 22 มิ.ย. 2564 19:41:59 น.','','0','0','etnmode3','2021-06-22 19:42:22',NULL,'system',NULL,'0'),(63,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 10.00 บาท เมื่อวันที่ 22 มิ.ย. 2564 19:43:09 น.','','0','0','etnmode3','2021-06-22 19:43:32',NULL,'system',NULL,'0'),(64,'2','ฝากเงินผ่านโมบาย','ฝากเงินเข้าบัญชี : xxx-00-003xx จำนวน : 100.00 บาท เมื่อวันที่ 23 มิ.ย. 2564 08:15:44 น.','','0','0','etnmode3','2021-06-23 08:15:45',NULL,'system',NULL,'0'),(65,'2','ฝากเงินผ่านโมบาย','ฝากเงินเข้าบัญชี : xxx-00-003xx จำนวน : 1,000.00 บาท เมื่อวันที่ 23 มิ.ย. 2564 09:38:52 น.','','0','0','etnmode3','2021-06-23 09:38:53',NULL,'system',NULL,'0'),(66,'2','ฝากเงินผ่านโมบาย','ฝากเงินเข้าบัญชี : xxx-00-003xx จำนวน : 10,000.00 บาท เมื่อวันที่ 23 มิ.ย. 2564 09:39:16 น.','','0','0','etnmode3','2021-06-23 09:39:17',NULL,'system',NULL,'0'),(67,'2','ฝากเงินผ่านโมบาย','ฝากเงินเข้าบัญชี : xxx-00-003xx จำนวน : 10,000.00 บาท เมื่อวันที่ 23 มิ.ย. 2564 14:42:59 น.','','0','0','etnmode3','2021-06-23 14:43:00',NULL,'system',NULL,'0'),(68,'2','ฝากเงินผ่านโมบาย','ฝากเงินเข้าบัญชี : xxx-00-003xx จำนวน : 2,000.00 บาท เมื่อวันที่ 23 มิ.ย. 2564 14:51:22 น.','','0','0','etnmode3','2021-06-23 14:51:44',NULL,'system',NULL,'0'),(69,'2','ฝากเงินผ่านโมบาย','ฝากเงินเข้าบัญชี : xxx-00-003xx จำนวน : 1,000.00 บาท เมื่อวันที่ 23 มิ.ย. 2564 15:01:53 น.','','0','0','etnmode3','2021-06-23 15:01:53',NULL,'system',NULL,'0'),(70,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 4,000.00 บาท เมื่อวันที่ 23 มิ.ย. 2564 15:54:26 น.','','0','0','etnmode3','2021-06-23 15:54:27',NULL,'system',NULL,'0'),(71,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 2,000.00 บาท เมื่อวันที่ 23 มิ.ย. 2564 16:00:13 น.','','0','0','etnmode3','2021-06-23 16:00:14',NULL,'system',NULL,'0'),(72,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 4,000.00 บาท เมื่อวันที่ 23 มิ.ย. 2564 16:00:43 น.','','0','0','etnmode3','2021-06-23 16:00:46',NULL,'system',NULL,'0'),(73,'2','ฝากเงินผ่านโมบาย','ฝากเงินเข้าบัญชี : xxx-00-003xx จำนวน : 6,000.00 บาท เมื่อวันที่ 23 มิ.ย. 2564 16:01:06 น.','','0','0','etnmode3','2021-06-23 16:01:06',NULL,'system',NULL,'0'),(74,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 10,000.00 บาท เมื่อวันที่ 23 มิ.ย. 2564 16:01:22 น.','','0','0','etnmode3','2021-06-23 16:01:23',NULL,'system',NULL,'0'),(75,'2','ฝากเงินผ่านโมบาย','ฝากเงินเข้าบัญชี : xxx-00-003xx จำนวน : 20,000.00 บาท เมื่อวันที่ 24 มิ.ย. 2564 10:01:16 น.','','0','0','etnmode3','2021-06-24 10:01:16',NULL,'system',NULL,'0'),(76,'2','ฝากเงินผ่านโมบาย','ฝากเงินเข้าบัญชี : xxx-00-003xx จำนวน : 15,000.00 บาท เมื่อวันที่ 24 มิ.ย. 2564 10:01:32 น.','','0','0','etnmode3','2021-06-24 10:01:32',NULL,'system',NULL,'0'),(77,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 1,000.00 บาท เมื่อวันที่ 24 มิ.ย. 2564 11:30 น.','','0','0','etnmode3','2021-06-24 11:30:01',NULL,'system',NULL,'0'),(78,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 1,000.00 บาท เมื่อวันที่ 24 มิ.ย. 2564 11:36:46 น.','','0','0','etnmode3','2021-06-24 11:36:47',NULL,'system',NULL,'0'),(79,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 2,000.00 บาท เมื่อวันที่ 24 มิ.ย. 2564 11:38:01 น.','','0','0','etnmode3','2021-06-24 11:38:02',NULL,'system',NULL,'0'),(80,'2','ฝากเงินผ่านโมบาย','ฝากเงินเข้าบัญชี : xxx-00-003xx จำนวน : 10,000.00 บาท เมื่อวันที่ 24 มิ.ย. 2564 11:48:50 น.','','0','0','etnmode3','2021-06-24 11:49:12',NULL,'system',NULL,'0'),(81,'2','ฝากเงินผ่านโมบาย','ฝากเงินเข้าบัญชี : xxx-00-003xx จำนวน : 20,000.00 บาท เมื่อวันที่ 24 มิ.ย. 2564 11:49:30 น.','','0','0','etnmode3','2021-06-24 11:49:52',NULL,'system',NULL,'0'),(82,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 5,000.00 บาท เมื่อวันที่ 24 มิ.ย. 2564 11:50:17 น.','','0','0','etnmode3','2021-06-24 11:50:39',NULL,'system',NULL,'0'),(83,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 20,000.00 บาท เมื่อวันที่ 24 มิ.ย. 2564 11:51:03 น.','','0','0','etnmode3','2021-06-24 11:51:27',NULL,'system',NULL,'0'),(84,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 5,000.00 บาท เมื่อวันที่ 24 มิ.ย. 2564 11:51:53 น.','','0','0','etnmode3','2021-06-24 11:52:16',NULL,'system',NULL,'0'),(85,'2','ฝากเงินผ่านโมบาย','ฝากเงินเข้าบัญชี : xxx-00-003xx จำนวน : 10,000.00 บาท เมื่อวันที่ 24 มิ.ย. 2564 16:37:22 น.','','0','0','etnmode3','2021-06-24 16:37:22',NULL,'system',NULL,'0'),(86,'2','ฝากเงินผ่านโมบาย','ฝากเงินเข้าบัญชี : xxx-00-003xx จำนวน : 20,000.00 บาท เมื่อวันที่ 24 มิ.ย. 2564 16:37:39 น.','','0','0','etnmode3','2021-06-24 16:37:39',NULL,'system',NULL,'0'),(87,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 5,000.00 บาท เมื่อวันที่ 24 มิ.ย. 2564 16:38:05 น.','','0','0','etnmode3','2021-06-24 16:38:06',NULL,'system',NULL,'0'),(88,'2','ฝากเงินผ่านโมบาย','ฝากเงินเข้าบัญชี : xxx-00-003xx จำนวน : 10,000.00 บาท เมื่อวันที่ 24 มิ.ย. 2564 16:42:29 น.','','0','0','etnmode3','2021-06-24 16:42:29',NULL,'system',NULL,'0'),(89,'2','ฝากเงินผ่านโมบาย','ฝากเงินเข้าบัญชี : xxx-00-003xx จำนวน : 20,000.00 บาท เมื่อวันที่ 24 มิ.ย. 2564 16:42:43 น.','','0','0','etnmode3','2021-06-24 16:42:43',NULL,'system',NULL,'0'),(90,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 5,000.00 บาท เมื่อวันที่ 24 มิ.ย. 2564 16:43:07 น.','','0','0','etnmode3','2021-06-24 16:43:08',NULL,'system',NULL,'0'),(91,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 15,000.00 บาท เมื่อวันที่ 24 มิ.ย. 2564 16:43:23 น.','','0','0','etnmode3','2021-06-24 16:43:24',NULL,'system',NULL,'0'),(92,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 10,000.00 บาท เมื่อวันที่ 24 มิ.ย. 2564 16:43:40 น.','','0','0','etnmode3','2021-06-24 16:43:41',NULL,'system',NULL,'0'),(93,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 300.00 บาท เมื่อวันที่ 24 มิ.ย. 2564 17:11:27 น.','','0','0','etnmode3','2021-06-24 17:11:30',NULL,'system',NULL,'0'),(94,'2','ชำระหนี้สำเร็จ','บัญชี : xxx-00-003xx มีการชำระหนี้สัญญา ฉฉ64000105 จำนวน : 10.00 บาท ดอกเบี้ย 0.00 บาท/เงินต้น 10.00 บาท เมื่อ 29 มิ.ย. 2564 11:35:45 น.','','0','0','etnmode3','2021-06-29 11:35:45',NULL,'system',NULL,'0'),(95,'2','ฝากเงินผ่านโมบาย','ฝากเงินเข้าบัญชี : xxx-00-003xx จำนวน : 10,000.00 บาท เมื่อวันที่ 29 มิ.ย. 2564 14:43:44 น.','','0','0','etnmode3','2021-06-29 14:43:45',NULL,'system',NULL,'0'),(96,'2','ชำระหนี้สำเร็จ','บัญชี : xxx-00-003xx มีการชำระหนี้สัญญา ฉฉ64000105 จำนวน : 1,000.00 บาท ดอกเบี้ย 0.00 บาท/เงินต้น 1,000.00 บาท เมื่อ 29 มิ.ย. 2564 16:16:20 น.','','0','0','etnmode3','2021-06-29 16:16:20',NULL,'system',NULL,'0'),(97,'2','ชำระหนี้สำเร็จ','บัญชี : xxx-00-003xx มีการชำระหนี้สัญญา ฉฉ64000105 จำนวน : 500.00 บาท ดอกเบี้ย 0.00 บาท/เงินต้น 500.00 บาท เมื่อ 30 มิ.ย. 2564 11:59:57 น.','','0','0','etnmode3','2021-06-30 11:59:57',NULL,'system',NULL,'0'),(98,'2','ชำระหนี้สำเร็จ','บัญชี : xxx-00-003xx มีการชำระหนี้สัญญา ฉฉ64000105 จำนวน : 500.00 บาท ดอกเบี้ย 0.00 บาท/เงินต้น 500.00 บาท เมื่อ 30 มิ.ย. 2564 12:07:30 น.','','0','0','etnmode3','2021-06-30 12:07:30',NULL,'system',NULL,'0'),(99,'2','ชำระหนี้สำเร็จ','บัญชี : xxx-06-740xx มีการชำระหนี้สัญญา ฉฉ64000105 จำนวน : 10,000.00 บาท ดอกเบี้ย 0.00 บาท/เงินต้น 10,000.00 บาท เมื่อ 30 มิ.ย. 2564 12:09:34 น.','','0','0','etnmode3','2021-06-30 12:09:34',NULL,'system',NULL,'0'),(100,'2','','','','0','0','etnmode3','2021-06-30 20:00:36',NULL,'system',NULL,'0'),(101,'2','','','','0','0','etnmode3','2021-06-30 20:02:04',NULL,'system',NULL,'0'),(102,'2','','','','0','0','etnmode3','2021-06-30 20:02:55',NULL,'system',NULL,'0'),(103,'2','','','','0','0','etnmode3','2021-06-30 20:08:23',NULL,'system',NULL,'0'),(104,'2','ทำรายการรับเงินกู้สำเร็จ','ทำรายการรับเงินกู้สัญญา ฉป64000001 เข้าบัญชี : xxx-00-002xx เป็นจำนวนเงิน 1,999.00 บาท เมื่อวันที่ 30 มิ.ย. 2564 20:12:51 น.','','0','0','etnmode3','2021-06-30 20:12:51',NULL,'system',NULL,'0'),(105,'2','ทำรายการรับเงินกู้สำเร็จ','ทำรายการรับเงินกู้สัญญา ฉป64000001 เข้าบัญชี : xxx-00-002xx เป็นจำนวนเงิน 500.00 บาท เมื่อวันที่ 30 มิ.ย. 2564 21:40:54 น.','','0','0','etnmode3','2021-06-30 21:41:16',NULL,'system',NULL,'0'),(106,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 1,000.00 บาท เมื่อวันที่ 30 มิ.ย. 2564 21:57:56 น.','','0','0','etnmode3','2021-06-30 21:57:57',NULL,'system',NULL,'0'),(107,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-003xx จำนวน : 100.00 บาท เมื่อวันที่ 30 มิ.ย. 2564 21:58:58 น.','','0','0','etnmode3','2021-06-30 21:58:59',NULL,'system',NULL,'0'),(108,'2','ทำรายการรับเงินกู้สำเร็จ','ทำรายการรับเงินกู้สัญญา ฉป64000001 เข้าบัญชี : xxx-06-740xx เป็นจำนวนเงิน 100.00 บาท เมื่อวันที่ 30 มิ.ย. 2564 22:07:53 น.','','0','0','etnmode3','2021-06-30 22:07:56',NULL,'system',NULL,'0'),(109,'2','ทำรายการรับเงินกู้สำเร็จ','ทำรายการรับเงินกู้สัญญา ฉป64000001 เข้าบัญชี : xxx-06-740xx เป็นจำนวนเงิน 500.00 บาท เมื่อวันที่ 30 มิ.ย. 2564 22:08:39 น.','','0','0','etnmode3','2021-06-30 22:08:41',NULL,'system',NULL,'0'),(110,'2','ทำรายการโอนเงินสำเร็จ','ทำรายการโอนเงินจากบัญชี : xxx-00-002xx เป็นจำนวนเงิน 700.00 บาท เมื่อวันที่ 01 ก.ค. 2564 09:02:23 น.','','0','0','etnmode3','2021-07-01 09:02:23',NULL,'system',NULL,'0'),(111,'2','','','','0','0','00001558','2021-07-01 09:02:24',NULL,'system',NULL,'0'),(112,'2','ชำระหนี้สำเร็จ','บัญชี : xxx-00-002xx มีการชำระหนี้สัญญา สม64000040 จำนวน : 2,000.00 บาท ดอกเบี้ย 0.00 บาท/เงินต้น 2,000.00 บาท เมื่อ 01 ก.ค. 2564 09:03:07 น.','','0','0','etnmode3','2021-07-01 09:03:07',NULL,'system',NULL,'0'),(113,'2','ทำรายการรับเงินกู้สำเร็จ','ทำรายการรับเงินกู้สัญญา ฉป64000001 เข้าบัญชี : xxx-00-002xx เป็นจำนวนเงิน 4,000.00 บาท เมื่อวันที่ 01 ก.ค. 2564 09:04:38 น.','','0','0','etnmode3','2021-07-01 09:04:39',NULL,'system',NULL,'0'),(114,'2','ทำรายการรับเงินกู้สำเร็จ','ทำรายการรับเงินกู้สัญญา ฉป64000001 เข้าบัญชี : xxx-06-740xx เป็นจำนวนเงิน 600.00 บาท เมื่อวันที่ 01 ก.ค. 2564 09:05:12 น.','','0','0','etnmode3','2021-07-01 09:05:15',NULL,'system',NULL,'0'),(115,'2','ทำรายการโอนเงินสำเร็จ','ทำรายการโอนเงินจากบัญชี : xxx-00-002xx เป็นจำนวนเงิน 100.00 บาท เมื่อวันที่ 01 ก.ค. 2564 09:20:19 น.','','0','0','etnmode3','2021-07-01 09:20:19',NULL,'system',NULL,'0'),(116,'2','','','','0','0','00001558','2021-07-01 09:20:20',NULL,'system',NULL,'0'),(117,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-002xx จำนวน : 1,000.00 บาท เมื่อวันที่ 01 ก.ค. 2564 09:21:04 น.','','0','0','etnmode3','2021-07-01 09:21:09',NULL,'system',NULL,'0'),(118,'2','ฝากเงินผ่านโมบาย','ฝากเงินเข้าบัญชี : xxx-00-002xx จำนวน : 10,000.00 บาท เมื่อวันที่ 01 ก.ค. 2564 09:22:01 น.','','0','0','etnmode3','2021-07-01 09:22:01',NULL,'system',NULL,'0'),(119,'2','ชำระหนี้สำเร็จ','บัญชี : xxx-00-002xx มีการชำระหนี้สัญญา สม64000040 จำนวน : 1,000.00 บาท ดอกเบี้ย 305.92 บาท/เงินต้น 694.08 บาท เมื่อ 01 ก.ค. 2564 09:32:42 น.','','0','0','etnmode3','2021-07-01 09:32:42',NULL,'system',NULL,'0'),(120,'2','ชำระหนี้สำเร็จ','บัญชี : xxx-06-740xx มีการชำระหนี้สัญญา สม64000040 จำนวน : 10,000.00 บาท ดอกเบี้ย 0.00 บาท/เงินต้น 10,000.00 บาท เมื่อ 01 ก.ค. 2564 09:41 น.','','0','0','etnmode3','2021-07-01 09:41:00',NULL,'system',NULL,'0'),(121,'2','ทำรายการรับเงินกู้สำเร็จ','ทำรายการรับเงินกู้สัญญา ฉป64000001 เข้าบัญชี : xxx-00-002xx เป็นจำนวนเงิน 10,000.00 บาท เมื่อวันที่ 01 ก.ค. 2564 10:06:42 น.','','0','0','etnmode3','2021-07-01 10:06:43',NULL,'system',NULL,'0'),(122,'2','ทำรายการรับเงินกู้สำเร็จ','ทำรายการรับเงินกู้สัญญา ฉป64000001 เข้าบัญชี : xxx-06-740xx เป็นจำนวนเงิน 10,000.00 บาท เมื่อวันที่ 01 ก.ค. 2564 10:07:25 น.','','0','0','etnmode3','2021-07-01 10:07:28',NULL,'system',NULL,'0'),(123,'2','ทำรายการรับเงินกู้สำเร็จ','ทำรายการรับเงินกู้สัญญา ฉป64000001 เข้าบัญชี : xxx-06-740xx เป็นจำนวนเงิน 10,000.00 บาท เมื่อวันที่ 01 ก.ค. 2564 10:11:23 น.','','0','0','etnmode3','2021-07-01 10:11:38',NULL,'system',NULL,'0'),(124,'2','ทำรายการรับเงินกู้สำเร็จ','ทำรายการรับเงินกู้สัญญา ฉป64000001 เข้าบัญชี : xxx-06-740xx เป็นจำนวนเงิน 10,000.00 บาท เมื่อวันที่ 01 ก.ค. 2564 10:13:15 น.','','0','0','etnmode3','2021-07-01 10:13:21',NULL,'system',NULL,'0'),(125,'2','ทำรายการรับเงินกู้สำเร็จ','ทำรายการรับเงินกู้สัญญา ฉป64000001 เข้าบัญชี : xxx-06-740xx เป็นจำนวนเงิน 10,000.00 บาท เมื่อวันที่ 01 ก.ค. 2564 10:13:34 น.','','0','0','etnmode3','2021-07-01 10:13:36',NULL,'system',NULL,'0'),(126,'1','','101','','1','0','etnmode2','2021-07-29 12:02:55','2021-09-28 12:12:20','dev@mode',NULL,'0'),(127,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-01-339xx จำนวน : 100.00 บาท เมื่อวันที่ 23 ส.ค. 2564 16:21:32 น.','','0','0','etnmode3','2021-08-23 16:21:33',NULL,'system',NULL,'0'),(128,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-01-012xx จำนวน : 100.00 บาท เมื่อวันที่ 23 ส.ค. 2564 16:21:51 น.','','0','0','etnmode3','2021-08-23 16:21:53',NULL,'system',NULL,'0'),(129,'2','ทำรายการโอนเงินสำเร็จ','ทำรายการโอนเงินจากบัญชี : xxx-02-244xx เป็นจำนวนเงิน 500.00 บาท เมื่อวันที่ 27 ก.ย. 2564 11:00:27 น.','','0','0','etnmode3','2021-09-27 11:00:27',NULL,'system',NULL,'0'),(130,'2','ทำรายการโอนเงินสำเร็จ','ทำรายการโอนเงินจากบัญชี : xxx-02-244xx เป็นจำนวนเงิน 500.00 บาท เมื่อวันที่ 27 ก.ย. 2564 11:27:42 น.','','0','0','etnmode3','2021-09-27 11:27:42',NULL,'system',NULL,'0'),(131,'2','ทำรายการโอนเงินสำเร็จ','ทำรายการโอนเงินจากบัญชี : xxx-02-021xx เป็นจำนวนเงิน 10,000.00 บาท เมื่อวันที่ 04 ต.ค. 2564 11:43:03 น.','','0','0','etnmode3','2021-10-04 11:43:03',NULL,'system',NULL,'0'),(132,'2','ทำรายการโอนเงินสำเร็จ','ทำรายการโอนเงินจากบัญชี : xxx-02-268xx เป็นจำนวนเงิน 1,000.00 บาท เมื่อวันที่ 04 ต.ค. 2564 17:29:58 น.','','0','0','etnmode3','2021-10-04 17:29:58',NULL,'system',NULL,'0'),(133,'2','ทำรายการโอนเงินสำเร็จ','ทำรายการโอนเงินจากบัญชี : xxx-02-268xx เป็นจำนวนเงิน 1,000.00 บาท เมื่อวันที่ 05 ต.ค. 2564 09:49:11 น.','','0','0','etnmode3','2021-10-05 09:49:11',NULL,'system',NULL,'0'),(134,'2','ทำรายการโอนเงินสำเร็จ','ทำรายการโอนเงินจากบัญชี : xxx-02-268xx เป็นจำนวนเงิน 500.00 บาท เมื่อวันที่ 06 ต.ค. 2564 10:54:10 น.','','0','0','etnmode3','2021-10-06 10:54:10',NULL,'system',NULL,'0'),(135,'1','notify test','testttttttt','','1','0','etnmode4','2021-10-06 13:39:39','2022-02-28 15:16:40','dev@mode',NULL,'0'),(136,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-01-007xx จำนวน : 100.00 บาท เมื่อวันที่ 07 ต.ค. 2564 16:09:18 น.','','0','0','etnmode3','2021-10-07 16:09:19',NULL,'system',NULL,'0'),(137,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-01-007xx จำนวน : 100.00 บาท เมื่อวันที่ 07 ต.ค. 2564 16:23:26 น.','','0','0','etnmode3','2021-10-07 16:23:29',NULL,'system',NULL,'0'),(138,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-01-330xx จำนวน : 100.00 บาท เมื่อวันที่ 07 ต.ค. 2564 16:24:22 น.','','0','0','etnmode3','2021-10-07 16:24:24',NULL,'system',NULL,'0'),(139,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-01-330xx จำนวน : 100.00 บาท เมื่อวันที่ 07 ต.ค. 2564 16:27:08 น.','','0','0','etnmode3','2021-10-07 16:27:10',NULL,'system',NULL,'0'),(140,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-01-330xx จำนวน : 500.00 บาท เมื่อวันที่ 07 ต.ค. 2564 16:28:49 น.','','0','0','etnmode3','2021-10-07 16:28:51',NULL,'system',NULL,'0'),(141,'2','ทำรายการโอนเงินสำเร็จ','ทำรายการโอนเงินจากบัญชี : xxx-01-330xx เป็นจำนวนเงิน 500.00 บาท เมื่อวันที่ 08 ต.ค. 2564 15:56:29 น.','','0','0','etnmode3','2021-10-08 15:56:29',NULL,'system',NULL,'0'),(142,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-01-330xx จำนวน : 100.00 บาท เมื่อวันที่ 08 ต.ค. 2564 16:07 น.','','0','0','etnmode3','2021-10-08 16:07:01',NULL,'system',NULL,'0'),(143,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-155xx จำนวน : 100.00 บาท เมื่อวันที่ 08 ธ.ค. 2564 22:17:34 น.','','1','0','00004491','2021-12-08 22:17:35','2021-12-08 22:20:34','system',NULL,'0'),(144,'1','รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน กุมภาพันธ์','รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน กุมภาพันธ์\nสหกรณ์ได้ทำการโอนเงินสวัสดิการเข้าบัญชีเงินฝากสมาชิกแล้ว สามารถตรวจสอบยอดโอนได้ที่แอพพลิเคชั่นสหกรณ์\n\nhttp://www.sunpasitcoop.com/coop/images/pdf/ASS/2565/ASS_02_2565.pdf','https://proxy.thaicoop.co/SPSCOOP/resource/image_wait_to_be_sent/SQHLHT.jpeg','1','0','00004378','2022-02-25 10:36:32','2022-04-29 17:10:20','spsadmin',NULL,'0'),(145,'1','รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน กุมภาพันธ์','รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน กุมภาพันธ์\nสหกรณ์ได้ทำการโอนเงินสวัสดิการเข้าบัญชีเงินฝากสมาชิกแล้ว สามารถตรวจสอบยอดโอนได้ที่แอพพลิเคชั่นสหกรณ์\n\nhttp://www.sunpasitcoop.com/coop/images/pdf/ASS/2565/ASS_02_2565.pdf','https://proxy.thaicoop.co/SPSCOOP/resource/image_wait_to_be_sent/SQHLHT.jpeg','1','0','00004491','2022-02-25 10:36:32','2022-02-25 10:36:55','spsadmin',NULL,'0'),(146,'1','รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน กุมภาพันธ์','รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน กุมภาพันธ์\nสหกรณ์ได้ทำการโอนเงินสวัสดิการเข้าบัญชีเงินฝากสมาชิกแล้ว สามารถตรวจสอบยอดโอนได้ที่แอพพลิเคชั่นสหกรณ์\n\nhttp://www.sunpasitcoop.com/coop/images/pdf/ASS/2565/ASS_02_2565.pdf','https://proxy.thaicoop.co/SPSCOOP/resource/image_wait_to_be_sent/SQHLHT.jpeg','1','0','00005060','2022-02-25 10:36:32','2022-02-25 16:27:26','spsadmin',NULL,'0'),(147,'1','รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน กุมภาพันธ์','รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน กุมภาพันธ์\nสหกรณ์ได้ทำการโอนเงินสวัสดิการเข้าบัญชีเงินฝากสมาชิกแล้ว สามารถตรวจสอบยอดโอนได้ที่แอพพลิเคชั่นสหกรณ์\n\nhttp://www.sunpasitcoop.com/coop/images/pdf/ASS/2565/ASS_02_2565.pdf','https://proxy.thaicoop.co/SPSCOOP/resource/image_wait_to_be_sent/SQHLHT.jpeg','0','0','dev@mode','2022-02-25 10:36:32',NULL,'spsadmin',NULL,'0'),(148,'1','รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน กุมภาพันธ์','รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน กุมภาพันธ์\nสหกรณ์ได้ทำการโอนเงินสวัสดิการเข้าบัญชีเงินฝากสมาชิกแล้ว สามารถตรวจสอบยอดโอนได้ที่แอพพลิเคชั่นสหกรณ์\n\nhttp://www.sunpasitcoop.com/coop/images/pdf/ASS/2565/ASS_02_2565.pdf','https://proxy.thaicoop.co/SPSCOOP/resource/image_wait_to_be_sent/SQHLHT.jpeg','0','0','etnmode1','2022-02-25 10:36:32',NULL,'spsadmin',NULL,'0'),(149,'1','รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน กุมภาพันธ์','รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน กุมภาพันธ์\nสหกรณ์ได้ทำการโอนเงินสวัสดิการเข้าบัญชีเงินฝากสมาชิกแล้ว สามารถตรวจสอบยอดโอนได้ที่แอพพลิเคชั่นสหกรณ์\n\nhttp://www.sunpasitcoop.com/coop/images/pdf/ASS/2565/ASS_02_2565.pdf','https://proxy.thaicoop.co/SPSCOOP/resource/image_wait_to_be_sent/SQHLHT.jpeg','0','0','etnmode2','2022-02-25 10:36:32',NULL,'spsadmin',NULL,'0'),(150,'1','รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน กุมภาพันธ์','รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน กุมภาพันธ์\nสหกรณ์ได้ทำการโอนเงินสวัสดิการเข้าบัญชีเงินฝากสมาชิกแล้ว สามารถตรวจสอบยอดโอนได้ที่แอพพลิเคชั่นสหกรณ์\n\nhttp://www.sunpasitcoop.com/coop/images/pdf/ASS/2565/ASS_02_2565.pdf','https://proxy.thaicoop.co/SPSCOOP/resource/image_wait_to_be_sent/SQHLHT.jpeg','0','0','etnmode3','2022-02-25 10:36:32',NULL,'spsadmin',NULL,'0'),(151,'1','รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน กุมภาพันธ์','รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน กุมภาพันธ์\nสหกรณ์ได้ทำการโอนเงินสวัสดิการเข้าบัญชีเงินฝากสมาชิกแล้ว สามารถตรวจสอบยอดโอนได้ที่แอพพลิเคชั่นสหกรณ์\n\nhttp://www.sunpasitcoop.com/coop/images/pdf/ASS/2565/ASS_02_2565.pdf','https://proxy.thaicoop.co/SPSCOOP/resource/image_wait_to_be_sent/SQHLHT.jpeg','1','0','etnmode4','2022-02-25 10:36:32','2022-02-25 12:10:37','spsadmin',NULL,'0'),(152,'1','รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน กุมภาพันธ์','รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน กุมภาพันธ์\nสหกรณ์ได้ทำการโอนเงินสวัสดิการเข้าบัญชีเงินฝากสมาชิกแล้ว สามารถตรวจสอบยอดโอนได้ที่แอพพลิเคชั่นสหกรณ์\n\nhttp://www.sunpasitcoop.com/coop/images/pdf/ASS/2565/ASS_02_2565.pdf','https://proxy.thaicoop.co/SPSCOOP/resource/image_wait_to_be_sent/SQHLHT.jpeg','0','0','salemode','2022-02-25 10:36:32',NULL,'spsadmin',NULL,'0'),(153,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-155xx จำนวน : 200.00 บาท เมื่อวันที่ 09 พ.ค. 2565 14:03:37 น.','','1','0','00004491','2022-05-09 14:03:38','2022-05-09 14:04:51','system',NULL,'0'),(154,'2','','','','1','0','00004491','2022-05-09 14:09:11','2022-05-09 14:10:21','system',NULL,'0'),(155,'2','','','','1','0','00004491','2022-05-19 10:52:03','2022-05-20 13:17:34','system',NULL,'0'),(156,'2','','','','0','0','00005367','2022-05-19 13:08:42',NULL,'system',NULL,'0'),(157,'2','','','','0','0','00003171','2022-05-23 13:00:58',NULL,'system',NULL,'0'),(158,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-155xx จำนวน : 129.00 บาท เมื่อวันที่ 24 พ.ค. 2565 14:13:13 น.','','1','0','00004491','2022-05-24 14:13:14','2022-05-24 14:13:31','system',NULL,'0'),(159,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-169xx จำนวน : 50.00 บาท เมื่อวันที่ 25 พ.ค. 2565 14:09:23 น.','','0','0','00005367','2022-05-25 14:09:24',NULL,'system',NULL,'0'),(160,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-155xx จำนวน : 93.00 บาท เมื่อวันที่ 25 พ.ค. 2565 14:11:47 น.','','1','0','00004491','2022-05-25 14:11:47','2022-05-25 14:13:00','system',NULL,'0'),(161,'2','','','','1','0','00004378','2022-06-08 13:52:47','2022-06-11 11:35:42','system',NULL,'0'),(162,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-153xx จำนวน : 189.00 บาท เมื่อวันที่ 08 มิ.ย. 2565 13:53:49 น.','','1','0','00004378','2022-06-08 13:53:50','2022-06-11 11:35:28','system',NULL,'0'),(163,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-155xx จำนวน : 125.00 บาท เมื่อวันที่ 08 มิ.ย. 2565 13:54:59 น.','','1','0','00004491','2022-06-08 13:55:00','2022-06-08 13:55:22','system',NULL,'0'),(164,'2','','','','1','0','00004491','2022-06-08 13:57:17','2022-06-09 14:22:19','system',NULL,'0'),(165,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-153xx จำนวน : 4,891.00 บาท เมื่อวันที่ 09 มิ.ย. 2565 10:25:28 น.','','1','0','00004378','2022-06-09 10:25:29','2022-06-11 11:35:31','system',NULL,'0'),(166,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-059xx จำนวน : 400.00 บาท เมื่อวันที่ 09 มิ.ย. 2565 10:41:13 น.','','1','0','00003171','2022-06-09 10:41:14','2022-06-14 06:17:25','system',NULL,'0'),(167,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-153xx จำนวน : 4,993.00 บาท เมื่อวันที่ 10 มิ.ย. 2565 09:50:07 น.','','1','0','00004378','2022-06-10 09:50:08','2022-06-11 11:35:33','system',NULL,'0'),(168,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-169xx จำนวน : 18,500.00 บาท เมื่อวันที่ 13 มิ.ย. 2565 14:16:40 น.','','0','0','00003076','2022-06-13 14:16:42',NULL,'system',NULL,'0'),(169,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-153xx จำนวน : 2,993.00 บาท เมื่อวันที่ 16 มิ.ย. 2565 23:40:07 น.','','1','0','00004378','2022-06-16 23:40:09','2022-06-23 13:42:42','system',NULL,'0'),(170,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-155xx จำนวน : 200.00 บาท เมื่อวันที่ 22 มิ.ย. 2565 09:28:57 น.','','1','0','00004491','2022-06-22 09:28:57','2022-06-22 09:29:08','system',NULL,'0'),(171,'2','ฝากเงินธนาคาร','มีการชำระบิลเข้ามา จำนวนเงิน : 111.00 บาท เมื่อวันที่ 22 มิ.ย. 2565 09:33:03 น.','','1','0','00004491','2022-06-22 09:33:03','2022-06-23 21:10:28','system',NULL,'0'),(172,'2','ฝากเงินธนาคาร','มีการชำระบิลเข้ามา จำนวนเงิน : 109.00 บาท เมื่อวันที่ 23 มิ.ย. 2565 13:42:07 น.','','1','0','00004378','2022-06-23 13:42:07','2022-06-23 13:42:35','system',NULL,'0'),(173,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-153xx จำนวน : 1,993.00 บาท เมื่อวันที่ 23 มิ.ย. 2565 13:45:40 น.','','1','0','00004378','2022-06-23 13:45:41','2022-07-02 10:20:33','system',NULL,'0'),(174,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-155xx จำนวน : 10,543.00 บาท เมื่อวันที่ 27 มิ.ย. 2565 13:45:36 น.','','1','0','00004491','2022-06-27 13:45:37','2022-06-27 13:45:58','system',NULL,'0'),(175,'2','ฝากเงินธนาคาร','มีการชำระบิลเข้ามา จำนวนเงิน : 135.00 บาท เมื่อวันที่ 27 มิ.ย. 2565 13:47:37 น.','','1','0','00004491','2022-06-27 13:47:37','2022-06-27 13:48:29','system',NULL,'0'),(176,'2','ฝากเงินธนาคาร','มีการชำระบิลเข้ามา จำนวนเงิน : 99.00 บาท เมื่อวันที่ 29 มิ.ย. 2565 13:55:55 น.','','1','0','00004378','2022-06-29 13:55:55','2022-06-29 13:56:02','system',NULL,'0'),(177,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-153xx จำนวน : 4,003.00 บาท เมื่อวันที่ 29 มิ.ย. 2565 13:59:31 น.','','1','0','00004378','2022-06-29 13:59:32','2022-07-02 10:20:29','system',NULL,'0'),(178,'2','ฝากเงินธนาคาร','มีการชำระบิลเข้ามา จำนวนเงิน : 183.00 บาท เมื่อวันที่ 30 มิ.ย. 2565 13:19:41 น.','','1','0','00004491','2022-06-30 13:19:41','2022-06-30 13:20:22','system',NULL,'0'),(179,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-155xx จำนวน : 135.00 บาท เมื่อวันที่ 30 มิ.ย. 2565 13:21:28 น.','','1','0','00004491','2022-06-30 13:21:28','2022-06-30 13:21:48','system',NULL,'0'),(180,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-059xx จำนวน : 1,700.00 บาท เมื่อวันที่ 02 ก.ค. 2565 20:09:26 น.','','0','0','00003171','2022-07-02 20:09:27',NULL,'system',NULL,'0'),(181,'2','ฝากเงินธนาคาร','มีการชำระบิลเข้ามา จำนวนเงิน : 88.00 บาท เมื่อวันที่ 04 ก.ค. 2565 12:57:24 น.','','1','0','00004491','2022-07-04 12:57:24','2022-07-04 12:57:35','system',NULL,'0'),(182,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-155xx จำนวน : 199.00 บาท เมื่อวันที่ 04 ก.ค. 2565 12:58:28 น.','','1','0','00004491','2022-07-04 12:58:28','2022-07-04 12:58:38','system',NULL,'0'),(183,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-169xx จำนวน : 23.00 บาท เมื่อวันที่ 04 ก.ค. 2565 14:16:03 น.','','0','0','00005367','2022-07-04 14:16:04',NULL,'system',NULL,'0'),(184,'2','ฝากเงินธนาคาร','มีการชำระบิลเข้ามา จำนวนเงิน : 23.00 บาท เมื่อวันที่ 04 ก.ค. 2565 14:18:46 น.','','0','0','00005367','2022-07-04 14:18:46',NULL,'system',NULL,'0'),(185,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-153xx จำนวน : 6,000.00 บาท เมื่อวันที่ 04 ก.ค. 2565 14:19:51 น.','','1','0','00004378','2022-07-04 14:19:52','2022-07-14 14:03:15','system',NULL,'0'),(186,'2','ฝากเงินธนาคาร','มีการชำระบิลเข้ามา จำนวนเงิน : 123.00 บาท เมื่อวันที่ 06 ก.ค. 2565 10:04:56 น.','','1','0','00004491','2022-07-06 10:04:56','2022-07-06 10:05:35','system',NULL,'0'),(187,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-001xx จำนวน : 101.00 บาท เมื่อวันที่ 06 ก.ค. 2565 10:10:42 น.','','1','0','00004491','2022-07-06 10:10:44','2022-07-06 10:10:54','system',NULL,'0'),(188,'2','ฝากเงินธนาคาร','มีการชำระบิลเข้ามา จำนวนเงิน : 112.00 บาท เมื่อวันที่ 06 ก.ค. 2565 11:39:09 น.','','1','0','00004491','2022-07-06 11:39:09','2022-07-06 11:39:21','system',NULL,'0'),(189,'2','ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : xxx-00-083xx จำนวน : 321.00 บาท เมื่อวันที่ 06 ก.ค. 2565 11:41:25 น.','','1','0','00004491','2022-07-06 11:41:26','2022-07-06 11:41:42','system',NULL,'0');
/*!40000 ALTER TABLE `gchistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gclinenotify`
--

DROP TABLE IF EXISTS `gclinenotify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gclinenotify` (
  `id_linenotify` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `line_token` varchar(200) NOT NULL,
  `member_no` char(8) NOT NULL,
  `request_date` datetime NOT NULL DEFAULT current_timestamp(),
  `is_receive` enum('0','1','-8','-9') NOT NULL DEFAULT '1',
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `revoke_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_linenotify`),
  KEY `member_no` (`member_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gclinenotify`
--

LOCK TABLES `gclinenotify` WRITE;
/*!40000 ALTER TABLE `gclinenotify` DISABLE KEYS */;
/*!40000 ALTER TABLE `gclinenotify` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gclive`
--

DROP TABLE IF EXISTS `gclive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gclive` (
  `id_live` smallint(3) NOT NULL,
  `live_url` text NOT NULL,
  `live_title` varchar(50) DEFAULT NULL,
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_use` enum('0','1','-9') NOT NULL DEFAULT '0',
  `update_by` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gclive`
--

LOCK TABLES `gclive` WRITE;
/*!40000 ALTER TABLE `gclive` DISABLE KEYS */;
/*!40000 ALTER TABLE `gclive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcmemberaccount`
--

DROP TABLE IF EXISTS `gcmemberaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcmemberaccount` (
  `member_no` char(8) NOT NULL,
  `password` varchar(200) NOT NULL,
  `pin` varchar(200) DEFAULT NULL,
  `phone_number` char(10) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `account_status` enum('1','-6','-7','-8','-9') NOT NULL DEFAULT '1',
  `prev_acc_status` enum('1','-6','-7','-8','-9') NOT NULL DEFAULT '1',
  `temppass` varchar(200) DEFAULT NULL,
  `path_avatar` text DEFAULT NULL,
  `upload_from_channel` enum('mobile_app','web','unknown') NOT NULL DEFAULT 'unknown',
  `register_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `upload_date` datetime DEFAULT NULL,
  `register_channel` enum('mobile_app','web','unknown') NOT NULL DEFAULT 'unknown',
  `os_channel` varchar(50) DEFAULT NULL,
  `user_type` enum('0','1','5','9') NOT NULL DEFAULT '0',
  `line_token` varchar(200) DEFAULT NULL,
  `email_line` varchar(200) DEFAULT NULL,
  `receive_notify_news` enum('0','1','-9') NOT NULL DEFAULT '1',
  `receive_notify_transaction` enum('0','1','-9') NOT NULL DEFAULT '1',
  `receive_login_email` enum('0','1','-9') NOT NULL DEFAULT '1',
  `fcm_token` text DEFAULT NULL,
  `hms_token` text DEFAULT NULL,
  `counter_wrongpass` tinyint(1) NOT NULL DEFAULT 0,
  `temppass_is_md5` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`member_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcmemberaccount`
--

LOCK TABLES `gcmemberaccount` WRITE;
/*!40000 ALTER TABLE `gcmemberaccount` DISABLE KEYS */;
INSERT INTO `gcmemberaccount` VALUES ('00000873','$2y$10$rjG.Pwa0xRtkhPcGWlHfzOdTpEfZ0ptJpU9N26LyceLA/3LkBrerW','$2y$10$Jbyf6FRuGnw2bfs0F8.jmer9XZntMUjDeInqeOgjzxCO/vAG0851O','0899469141','sintorn2503@gmail.com','1','1',NULL,NULL,'unknown','2022-05-17 13:02:48','2022-05-17 13:03:24',NULL,'mobile_app',NULL,'0',NULL,NULL,'1','1','1','cQOWhXFbSWOGFTAt8uKAO-:APA91bFYtfc6VhUsb2ytEWJQP65OytlrVvc6U70TKqYSsRm2UCKgiL3Kfk_--C0F1gV7WmnAZN_wa3zZPDKsc3f8DzvJ5syvpGH_wdYrCJ7MfqzPVJTQibWpNrod0Wvw6LNpbsYWuWrE',NULL,0,'0'),('00002232','$2y$10$HZOP6oMTJmNCXt3r0kFBEOl8OdehRgt2/4cU8vNT4k8MBn29384R6','$2y$10$MjdWDmVtYc2Ym9nPIpWq1u1nb2BKaCBOSrMC6GXTUiO/8fU4ua5dq','0898460260','hnoy_ruedee@hotmail.com','1','1',NULL,NULL,'unknown','2022-05-17 12:32:14','2022-05-17 12:32:31',NULL,'mobile_app',NULL,'0',NULL,NULL,'1','1','1','ckfmjrdSf0jLqKXVacvjst:APA91bGos7MrJM7TpCI3eTB_e0mzFo0hYXuF1wET44zCCOaHT171Qcx13WInHkhNPNQeMQe28VcJ-N5NqQBLZ7KHxfb4Vuh77EBKvlzwSQNVLqt3DPlqtetc2wpQAp11-nERdLyWvoMB',NULL,0,'0'),('00002539','$2y$10$G2jQLnPwFhHYhrkurNydJuHue57sfmMP9ucBMbUTckevuP13o5jaq','$2y$10$HjKwcGSPfu1Fu7KxmcCLFu/YxOUWtlJ9JDVPXEq5nZZWmSM2xKQGS','0610284878','wassanaauppasan@gmail.com','1','1',NULL,NULL,'unknown','2022-05-17 13:14:55','2022-05-17 13:15:19',NULL,'mobile_app',NULL,'0',NULL,NULL,'1','1','1','fuG4A4zmQmyviORor04fo5:APA91bGw1O-DQPNfPXnSYBYkzudNyQVr5GB8jOjyvhkH5Fgl8I7_q4WpXOIHfCLI5fDcYlwIJ6Q6KilGMlUlMwgia-EH6_mbkFUaNiMQpToShFvG8M92J0p0miv1JIPr1FDgXqYVzliF',NULL,0,'0'),('00002799','$2y$10$aT5/AN.1/PjNeBjQgQ0US.0DWVud7YSzVf7bM7my1nDw14M7mreGa','$2y$10$BmEMBu5qQDntY7E0a8wrou0imeq5GDSPpw6V54VI7CFP2HqMvX27S','0840363699','suda.chueasing@gmail.com','1','1',NULL,NULL,'unknown','2022-05-17 12:42:13','2022-05-17 12:44:55',NULL,'mobile_app',NULL,'0',NULL,NULL,'1','1','1','csoyYPvLQky2CFZvcYn1nA:APA91bG4XU3JfLbb-Q7FJmOcLQiB-DPhXfNWkNcYxUBS-vETNmjXgFZNczDFOuA0_eM__I6CU9cgHJokyWiAZdAwEKrS6LoZTDU9n36zsGSwj3TAmwvhKZk2fRWYY5BXJQJL-eDbNC46',NULL,0,'0'),('00002949','$2y$10$BqjEFahTuyBEpQLu3UgyPOkhKouPTZAC.ifF8H1u936lxFE/NDbcm','$2y$10$RcnQa3aQsWfFjne3gfMCJOpCVF8jgshBDUDyWw2RdQpB4LPR4QrrC','0898650747','kunnikayp@gmil.com','1','1',NULL,NULL,'unknown','2022-05-17 12:32:36','2022-05-17 12:32:53',NULL,'mobile_app',NULL,'0',NULL,NULL,'1','1','1','eQ1CKBzwT0Mjhb94VSYVcQ:APA91bFGRsJ84Apgq4RAiytZUC73WHDM2b7F2eDgK7FxVjHMnbDZ0QwL78iu0wNmG7sh_jMlSadGXFQ2N2XQBWPspwfxRuZ8ww5YNOXuH4fWhcw0nqrWsKTQgi8YA6jjHtBp1XiOtIHm',NULL,0,'0'),('00003076','$2y$10$kJHKGbeldOpuHe1gnaDKtOtGz.Tcyf/D0c4kGmJSuUr3Mn7gh0hj6','$2y$10$IvkxLs4sMMT3lIktZljniOgNCunCj1m2apiVrZAgJZb.QRCZhNRk.','0898485927','meang.vilai@hotmail.com','1','1',NULL,NULL,'unknown','2022-05-17 13:31:07','2022-06-13 14:08:52',NULL,'mobile_app',NULL,'0',NULL,NULL,'1','1','1','fnpQxdu-QGmAWPcS-xacr-:APA91bEUehvjAjNloDDVTCggfoTMft9tExDu0QZNqWM6iBRELCpp0CplVeBfReZd4Xy8FFdF551xqUhn5_3D8Rzu5hV5V_aqb5UDXBaKZabCXqQ-XyjGCDc8hWzW7eNLvEFz6R4wVsqq',NULL,0,'0'),('00003089','$2y$10$fNcG2R.f02eDNVF7TX0sSeBSJri8QsxjnjF0Iv4pbW.iAzibZoPbO','$2y$10$8A/.z9fbEQZ.bAO9LDoWwexLOOAOhCVNHIE92uEiZ0svR57Y6ElFm','0895824224',NULL,'1','1',NULL,NULL,'unknown','2022-05-17 12:33:56','2022-05-17 12:34:35',NULL,'mobile_app',NULL,'0',NULL,NULL,'1','1','1','c1Gurw2TRlWCbzMZgJ5IFx:APA91bEYjnZXje1E3K_CQMMgt0v7JzGBUkdaBILL8lV3qjgSOp7rZkuvcsIj5MGcvmrYMWdzLaTnPfFE9bBRG2SCqn0wEdja4JQH50Kwhwwvww-MtQh3nfcmfNrquKNLrZSy4DMnOoJS',NULL,0,'0'),('00003171','$2y$10$Zch3rdSRcCwRJMvd1/JnP.8WuwJphIwQguht0gWF4EEr4lKG3rhmW','$2y$10$VvwBbaWo9W2guR7xIgPEeuC7k/MM9QhS.di/GXVNXrpYdvYDVe3eq','0815933618','pongtong933@gmail.com','1','1',NULL,NULL,'unknown','2022-05-17 12:31:38','2022-05-17 12:32:05',NULL,'mobile_app',NULL,'0',NULL,NULL,'1','1','1','cf9RpH_RSs-vKZzYt4spdd:APA91bHvlh0At3inl4CTSwjOD4Bh7QQuOF_XUv0v5HPZ-V29zFFvl9PNibcR7L5jN7Uv46r0G9Ma4_mcJPr7wnC7PMZTFw8nqVWcwR6XFT00HuMtvnn-p8oK9zKyvC6sGtz9HZuKRKUz',NULL,0,'0'),('00003823','$2y$10$zFvprLe3FoYr1BzlK609iuoHo52VoLLx3QHVxlOD4pwueLm.ECoLm','$2y$10$NhcDJEd.sP7AfIKOyYVwxOrD6zKM5D8ar.GZ8Md5HC68Z63bqgZA6','0992645259','towiwats@yahoo.co.th','1','1',NULL,NULL,'unknown','2022-05-23 12:46:08','2022-05-23 12:47:11',NULL,'mobile_app',NULL,'0',NULL,NULL,'1','1','1','fRZQTp9xRZePSbiek1nAkS:APA91bFn83c092VsSQLZCVMVjWnEaT9tkdOiFT-Wf8LgZjkzMoIYABaXLEpTXT25yj6Qj5VX9Ypc4DKpTLo156XDeu-y-w-eoLumkElkhawZugrXJt-BIxkzt7o1QMQdHLqi0JfDH4ZH',NULL,0,'0'),('00004356','$2y$10$46KMvvp8NSaTYwSrTBFiiedZqW6KSSsi2lsWzF5yI7mN/HbAeqboG','$2y$10$11HkB71ZEtQksjGAuo6w1.w6Wkz88MmWJSndLhvcu3GNlcq4CrJA2','0810729174',NULL,'1','1',NULL,'/resource/avatar/00004356/rLz4xL.jpeg','mobile_app','2022-05-24 14:59:30','2022-05-30 21:28:15','2022-05-30 21:28:15','mobile_app',NULL,'0',NULL,NULL,'1','1','1','cgt06DpQTP-MuVOTzmpZnL:APA91bHwFUG7AtgYERwAbjqhMuHrITwVzzJe26aSQF5MKzjawgjmV-71Qr5uA3sunoICKMQj1cdj6aPBWfEG9_WNFprlGZ9wPHEeoLeCOtccHcIVH3ao5e100IwJOebbQ1OWn4H1UOpU',NULL,0,'0'),('00004378','$2y$10$4tyqDIRRNpezlicFvk5BTOl53Jz2.ykmfWDGxc844wZ0reGasLwVe','$2y$10$zR7nGVcJfDUxycyzE584KexyS99DY.SVj1VIjQzsTxj.paxx26PJe','0876512036','rememberau@hotmail.co.th','1','1',NULL,'/resource/avatar/00004378/reCnV2.jpeg','mobile_app','2021-12-15 13:12:56','2021-12-15 13:14:30','2021-12-15 13:14:30','mobile_app',NULL,'0',NULL,NULL,'1','1','1','c9toPm_sN00Ava9X0Ui73V:APA91bE__npMkeu8gBG_bUjlrmWCM00BTlbSigjNdA0XO9r612qa5VE8DS2sNle7_CJXYZ5esrJi0VTePeojhPcxV0ToipgNq7FqK-g9Co7s5YKHRIKcTHYh9P831usHY40trKCAPvXZ',NULL,0,'0'),('00004408','$2y$10$t3aq53HB2o2F/Gf3fnVowekOKHOJ7oFs4MKDm6vbOyzPiAfFrxaJK','$2y$10$rgsAN40KBkCZ5TskCffb/Oy/lp2hFUKFtWXwO1Qxy0BygHYIRKC/i','0880248888',NULL,'1','1',NULL,NULL,'unknown','2022-05-17 13:17:25','2022-05-17 13:17:35',NULL,'mobile_app',NULL,'0',NULL,NULL,'1','1','1','e8JNwlxZSTmO3v5Z2_4S9O:APA91bHJ5Gn-PvP1z3uc5d4ozALjdVTYvc9VD0jdAqBuEd2iLNIBhROMZI0of1YodFR7NUj5F4MW-6zRp46utxvWIbaAWdaxfi4kzcbM3EuCUI2Yd3OjX_qOgHEh5mkm7qGiO1wTL9Oj',NULL,0,'0'),('00004491','$2y$10$6qwUZArHOlktg2w66e4jNOIk.ZKazR3d9UeFuTkRZEHeCs8Mi.Q7q','$2y$10$8nqNBXxY6v82Z8HgXmbnV.AL67WxyJTz0awHVAWJphdt1gJ9abM42','0634561953','sc.chanamee@gmail.com','1','1',NULL,NULL,'unknown','2022-03-08 17:06:29','2022-05-27 10:34:51',NULL,'mobile_app',NULL,'0',NULL,NULL,'1','1','1','focjIJpmROOAZtKkM4MZt4:APA91bGoZfNOWW6L2SIPXDIOg1EL0Fp7cpaIOrXyOOfkt1KJhs4MtiFKdpeQzb3qGhUUNfZHvjM3dlhwO14yObSvvokNgWyZMxzLVqu1DrqHgimWbuJWq6ekko8qdv-aFvtJtSAjn-ig',NULL,0,'0'),('00005060','$2y$10$okBCgKqDNUhIyzE7Vqv3OeRYmrhvBYoaghhXMsft9wu5RdrbR22/G','$2y$10$ZinR2dvg5FUsd.tT9SRZAuptha2OS/ZAmA8PdBpTU6R0nX4vCI.N6','0994746417','kapooklook-na@hotmail.com','1','1',NULL,'/resource/avatar/00005060/3nrq7o.jpeg','mobile_app','2021-12-15 13:12:04','2021-12-15 13:13:06','2021-12-15 13:13:06','mobile_app',NULL,'0',NULL,NULL,'1','1','1','fwNQekBy50H0tujz0Fe_j-:APA91bGaqjknEb1tntl-DLKA7AN7-DQzb4PoQBEiH31-RnRAqQq3i2EVrfmjSDlKqRDkgY3TIdXoMcH_pvFFEghRnWiTkgMF7zHlAPqS7faTh4eu88IxE16LJh3fA6jXPoGXS91tgjRW',NULL,0,'0'),('00005357','$2y$10$qP7VJccPQcnbLXJjv3lRV.MjgkOjXP6eemM2PJ3nPMulnTe5ou/tW','$2y$10$.k8l30nTN13P/6.0yAnFku7iBkESVZiyOzDhXEJhoXZuRi2N6IeYy','0821528248','kib.kunyaphon@gmail.com','1','1',NULL,'/resource/avatar/00005357/t3sZll.jpeg','mobile_app','2022-05-24 14:58:54','2022-05-24 15:02:42','2022-05-24 15:02:42','mobile_app',NULL,'0',NULL,NULL,'1','1','1','cS7UKtraK01Zr1vMfb4YS-:APA91bEiJ1_MAo8LnMlrVTAlM3PQV8bv9lf-itc8WHQvglJb350uOe0U7Y1NR-rLCA37XVeIDSdMnN_5mYB8aHISgWyGEMPMu9wA0fHlhVIld77hyGX8ut3mK98kdqcWzwqCsq3nG5t9',NULL,0,'0'),('00005367','$2y$10$HmjsRcyAQfMbPekUPUQMWOqlAP1wmIs3RpAGXxNwwUVj33B.ykZX6','$2y$10$cP.B0WOU4Q89Ds5YrexB0evsvHsNPr20ZSLZHt5qnZ0Hh9yI0qeIa','0897176694','janeung@hotmail.co.th','1','1',NULL,NULL,'unknown','2022-05-17 12:16:52','2022-05-17 12:17:01',NULL,'mobile_app',NULL,'0',NULL,NULL,'1','1','1','fYBXKNBFRjC0mdUX7ENBe6:APA91bHrTo7i6P8SULYYBEGFrXZTZvX3vZuq68-V_2Cxw2BHFVn7b77yxW6UJjJyS6EHX45mAJDGepAvx6hLciZKglFKIjT4L36KeRvreRx6AjOW5W2MfpdqS3jpmjTFY_2DN8m200Gi',NULL,0,'0'),('dev@mode','$2y$10$3S5TNPvzNLV8tvhOrfoDkuB4FRAzNrkK5DVdK4u05xpialXRGt11S','$2y$10$2gBXLEyNV1dW2zNomKSWWe96tQ3YTLcYLGF0y.mijLZ94NX17zpam','0637891888','support@gensoft.co.th','1','1',NULL,'/resource/avatar/dev@mode/8MZ53m.jpeg','mobile_app','2019-10-23 15:38:33','2022-04-07 14:21:34','2020-04-08 17:53:00','unknown',NULL,'9',NULL,NULL,'1','1','1','fDNbVSLpcky_ka7Dh_vjA5:APA91bHgam6vVubj0BDB8xRZn7u0zeGn4ISSFFInML9O0kwmTo_ofE41Sal_194YOlT6RIRFlUB35GsK061o7LgiL4PfljX_OSQCrvCRa60OnB7G3WD5nY1AJ0W0fg6JGF7WeB-pt43I',NULL,0,'0'),('etnmode1','$2y$10$1x5BNcCKE53c/dEdrpOOa.24Yh0DHFSEXVRSKqiPcxmuCshF7x5K.','$2y$10$ijS7ZiKEUKsS6g0KjIlDtuq9b6.7IVE1Ybd7badeB./Mlo8CGbtxu','0637891888','chatchai.p@gensoft.co.th','1','1','$2y$10$Hd2jzWJ1p5wkGo.jctCHKuJx2HWlDbmS3G6Pyj6gaa/dRpTEkSQr.','/resource/avatar/etnmode1/F6ug5D.jpeg','mobile_app','2019-11-21 21:20:25','2022-06-07 16:04:14','2020-10-14 11:03:25','unknown',NULL,'0',NULL,NULL,'1','1','1','f2TKBbxUT1CZbxBnwqmpYV:APA91bGFU5A8EjsWQ4qyGeTEZRagLISwMtacFrEJCzzjxTqUoazNwD4dkvBQ9VbmJixkhEohjztuRYic_Y1L7s8jMfBsMhYVIuvtmo4-m1y5wLJWzvktAlbGztZFd8xsZ_ugJSKRQ3l4','IQAAAACy0m-iAAAbdm9-3MoA-IH_Qw9spCFdba66H55xf03tFE3EdkzYhx4VIXa_Xt_GR-nvYBsL7xCNxycUzgphxnciVJ_lyScqp37z4EKlOrvyRw',0,'0'),('etnmode2','$2y$10$qiPhWZle/fn4ZO6ul2/AF.cuqys4Jo/xwMep2rQiEy8C4sE8p/Wgm','$2y$10$ijS7ZiKEUKsS6g0KjIlDtuq9b6.7IVE1Ybd7badeB./Mlo8CGbtxu','0637891888','support@gensoft.co.th','1','1',NULL,'/resource/avatar/etnmode2/m6XCpk.jpeg','mobile_app','2020-01-08 10:08:24','2021-09-29 15:01:18','2021-07-22 15:41:18','unknown',NULL,'1',NULL,NULL,'1','1','1','cEg8Kwg5aEg6mLg4txcCW9:APA91bFE94YJ6E1QBXxQuc0jLphmn3IvQkMghg2x2l__okUWojpym6uABTA14AmdE6HELNAl0Fu1AqnG5AlfRaVV3XhZSQA0H5lNfwSB-ZZpfHb-MdrooWZ1r3tF2A5h1ex5Rz1jq3xG',NULL,0,'0'),('etnmode3','$2y$10$qiPhWZle/fn4ZO6ul2/AF.cuqys4Jo/xwMep2rQiEy8C4sE8p/Wgm','$2y$10$ijS7ZiKEUKsS6g0KjIlDtuq9b6.7IVE1Ybd7badeB./Mlo8CGbtxu',NULL,'nanthawat.f@yahoo.com','1','1','$2y$10$xLUQ/mEFYMMvlnwRtb9keelhg.7IWAM7TjBMzAs7v87jR.EvjU2cm','/resource/avatar/etnmode3/pnuxvU.jpeg','mobile_app','2020-01-08 10:09:02','2021-12-15 12:06:44','2021-06-24 14:38:30','unknown',NULL,'0',NULL,NULL,'1','1','1','fpBqEjmOJkKrvExZ44crHn:APA91bGNkngJoxNNadip9Dy9BXDdbdZQOYKpLpY0lliduIaGIinbkLiQsL-u3Y7dyljNNJXo8pO1DOyVFsyV9bqJSwK_b89Q4Rd_SV7DegCZu6NxhsZ8Pfy-H2e3LoxAoHgYqfAg3qF6',NULL,0,'0'),('etnmode4','$2y$10$qiPhWZle/fn4ZO6ul2/AF.cuqys4Jo/xwMep2rQiEy8C4sE8p/Wgm','$2y$10$ijS7ZiKEUKsS6g0KjIlDtuq9b6.7IVE1Ybd7badeB./Mlo8CGbtxu','0992409191','isocare.one@gmail.com','1','1','$2y$10$Anv.JXS/A0QB.VY2zTgF8OCTwuxmkrEY03Dws0ZeysAgU89wKqwf.',NULL,'unknown','2020-02-19 02:14:38','2022-02-28 15:14:54',NULL,'unknown',NULL,'1',NULL,NULL,'1','1','1','fDw7khCaA0xxoy-h9xtJpv:APA91bHr-lsW09rqSGys3SJvYAxTobJ368hnMQhu9cxCZn7MiFoSHzBFMedYqeAe7-1DF5LQMPfy8mZ0gnU9VYbjiTAmVzqGWqLjlXFv_lJFsW_9PuG2llqxS6a_wy7tA6sYdkgugIVU',NULL,0,'0'),('salemode','$2y$10$v5mtKjlS7xVwxXokti60v.XZfBgys9.J/MxutNuJXRtf0zuAIIQJe','$2y$10$X8.xl5OhAHcgBvmxW96uEuCbGTLPK9K/oDHGfkOC7WdCsr2iPPZlu','0637891888','sale@gensoft.co.th','1','1',NULL,'/resource/avatar/salemode/FaIEHZ.jpeg','mobile_app','2019-10-23 15:38:33','2020-04-21 14:41:29','2020-02-01 16:54:42','unknown',NULL,'5',NULL,NULL,'1','1','1','c_DvPeicQqY:APA91bHdxKzWejzy63Jw9lf8XFd8G55TRziswUCG6tnNLFp1h1sNutksIjbrVeFxBmnog6CTCugqUM1YyQNZzslnj0j1C_YxqILj8QA1JpvKHKefwuPb8EJjZttLyC2t8Fm9cSyIzDmZ',NULL,0,'0');
/*!40000 ALTER TABLE `gcmemberaccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcmemodept`
--

DROP TABLE IF EXISTS `gcmemodept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcmemodept` (
  `id_memo` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `memo_text` varchar(150) DEFAULT NULL,
  `memo_icon_path` varchar(150) DEFAULT NULL,
  `deptaccount_no` varchar(15) NOT NULL,
  `seq_no` varchar(5) NOT NULL,
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `insert_date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_memo`),
  KEY `FETCH_DEPTACCOUNT_NO` (`deptaccount_no`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcmemodept`
--

LOCK TABLES `gcmemodept` WRITE;
/*!40000 ALTER TABLE `gcmemodept` DISABLE KEYS */;
INSERT INTO `gcmemodept` VALUES (1,'ทดสอบบ',NULL,'1000000240','279','2021-07-01 09:20:19','2021-07-01 09:20:19'),(2,'ทดสอบบ',NULL,'1000000240','280','2021-07-01 09:21:09','2021-07-01 09:21:09'),(3,'สอบทด',NULL,'1000000240','281','2021-07-01 09:22:01','2021-07-01 09:22:01'),(4,'ทดสอบชำหรถ',NULL,'1000000240','282','2021-07-01 09:32:42','2021-07-01 09:32:42'),(5,'',NULL,'0010133923','2004','2021-08-23 16:21:33','2021-08-23 16:21:33'),(6,'ทดสอบบ',NULL,'0010101265','2005','2021-08-23 16:21:52','2021-08-23 16:21:52'),(7,'กกกกก',NULL,'0010224479','2026','2021-09-27 11:00:27','2021-09-27 11:00:27'),(8,'ถัั',NULL,'0010224479','2027','2021-09-27 11:27:42','2021-09-27 11:27:42'),(9,'ทดสอบบ',NULL,'0010202133','2010','2021-10-04 11:43:03','2021-10-04 11:43:03'),(10,'Bskckk',NULL,'0010226846','2010','2021-10-04 17:29:58','2021-10-04 17:29:58'),(11,NULL,NULL,'0010226846','2011','2021-10-05 09:49:11','2021-10-05 09:49:11'),(12,NULL,NULL,'0010226846','2011','2021-10-06 10:54:10','2021-10-06 10:54:10'),(13,'Sddd',NULL,'0010100708','2004','2021-10-07 16:09:19','2021-10-07 16:09:19'),(14,'Ffff',NULL,'0010100708','2006','2021-10-07 16:23:28','2021-10-07 16:23:28'),(15,'Dxxf',NULL,'0010133036','2026','2021-10-07 16:24:23','2021-10-07 16:24:23'),(16,'',NULL,'0010133036','2028','2021-10-07 16:27:10','2021-10-07 16:27:10'),(17,'Ndkckk',NULL,'0010133036','2030','2021-10-07 16:28:50','2021-10-07 16:28:50'),(18,NULL,NULL,'0010133036','2032','2021-10-08 15:56:29','2021-10-08 15:56:29'),(19,'',NULL,'0010133036','2033','2021-10-08 16:07:01','2021-10-08 16:07:01'),(20,'',NULL,'0000015551','193','2021-12-08 22:17:35','2021-12-08 22:17:35'),(21,'รีไฟแนนซ์ธนชาติ',NULL,'1000004780','347','2021-12-12 20:24:50','2021-12-12 20:10:06'),(22,'ถอนเงินก้อน\nครั้งที่​ 5\n(จ่ายฌาปนกิจคืนโบว์)\n30,000​ บาท','loan','1000004780','386','2021-12-12 20:32:08','2021-12-12 20:11:48'),(23,'สสปท.','loan','1000004780','384','2021-12-12 20:13:35','2021-12-12 20:12:42'),(24,'สสปท.','loan','1000004780','383','2021-12-12 20:13:01','2021-12-12 20:13:01'),(25,'สสธท.','loan','1000004780','382','2021-12-12 20:15:50','2021-12-12 20:13:53'),(26,'สสธท.','loan','1000004780','381','2021-12-12 20:16:01','2021-12-12 20:14:43'),(27,'สสธท.','loan','1000004780','380','2021-12-12 20:16:14','2021-12-12 20:14:57'),(28,'กสธท.','loan','1000004780','379','2021-12-12 20:15:31','2021-12-12 20:15:31'),(29,'สสธท.','loan','1000004780','380','2021-12-12 20:17:04','2021-12-12 20:17:04'),(30,'กสธท.','loan','1000004780','378','2021-12-12 20:17:30','2021-12-12 20:17:30'),(31,'กสธท.','loan','1000004780','377','2021-12-12 20:17:45','2021-12-12 20:17:45'),(32,'เงินปันผล',NULL,'1000004780','358','2021-12-12 20:18:12','2021-12-12 20:18:12'),(33,'ฌาปนกิจ​ ปี​64\n~38,000​ บาท',NULL,'1000004780','385','2021-12-12 20:23:32','2021-12-12 20:21:58'),(34,'ฌาปนกิจ​ ปี​64\n~38,000​ บาท',NULL,'1000004780','385','2021-12-12 20:23:32','2021-12-12 20:22:58'),(35,'ถอนเงินก้อน\nครั้งที่​ 1\n30,000','loan','1000004780','350','2021-12-12 20:25:45','2021-12-12 20:25:45'),(36,'ถอนเงินก้อน\nครั้งที่​ 2\n20,000​ บาท','loan','1000004780','351','2021-12-12 20:27:28','2021-12-12 20:27:28'),(37,'ถอนเงินก้อน\nครั้งที่​ 3\n(พี่เนสยืม)\n20,000​ บาท','loan','1000004780','352','2021-12-12 20:28:24','2021-12-12 20:28:18'),(38,'ถอนเงินก้อน\nครั้งที่​ 4\n(ปันผล)\n17,000 บาท','loan','1000004780','360','2021-12-12 20:32:57','2021-12-12 20:32:57'),(39,'เงินกรุงไทยอเนกประสงค์\n1.5​ ล้าน\nหลังปิดหนี้เหลือ​ 200,000 บาท',NULL,'1000004780','346','2021-12-12 20:35:22','2021-12-12 20:35:22'),(40,'',NULL,'0000015551','207','2022-05-09 14:03:38','2022-05-09 14:03:38'),(41,'',NULL,'0000015551','212','2022-05-24 14:13:13','2022-05-24 14:13:13'),(42,'',NULL,'0000016937','14','2022-05-25 14:09:24','2022-05-25 14:09:24'),(43,'',NULL,'0000015551','214','2022-05-25 14:11:47','2022-05-25 14:11:47'),(44,'ดบ.',NULL,'1000006771','195','2022-05-30 21:31:18','2022-05-30 21:31:18'),(45,'ดบ.',NULL,'1000006771','195','2022-05-30 21:31:32','2022-05-30 21:31:32'),(46,'เอเจมา','holiday','1000006771','193','2022-05-30 21:32:21','2022-05-30 21:32:06'),(47,'เพื่อนพ่อยืม','loan','1000006771','180','2022-05-30 21:35:13','2022-05-30 21:34:50'),(48,'เพื่อนพ่อยืม','loan','1000006771','180','2022-05-30 21:35:21','2022-05-30 21:35:21'),(49,'',NULL,'0000015340','501','2022-06-08 13:53:50','2022-06-08 13:53:50'),(50,'',NULL,'0000015551','219','2022-06-08 13:55:00','2022-06-08 13:55:00'),(51,'',NULL,'0000015340','504','2022-06-09 10:25:29','2022-06-09 10:25:29'),(52,'',NULL,'0000005977','284','2022-06-09 10:41:14','2022-06-09 10:41:14'),(53,'',NULL,'0000015340','506','2022-06-10 09:50:08','2022-06-10 09:50:08'),(54,'',NULL,'0000016952','4','2022-06-13 14:16:41','2022-06-13 14:16:41'),(55,'',NULL,'0000015340','508','2022-06-16 23:40:08','2022-06-16 23:40:08'),(56,'ทดสอบถอนดึงบัญชี',NULL,'0000015551','222','2022-06-22 09:28:57','2022-06-22 09:28:57'),(57,'',NULL,'0000015340','512','2022-06-23 13:45:40','2022-06-23 13:45:40'),(58,'',NULL,'0000015551','226','2022-06-27 13:45:37','2022-06-27 13:45:37'),(59,'',NULL,'0000015340','516','2022-06-29 13:59:32','2022-06-29 13:59:32'),(60,'',NULL,'0000015551','230','2022-06-30 13:21:28','2022-06-30 13:21:28'),(61,'',NULL,'0000005977','286','2022-07-02 20:09:27','2022-07-02 20:09:27'),(62,'',NULL,'0000015551','233','2022-07-04 12:58:28','2022-07-04 12:58:28'),(63,'',NULL,'0000016937','21','2022-07-04 14:16:04','2022-07-04 14:16:04'),(64,'',NULL,'0000015340','518','2022-07-04 14:19:52','2022-07-04 14:19:52'),(65,'',NULL,'1400000106','3','2022-07-06 10:10:43','2022-07-06 10:10:43'),(66,'',NULL,'0100008365','54','2022-07-06 11:41:26','2022-07-06 11:41:26');
/*!40000 ALTER TABLE `gcmemodept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcmenu`
--

DROP TABLE IF EXISTS `gcmenu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcmenu` (
  `id_menu` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(40) NOT NULL,
  `menu_name_en` varchar(40) DEFAULT NULL,
  `menu_icon_path` varchar(100) DEFAULT NULL,
  `menu_status` enum('0','1','-9') NOT NULL DEFAULT '1',
  `menu_component` varchar(50) DEFAULT NULL,
  `menu_permission` enum('0','1','2','3') NOT NULL DEFAULT '0',
  `menu_parent` tinyint(3) DEFAULT 0,
  `menu_version` varchar(10) DEFAULT NULL,
  `menu_order` tinyint(3) NOT NULL DEFAULT -1,
  `menu_channel` enum('mobile_app','web','both') NOT NULL DEFAULT 'both',
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcmenu`
--

LOCK TABLES `gcmenu` WRITE;
/*!40000 ALTER TABLE `gcmenu` DISABLE KEYS */;
INSERT INTO `gcmenu` VALUES (1,'เงินฝาก','Deposits','menu_deposit','1','DepositInfo','0',0,'0.0.1',20,'both','2022-05-17 09:56:12','2019-10-23 15:38:33'),(2,'เงินกู้','Loan','menu_loan','1','LoanInfo','0',0,'0.0.1',21,'both','2021-12-15 12:08:21','2019-10-23 15:38:33'),(3,'หุ้น','Share','menu_share','1','ShareInfo','0',0,'0.0.1',2,'both','2021-12-15 12:07:53','2019-10-23 15:38:33'),(4,'สิทธิ์กู้โดยประมาณ','Loan estimate','menu_loancredit','-9','LoanCredit','0',0,'0.0.1',5,'mobile_app','2021-10-18 10:37:37','2019-10-23 15:38:33'),(5,'ภาระค้ำประกัน','Guarantees','menu_guarantee','1','GuaranteeInfo','0',0,'0.0.1',4,'both','2021-12-15 12:07:59','2019-10-23 15:38:33'),(6,'ปันผล - เฉลี่ยคืน','Dividend','menu_dividend','1','DividendInfo','0',0,'0.0.1',7,'both','2021-12-15 12:08:00','2019-10-23 15:38:33'),(7,'เรียกเก็บประจำเดือน','Keeping monthly','menu_paymentmonthly','1','PaymentMonthlyInfo','0',0,'0.0.1',3,'both','2021-12-15 12:08:00','2019-10-23 15:38:33'),(8,'ใบเสร็จ','Slips','menu_slip','1','SlipInfo','0',0,'0.0.1',22,'both','2021-01-14 10:01:10','2019-10-23 15:38:33'),(9,'ขอกู้ออนไลน์','Request loan online','menu_loanrequest','-9','LoanRequest','0',18,'0.0.1',26,'both','2021-05-27 16:01:07','2019-10-23 15:38:33'),(10,'ผู้รับโอนผลประโยชน์','Beneficiary','menu_beneficalry','0','BeneficiaryInfo','0',0,'0.0.1',6,'mobile_app','2022-03-04 12:37:25','2019-10-23 15:38:33'),(11,'สวัสดิการ','Welfare','menu_assist','-9','AssistInfo','0',0,'0.0.1',8,'web','2020-10-14 14:14:20','2019-10-23 15:38:33'),(12,'ประกัน','Insurance','menu_insure','-9','InsureInfo','0',0,'0.0.1',23,'both','2020-07-03 10:02:36','2019-10-23 15:38:33'),(13,'ตารางประมาณการชำระ','Simulate payment','menu_paymenttable','1','PaymentSimulateTable','0',0,'0.0.1',8,'both','2021-12-15 12:08:01','2019-10-23 15:38:33'),(14,'ฌาปนกิจ','Cremation','menu_cremation','-9','CremationInfo','0',0,'0.0.1',22,'mobile_app','2020-07-03 10:02:36','2019-10-23 15:38:33'),(15,'ข่าวสาร','News','menu_news','1','News','0',0,'0.0.1',23,'both','2021-01-14 10:01:10','2019-10-23 15:38:33'),(18,'ธุรกรรม','Transaction','menu_transaction','1','Transaction','0',-9,'0.0.1',10,'mobile_app','2022-05-06 15:59:19','2019-10-23 15:38:33'),(19,'โอนเงินฝากภายในบัญชีตนเอง','Transfer inside myself','menu_transfer_myself','0','TransferSelfDepInsideCoop','0',18,'0.0.6',27,'web','2022-05-17 10:05:10','2019-10-23 15:38:33'),(20,'โอนเงินฝากภายในบัญชีสหกรณ์','Transfer inside coop','menu_transfer_incoop','0','TransferDepInsideCoop','0',18,'0.0.6',28,'web','2022-05-17 09:58:32','2019-10-23 15:38:33'),(21,'โอนเงินฝากชำระหนี้','Transfer payment loan','menu_transfer_loan_payment','0','TransferDepPayLoan','0',18,'0.0.1',29,'web','2022-05-17 09:57:35','2019-10-23 15:38:33'),(22,'โอนเงินฝากไปซื้อหุ้น','Transfer buy shares','menu_transfer_buy_share','-9','TransferDepBuyShare','0',18,'0.0.1',30,'both','2021-06-18 11:54:52','2019-10-23 15:38:33'),(24,'ตั้งค่า','Setting',NULL,'1','Setting','0',0,'0.0.1',25,'both','2021-12-15 12:08:25','2019-10-23 15:38:33'),(25,'เปลี่ยนรหัสผ่าน','Change password','setting_password','1','SettingChangePassword','0',24,'0.0.1',34,'both','2020-04-07 14:37:48','2019-10-23 15:38:33'),(26,'เปลี่ยนรหัส PIN','Change pin','setting_pin','1','ChangePin','0',24,'0.0.1',35,'mobile_app','2020-04-14 17:33:55','2019-10-23 15:38:33'),(27,'จัดการอุปกรณ์','Manage device','setting_devices','1','SettingManageDevice','0',24,'0.0.1',36,'both','2020-04-14 17:34:09','2019-10-23 15:38:33'),(28,'จัดการการแจ้งเตือน','Manage notification','setting_notification','1','SettingManageNotification','0',24,'0.0.1',37,'mobile_app','2020-06-11 14:54:36','2019-10-23 15:38:33'),(29,'ขนาดตัวอักษร','Font size','setting_font','1','SettingFontSize','0',24,'0.0.1',38,'mobile_app','2021-05-07 15:04:33','2019-10-23 15:38:33'),(30,'เปิดใช้งาน Touch ID / Face ID','Enable touch ID / face ID','setting_faceid','1','SettingFaceID','0',24,'0.0.1',39,'mobile_app','2020-04-07 14:37:48','2019-10-23 15:38:33'),(31,'แสดงเลขบัญชีบางส่วน','Show some account no number','setting_hideaccount','1','SettingHideAccount','0',24,'0.0.1',40,'both','2020-04-07 14:37:48','2019-10-23 15:38:33'),(33,'คำถามที่พบบ่อย','FAQ','setting_question','1','SettingQuestion','0',24,'0.0.1',41,'both','2020-04-14 17:34:05','2019-10-23 15:38:33'),(34,'เวอร์ชันแอปพลิเคชัน','Version application','setting_store','1','AppVersion','0',24,'0.0.1',43,'mobile_app','2022-06-05 23:15:17','2019-10-23 15:38:33'),(35,'กิจกรรมของสหกรณ์','Event',NULL,'1','Event','0',15,'0.0.1',20,'both','2020-04-07 14:37:48','2019-10-23 15:38:33'),(36,'สมัครขอใช้บริการ','Register',NULL,'1','AppRegister','0',-2,'0.0.1',34,'both','2020-02-29 19:45:45','2019-10-23 15:38:33'),(37,'แก้ไขข้อมูลสมาชิก','Edit member info',NULL,'-9',NULL,'0',-9,'0.0.1',29,'both','2020-07-03 10:02:36','2019-10-23 15:38:33'),(38,'ระบบ','System',NULL,'1','System','0',-1,'0.0.1',1,'both','2021-12-12 12:01:01','2019-10-23 15:38:33'),(39,'Statement เงินฝาก','Movements of deposit',NULL,'1','DepositStatement','0',-8,'0.0.1',18,'both','2021-12-15 12:08:18','2019-10-23 15:38:33'),(40,'Statement เงินกู้','Movements of loan',NULL,'1','LoanStatement','0',-8,'0.0.1',17,'both','2021-12-15 12:08:16','2019-10-23 15:38:33'),(41,'รายละเอียดเรียกเก็บประจำเดือน','Keeping monthly detail',NULL,'1','PaymentMonthlyDetail','0',-8,'0.0.1',15,'both','2021-12-15 12:08:28','2019-10-23 15:38:33'),(42,'แจ้งเตือน','Notification','menu_notification','1','Notification','0',0,'0.0.1',24,'both','2021-12-15 12:08:23','2019-10-23 15:38:33'),(43,'ข้อมูลส่วนตัว ','Member info',NULL,'1','MemberInfo','0',0,'0.0.1',19,'both','2021-12-15 12:08:19','2019-10-23 15:38:33'),(44,'ใบคำขอสวัสดิการ','Welfare request','menu_assistrequest','-9','AssistRequest','0',0,'0.0.1',30,'both','2020-07-03 10:02:36','2019-10-23 15:38:33'),(45,'รับเงินกู้สหกรณ์','Receive loan','menu_loanreceive','0','LoanReceive','0',18,'0.0.1',26,'mobile_app','2022-02-25 11:24:54','2019-10-26 03:25:51'),(46,'ฝากเงินเข้าบัญชี','Deposit to account','menu_deposit_to_account','0','TransactionDeposit','0',18,'0.0.1',25,'web','2022-05-17 09:56:26','2019-10-26 03:25:51'),(47,'Statement สวัสดิการ','Movements of welfare',NULL,'1','AssistStatement','0',-8,'0.0.1',13,'mobile_app','2022-02-25 11:24:26','2019-11-11 10:13:02'),(48,'ผูกบัญชี','Bind account',NULL,'1','BindAccountConsent','0',-9,'0.0.1',9,'mobile_app','2022-02-25 11:28:32','2019-11-18 10:09:07'),(49,'จัดการบัญชี','Manage account','menu_management_bank_account','1','ManagementAccount','0',18,'0.0.1',11,'mobile_app','2022-02-25 14:47:43','2019-11-21 13:51:09'),(50,'รายการโปรด','My Favorites','menu_management_favorite','-9','FavoriteAccount','2',0,'0.0.1',31,'mobile_app','2020-07-03 10:02:36','2019-11-26 10:28:20'),(51,'ภาษา','Language','setting_font','1','SettingLanguage','0',24,'0.0.3',31,'both','2020-04-21 14:34:46','2019-12-16 14:40:47'),(52,'ถอนเงินฝาก','Withdraw deposits','menu_withdraw_deposits','1','TransactionWithdrawDeposit','0',18,'0.0.1',24,'both','2021-05-27 16:00:34','2019-12-16 15:45:49'),(53,'แสดงยอดเงินที่หน้าหลัก','Enable view balance at home','setting_hideaccount','1','SettingEnableViewBalance','0',24,'1.1.0',45,'both','2020-06-11 14:53:48','2020-03-18 17:28:44'),(54,'OTP','OTP',NULL,'1','OTPChecker','0',-2,'0.0.1',-1,'both','2022-03-08 16:47:51','2020-03-23 15:47:12'),(55,'Statement ประกัน','Movements of Insurance',NULL,'1','InsureStatement','0',-8,'0.0.1',12,'mobile_app','2021-01-14 10:01:10','2020-05-11 11:35:16'),(56,'ธุรกรรมภายใน','Transfer in Coop','menu_transfer_myself','-9','TransferInsideCoop','0',18,'0.0.6',14,'mobile_app','2021-01-14 10:47:25','2020-05-18 14:38:42'),(57,'โอนบัญชีสหกรณ์กับธนาคาร','Transfer between Coop and Bank','menu_withdraw_deposits','-9','TransferOutsideCoop','0',18,'0.0.6',16,'mobile_app','2021-05-27 16:00:24','2020-05-18 14:38:42'),(58,'สถานะใบคำขอสวัสดิการ','Track Welfare request','menu_assistrequest','-9','AssistRequestTrack','0',0,'0.0.1',32,'both','2020-07-03 10:02:36','2020-06-23 20:53:45'),(59,'ใบคำขอกู้ออนไลน์','Form request loan online','menu_loanrequest','0','LoanRequestForm','0',18,'0.0.1',-1,'web','2022-01-24 17:13:34','2021-02-25 11:43:19'),(60,'ติดตามใบคำขอกู้ออนไลน์','Track Loan Request Online','menu_loanrequest_track','0','LoanRequestTrack','0',0,'0.0.1',-1,'both','2021-10-15 15:55:48','2021-02-25 11:44:29'),(61,'สแกน QR Code','Scan QR Code','menu_qrscanner','-9','QRCodeScanner','0',0,'1.3.1',-1,'both','2021-05-25 16:18:58','2021-05-25 16:18:58'),(62,'รีเซตรหัสผ่านด้วย SMS','Forget Password With SMS',NULL,'1','ForgetPasswordSMS','0',-2,'1.0.0',-1,'both','2022-03-08 16:48:21','2022-03-08 15:49:58'),(63,'สร้าง QR Code','Generate QR Code','menu_generate_qrcode','1','GenerateQR','0',18,'0.1.0',-1,'mobile_app','2022-05-06 15:59:33','2022-04-07 11:17:31'),(64,'ยินยอมให้ประมวลผลข้อมูล','Consent PDPA','','1','ConsentAgreement','0',-1,'1.0.0',-1,'both','2022-06-01 16:03:47','2022-06-01 16:03:47'),(65,'นโยบายการคุ้มครองข้อมูลส่วนบุคคล','Personal Data Protection Policy','menu_setting_privacy_policy','1','SettingPrivacyPolicy','0',24,'1.1.0',42,'mobile_app','2022-06-05 23:14:58','2022-06-05 23:14:58');
/*!40000 ALTER TABLE `gcmenu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcmenuconstantmapping`
--

DROP TABLE IF EXISTS `gcmenuconstantmapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcmenuconstantmapping` (
  `id_constantmapping` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `menu_component` varchar(50) NOT NULL,
  `id_bankconstant` mediumint(8) NOT NULL,
  `is_use` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_constantmapping`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcmenuconstantmapping`
--

LOCK TABLES `gcmenuconstantmapping` WRITE;
/*!40000 ALTER TABLE `gcmenuconstantmapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `gcmenuconstantmapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcnews`
--

DROP TABLE IF EXISTS `gcnews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcnews` (
  `id_news` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `news_title` varchar(200) DEFAULT NULL,
  `news_detail` text DEFAULT NULL,
  `news_html` longtext DEFAULT NULL,
  `path_img_header` text DEFAULT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `link_news_more` text DEFAULT NULL,
  `is_use` enum('0','1','-9') NOT NULL DEFAULT '1',
  `img_gallery_1` text DEFAULT NULL,
  `img_gallery_2` text DEFAULT NULL,
  `img_gallery_3` text DEFAULT NULL,
  `img_gallery_4` text DEFAULT NULL,
  `img_gallery_5` text DEFAULT NULL,
  `file_upload` text DEFAULT NULL,
  `create_by` varchar(20) NOT NULL,
  PRIMARY KEY (`id_news`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcnews`
--

LOCK TABLES `gcnews` WRITE;
/*!40000 ALTER TABLE `gcnews` DISABLE KEYS */;
INSERT INTO `gcnews` VALUES (1,'กำหนดเงินคงเหลือหลังหักหนี้ 30 สำหรับสมาชิกใหม่ ตั้งแต่วันที่ 1 มีนาคม 2565 เป็นต้นไป','','<!DOCTYPE HTML>\r\n									<html>\r\n									<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n								  <meta charset=\"UTF-8\">\r\n								  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n								  <p><a href=\"http://www.sunpasitcoop.com/coop/8-news/724-n08_2565.html\" target=\"_self\">กำหนดเงินคงเหลือหลังหักหนี้ 30% สำหรับสมาชิกใหม่ ตั้งแต่วันที่ 1 มีนาคม 2565 เป็นต้นไป</a></p>\n<p>&nbsp;&nbsp;</p>\n\r\n								  </body>\r\n									</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/7y9ffJ.jpeg','2022-02-28 14:10:29','2022-02-28 14:13:40','','1',NULL,NULL,NULL,NULL,NULL,NULL,'spsadmin'),(2,'แจ้งหยุดทำการ วันที่ 10-11 มีนาคม 2565 เนื่องจากไปศึกษาดูงาน','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>แจ้งหยุดทำการ วันที่ 10-11 มีนาคม 2565 เนื่องจากไปศึกษาดูงาน ณ สหกรณ์ออมทรัพย์ออมทรัพย์สาธารณสุขสุราษฎร์ธานี จำกัด  และจะเปิดทำการอีกครั้งในวันจันทร์ที่ 14 มีนาคม 2565</p>\n\r\n							  </body>\r\n								</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/skV9Zr.jpeg','2022-03-02 09:37:49','2022-03-02 09:37:49',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,'spsadmin'),(3,'รายการย่อแสดงสินทรัพย์และหนี้สิน กุมภาพันธ์ 2565','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p><a href=\"http://www.sunpasitcoop.com/coop/%E0%B8%A3%E0%B8%B2%E0%B8%A2%E0%B8%81%E0%B8%B2%E0%B8%A3%E0%B8%A2%E0%B9%88%E0%B8%AD%E0%B9%81%E0%B8%AA%E0%B8%94%E0%B8%87%E0%B8%AA%E0%B8%B4%E0%B8%99%E0%B8%97%E0%B8%A3%E0%B8%B1%E0%B8%9E%E0%B8%A2%E0%B9%8C%E0%B9%81%E0%B8%A5%E0%B8%B0%E0%B8%AB%E0%B8%99%E0%B8%B5%E0%B9%89%E0%B8%AA%E0%B8%B4%E0%B8%99/47-assets_debts_2565/726-assets_debts_022565.html\" target=\"_self\">รายการย่อแสดงสินทรัพย์และหนี้สิน กุมภาพันธ์ 2565</a></p>\n\r\n							  </body>\r\n								</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/H80eaB.jpeg','2022-03-03 09:24:30','2022-03-03 09:24:30',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,'spsadmin'),(4,'ผลการดำเนินงาน ประจำเดือนกุมภาพันธ์ 2565','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p><a href=\"http://www.sunpasitcoop.com/coop/%E0%B8%9C%E0%B8%A5%E0%B8%81%E0%B8%B2%E0%B8%A3%E0%B8%94%E0%B8%B3%E0%B9%80%E0%B8%99%E0%B8%B4%E0%B8%99%E0%B8%87%E0%B8%B2%E0%B8%99/45-overall_result_2565/727-overall_result_02_2565.html\" target=\"_self\">ผลการดำเนินงาน ประจำเดือนกุมภาพันธ์ 2565</a>&nbsp;</p>\n\r\n							  </body>\r\n								</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/0GcQOB.jpeg','2022-03-03 09:25:36','2022-03-03 09:25:36',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,'spsadmin'),(5,'รายชื่อสมาชิกสมทบ หน่วยพนักงานกระทรวงสาธารณสุข(พกส.) ที่ได้รับการปรับเป็นสมาชิกสามัญประจำเดือน มีนาคม 2565','','<!DOCTYPE HTML>\r\n									<html>\r\n									<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n								  <meta charset=\"UTF-8\">\r\n								  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n								  <p><a href=\"http://www.sunpasitcoop.com/coop/7-pressrelease/728-pks_03_2565.html\" target=\"_self\">รายชื่อสมาชิกสมทบ หน่วยพนักงานกระทรวงสาธารณสุข(พกส.) ที่ได้รับการปรับเป็นสมาชิกสามัญประจำเดือน มีนาคม 2565</a>&nbsp;&nbsp;</p>\n\r\n								  </body>\r\n									</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/1MyFdb.jpeg','2022-03-14 11:06:51','2022-03-14 11:50:14','','1',NULL,NULL,NULL,NULL,NULL,'https://proxy.thaicoop.co/SPSCOOP/resource/news/news_5.pdf?yqBAdO','spsadmin'),(6,'เชิญสมาชิก ส.ส.ป.ท. ประชุมใหญ่สามัญประจำปี 2565','','<!DOCTYPE HTML>\r\n									<html>\r\n									<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n								  <meta charset=\"UTF-8\">\r\n								  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n								  <p>เชิญสมาชิก ส.ส.ป.ท. ประชุมใหญ่สามัญประจำปี 2565 วันที่ 16 มีนาคม 2565 ณ หอประชุมมณีเทวา สหกรณ์ออมทรัพย์ครูอุบลราชธานี จำกัด ลงทะเบียน 09.00-10.00 น. เท่านั้น  กรุณานำบัตรประชาชนหรือบัตรที่ทางราชการออกให้ไปด้วย&nbsp;</p>\n\r\n								  </body>\r\n									</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/6z7MYf.jpeg','2022-03-15 09:42:43','2022-03-15 12:18:53','','1',NULL,NULL,NULL,NULL,NULL,NULL,'spsadmin'),(7,'โครงการทัศนศึกษาสมาชิก ประจำปี 2565','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p><a href=\"http://www.sunpasitcoop.com/coop/8-news/731-n11_2565.html\" target=\"_self\">โครงการทัศนศึกษาสมาชิก ประจำปี 2565</a></p>\n\r\n							  </body>\r\n								</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/hfgkCc.jpeg','2022-03-21 16:27:50','2022-03-21 16:27:50',NULL,'1',NULL,NULL,NULL,NULL,NULL,'https://proxy.thaicoop.co/SPSCOOP/resource/news/news_7.pdf?E3mmb2','spsadmin'),(8,'การให้กู้ เพื่อทัศนศึกษาสมาชิก จังหวัดสตูล (เกาะหลีเป๊ะ)','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p><a href=\"http://www.sunpasitcoop.com/coop/8-news/732-n12_2565.html\" target=\"_self\">การให้กู้ เพื่อทัศนศึกษาสมาชิก จังหวัดสตูล (เกาะหลีเป๊ะ)</a></p>\n\r\n							  </body>\r\n								</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/nI8lkx.jpeg','2022-03-23 16:26:05','2022-03-23 16:26:05',NULL,'1',NULL,NULL,NULL,NULL,NULL,'https://proxy.thaicoop.co/SPSCOOP/resource/news/news_8.pdf?QkfsBv','spsadmin'),(9,'รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน มีนาคม','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p><a href=\"http://www.sunpasitcoop.com/coop/images/pdf/ASS/2565/ASS_03_2565.pdf\" target=\"_self\">รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน มีนาคม</a>&nbsp;</p>\n\r\n							  </body>\r\n								</html>',NULL,'2022-03-25 09:06:05','2022-03-25 09:06:05',NULL,'1',NULL,NULL,NULL,NULL,NULL,'https://proxy.thaicoop.co/SPSCOOP/resource/news/news_9.pdf?f4wza0','spsadmin'),(10,'วารสารสหกรณ์ประจำเดือน มกราคม - มีนาคม 2565','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>วารสารสหกรณ์ประจำเดือน มกราคม - มีนาคม 2565</p>\n\r\n							  </body>\r\n								</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/Bc43lf.jpeg','2022-03-31 15:13:18','2022-03-31 15:13:18',NULL,'1',NULL,NULL,NULL,NULL,NULL,'https://proxy.thaicoop.co/SPSCOOP/resource/news/news_10.pdf?ClHWn5','spsadmin'),(11,'ผลการดำเนินงาน ประจำเดือนมีนาคม 2565','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>ผลการดำเนินงาน ประจำเดือนมีนาคม 2565</p>\n\r\n							  </body>\r\n								</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/tuFPFG.jpeg','2022-04-01 15:31:07','2022-04-01 15:31:41',NULL,'-9',NULL,NULL,NULL,NULL,NULL,NULL,'spsadmin'),(12,'ผลการดำเนินงาน ประจำเดือนมีนาคม 2565','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>ผลการดำเนินงาน ประจำเดือนมีนาคม 2565</p>\n\r\n							  </body>\r\n								</html>',NULL,'2022-04-01 15:32:45','2022-04-01 15:32:45',NULL,'1',NULL,NULL,NULL,NULL,NULL,'https://proxy.thaicoop.co/SPSCOOP/resource/news/news_12.pdf?WyhjEz','spsadmin'),(13,'ขยายวันที่แจ้งความจำนง เพื่อไปทัศนศึกษาสมาชิก จังหวัดสตูล (เกาะหลีเป๊ะ)','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>ขยายวันที่แจ้งความจำนง เพื่อไปทัศนศึกษาสมาชิก จังหวัดสตูล (เกาะหลีเป๊ะ)</p>\n\r\n							  </body>\r\n								</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/uaAEOk.jpeg','2022-04-04 16:02:51','2022-04-04 16:02:51',NULL,'1',NULL,NULL,NULL,NULL,NULL,'https://proxy.thaicoop.co/SPSCOOP/resource/news/news_13.pdf?Oam8D6','spsadmin'),(14,'แจ้งวันหยุดประจำเดือนเมษายน 2565','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>แจ้งวันหยุดประจำเดือนเมษายน 2565<br>วันที่ 6 เมษายน 2565 เนื่องในวันจักรี<br>วันที่ 13-15 เมษายน 256 เนื่องในวันสงกรานต์</p>\n\r\n							  </body>\r\n								</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/KErIfT.jpeg','2022-04-05 09:54:51','2022-04-05 09:54:51',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,'spsadmin'),(15,'รายชื่อสมาชิกสมทบ หน่วยพนักงานกระทรวงสาธารณสุข(พกส.) ที่ได้รับการปรับเป็นสมาชิกสามัญประจำเดือน เมษายน 2565','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>รายชื่อสมาชิกสมทบ หน่วยพนักงานกระทรวงสาธารณสุข(พกส.) ที่ได้รับการปรับเป็นสมาชิกสามัญประจำเดือน เมษายน 2565</p>\n\r\n							  </body>\r\n								</html>',NULL,'2022-04-18 10:14:26','2022-04-18 10:14:26',NULL,'1',NULL,NULL,NULL,NULL,NULL,'https://proxy.thaicoop.co/SPSCOOP/resource/news/news_15.pdf?DnwFlN','spsadmin'),(16,'สหกรณ์ยืนยันทัศนศึกษาสมาชิกประจำปี 2565 ตามจำนวนสมาชิกที่ได้แจ้งความจำนงไว้','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>สหกรณ์ยืนยันทัศนศึกษาสมาชิกประจำปี 2565 ตามจำนวนสมาชิกที่ได้แจ้งความจำนงไว้ แจ้งความจำนงได้จนถึงวันที่ 25 เมษายน 2565</p>\n\r\n							  </body>\r\n								</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/Z9rTqd.jpeg','2022-04-18 10:15:01','2022-04-18 10:15:01',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,'spsadmin'),(17,'รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน เมษายน','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน เมษายน</p>\n\r\n							  </body>\r\n								</html>',NULL,'2022-04-25 10:10:58','2022-04-25 10:10:58',NULL,'1',NULL,NULL,NULL,NULL,NULL,'https://proxy.thaicoop.co/SPSCOOP/resource/news/news_17.pdf?XuKOOz','spsadmin'),(18,'ขยายวันที่แจ้งความจำนง เพื่อไปทัศนศึกษาสมาชิก จังหวัดสตูล (เกาะหลีเป๊ะ) ถึงวันที่ 29 เมษายน 2565','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>ขยายวันที่แจ้งความจำนง เพื่อไปทัศนศึกษาสมาชิก จังหวัดสตูล (เกาะหลีเป๊ะ) ถึงวันที่ 29 เมษายน 2565</p>\n\r\n							  </body>\r\n								</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/K9ZbhI.jpeg','2022-04-25 10:11:34','2022-04-25 10:11:34',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,'spsadmin'),(19,'แจ้งวันหยุดประจำเดือนพฤษภาคม 2565','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>แจ้งวันหยุดประจำเดือนพฤษภาคม 2565</p>\n\r\n							  </body>\r\n								</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/S9sT6q.jpeg','2022-04-27 14:55:16','2022-04-27 14:55:16',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,'spsadmin'),(20,'รายการย่อแสดงสินทรัพย์และหนี้สิน เมษายน 2565','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p><a href=\"http://www.sunpasitcoop.com/coop/%E0%B8%A3%E0%B8%B2%E0%B8%A2%E0%B8%81%E0%B8%B2%E0%B8%A3%E0%B8%A2%E0%B9%88%E0%B8%AD%E0%B9%81%E0%B8%AA%E0%B8%94%E0%B8%87%E0%B8%AA%E0%B8%B4%E0%B8%99%E0%B8%97%E0%B8%A3%E0%B8%B1%E0%B8%9E%E0%B8%A2%E0%B9%8C%E0%B9%81%E0%B8%A5%E0%B8%B0%E0%B8%AB%E0%B8%99%E0%B8%B5%E0%B9%89%E0%B8%AA%E0%B8%B4%E0%B8%99/47-assets_debts_2565/747-assets_debts_042565.html\" target=\"_self\">รายการย่อแสดงสินทรัพย์และหนี้สิน เมษายน 2565</a>&nbsp;</p>\n\r\n							  </body>\r\n								</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/UgDtn7.jpeg','2022-05-05 16:23:27','2022-05-05 16:23:27',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,'spsadmin'),(21,'ผลการดำเนินงาน ประจำเดือนเมษายน 2565','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p><a href=\"http://www.sunpasitcoop.com/coop/%E0%B8%9C%E0%B8%A5%E0%B8%81%E0%B8%B2%E0%B8%A3%E0%B8%94%E0%B8%B3%E0%B9%80%E0%B8%99%E0%B8%B4%E0%B8%99%E0%B8%87%E0%B8%B2%E0%B8%99/45-overall_result_2565/746-overall_result_04_2565.html\" target=\"_self\">ผลการดำเนินงาน ประจำเดือนเมษายน 2565</a>&nbsp;</p>\n\r\n							  </body>\r\n								</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/DxLRjB.jpeg','2022-05-05 16:24:13','2022-05-05 16:24:13',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,'spsadmin'),(22,'รายชื่อสมาชิกสมทบ หน่วยพนักงานกระทรวงสาธารณสุข(พกส.) ที่ได้รับการปรับเป็นสมาชิกสามัญประจำเดือน พฤษภาคม 2565','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>รายชื่อสมาชิกสมทบ หน่วยพนักงานกระทรวงสาธารณสุข(พกส.) ที่ได้รับการปรับเป็นสมาชิกสามัญประจำเดือน พฤษภาคม 2565</p>\n\r\n							  </body>\r\n								</html>',NULL,'2022-05-17 10:20:31','2022-05-17 10:20:31',NULL,'1',NULL,NULL,NULL,NULL,NULL,'https://proxy.thaicoop.co/SPSCOOP/resource/news/news_22.pdf?CyIk8J','spsadmin'),(23,'โครงการทัศนศึกษาสมาชิก จังหวัดศรีสะเกษ (ไป-กลับวันเดียว)','','<!DOCTYPE HTML>\r\n									<html>\r\n									<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n								  <meta charset=\"UTF-8\">\r\n								  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n								  <p><a href=\"http://www.sunpasitcoop.com/coop/8-news/749-n14_2565.html \" target=\"_self\">โครงการทัศนศึกษาสมาชิก จังหวัดศรีสะเกษ (ไป-กลับวันเดียว)</a>&nbsp;</p>\n\r\n								  </body>\r\n									</html>',NULL,'2022-05-17 14:43:20','2022-05-17 14:44:04','','1',NULL,NULL,NULL,NULL,NULL,'https://proxy.thaicoop.co/SPSCOOP/resource/news/news_23.pdf?B1Vvmt','spsadmin'),(24,'รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน พฤษภาคม','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน พฤษภาคม</p>\n\r\n							  </body>\r\n								</html>',NULL,'2022-05-25 09:39:44','2022-05-25 09:39:44',NULL,'1',NULL,NULL,NULL,NULL,NULL,'https://proxy.thaicoop.co/SPSCOOP/resource/news/news_24.pdf?OOPjMw','spsadmin'),(25,'วันที่ 3 มิถุนายน 2565 สหกรณ์หยุดทำการ 1 วัน เนื่องในวันเฉลิมพระชนมพรรษา พระบรมราชินี','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>วันที่ 3 มิถุนายน 2565 สหกรณ์หยุดทำการ 1 วัน เนื่องในวันเฉลิมพระชนมพรรษา พระบรมราชินี</p>\n\r\n							  </body>\r\n								</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/8ZSMfu.jpeg','2022-06-02 08:16:12','2022-06-02 08:16:12',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,'spsadmin'),(26,'ผลการดำเนินงาน และรายการย่อแสดงสินทรัพย์และหนี้สิน พฤษภาคม 2565','','<!DOCTYPE HTML>\r\n									<html>\r\n									<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n								  <meta charset=\"UTF-8\">\r\n								  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n								  <p><a href=\"http://www.sunpasitcoop.com/coop/%E0%B8%9C%E0%B8%A5%E0%B8%81%E0%B8%B2%E0%B8%A3%E0%B8%94%E0%B8%B3%E0%B9%80%E0%B8%99%E0%B8%B4%E0%B8%99%E0%B8%87%E0%B8%B2%E0%B8%99/45-overall_result_2565/753-overall_result_05_2565.html\" target=\"_self\">ผลการดำเนินงาน ประจำเดือนพฤษภาคม 2565</a><br><a href=\"http://www.sunpasitcoop.com/coop/%E0%B8%A3%E0%B8%B2%E0%B8%A2%E0%B8%81%E0%B8%B2%E0%B8%A3%E0%B8%A2%E0%B9%88%E0%B8%AD%E0%B9%81%E0%B8%AA%E0%B8%94%E0%B8%87%E0%B8%AA%E0%B8%B4%E0%B8%99%E0%B8%97%E0%B8%A3%E0%B8%B1%E0%B8%9E%E0%B8%A2%E0%B9%8C%E0%B9%81%E0%B8%A5%E0%B8%B0%E0%B8%AB%E0%B8%99%E0%B8%B5%E0%B9%89%E0%B8%AA%E0%B8%B4%E0%B8%99/47-assets_debts_2565/754-assets_debts_052565.html\" target=\"_self\">รายการย่อแสดงสินทรัพย์และหนี้สิน พฤษภาคม 2565</a></p>\n\r\n								  </body>\r\n									</html>',NULL,'2022-06-06 10:07:37','2022-06-17 10:17:49','','1',NULL,NULL,NULL,NULL,NULL,NULL,'spsadmin'),(27,'รายชื่อสมาชิกสมทบ หน่วยพนักงานกระทรวงสาธารณสุข(พกส.) ที่ได้รับการปรับเป็นสมาชิกสามัญประจำเดือน มิถุนายน 2565','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>รายชื่อสมาชิกสมทบ หน่วยพนักงานกระทรวงสาธารณสุข(พกส.) ที่ได้รับการปรับเป็นสมาชิกสามัญประจำเดือน มิถุนายน 2565</p>\n\r\n							  </body>\r\n								</html>',NULL,'2022-06-17 10:15:55','2022-06-17 10:15:55',NULL,'1',NULL,NULL,NULL,NULL,NULL,'https://proxy.thaicoop.co/SPSCOOP/resource/news/news_27.pdf?791R5J','spsadmin'),(28,'การให้ทุนการศึกษาบุตรสมาชิกประจำปี 2565','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>การให้ทุนการศึกษาบุตรสมาชิกประจำปี 2565</p>\n\r\n							  </body>\r\n								</html>',NULL,'2022-06-22 08:55:07','2022-06-22 08:55:07',NULL,'1',NULL,NULL,NULL,NULL,NULL,'https://proxy.thaicoop.co/SPSCOOP/resource/news/news_28.pdf?AVhgwj','spsadmin'),(29,'รายชื่อสมาชิกสหกรณ์ที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน มิถุนายน','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>รายชื่อสมาชิกที่ได้รับสวัสดิการค่ายังชีพแก่สมาชิกอาวุโส(อายุ 61 ปีขึ้นไป และอายุการเป็นสมาชิกไม่ต่ำกว่า 10 ปี) ที่เกิดในเดือน มิถุนายน<br>สหกรณ์ได้ทำการโอนเงินสวัสดิการเข้าบัญชีเงินฝากสมาชิกแล้ว สามารถตรวจสอบยอดโอนได้ที่แอพพลิเคชั่นสหกรณ์</p>\n\r\n							  </body>\r\n								</html>',NULL,'2022-06-27 10:15:51','2022-06-27 10:15:51',NULL,'1',NULL,NULL,NULL,NULL,NULL,'https://proxy.thaicoop.co/SPSCOOP/resource/news/news_29.pdf?vpPuIH','spsadmin'),(30,'ทัศนศึกษาสมาชิก โครงการที่ 3 ประเทศลาว (วังเวียง, หลวงพระบาง)','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>ทัศนศึกษาสมาชิก โครงการที่ 3 ประเทศลาว (วังเวียง, หลวงพระบาง)</p>\n\r\n							  </body>\r\n								</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/D90jKG.jpeg','2022-07-05 10:44:14','2022-07-05 10:44:15',NULL,'1',NULL,NULL,NULL,NULL,NULL,'https://proxy.thaicoop.co/SPSCOOP/resource/news/news_30.pdf?bE4jck','spsadmin'),(31,'ลดอัตราดอกเบี้ยเงินฝากออมทรัพย์พิเศษเพื่อการศึกษาบุตร เป็นอัตรา 3.50 ต่อปี','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>ลดอัตราดอกเบี้ยเงินฝากออมทรัพย์พิเศษเพื่อการศึกษาบุตร เป็นอัตรา 3.50 ต่อปี</p>\n\r\n							  </body>\r\n								</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/fhQyPr.jpeg','2022-07-05 13:57:27','2022-07-05 13:57:27',NULL,'1',NULL,NULL,NULL,NULL,NULL,'https://proxy.thaicoop.co/SPSCOOP/resource/news/news_31.pdf?2OHknd','spsadmin'),(32,'ผลการดำเนินงานและรายการย่อแสดงสินทรัพย์และหนี้สิน มิถุนายน 2565','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>ผลการดำเนินงานและรายการย่อแสดงสินทรัพย์และหนี้สิน มิถุนายน 2565</p>\n\r\n							  </body>\r\n								</html>',NULL,'2022-07-06 09:44:19','2022-07-06 09:44:20',NULL,'1',NULL,NULL,NULL,NULL,NULL,'https://proxy.thaicoop.co/SPSCOOP/resource/news/news_32.pdf?XjoaRC','spsadmin'),(33,'แจ้งวันหยุดประจำเดือนกรกฎาคม 2565','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>แจ้งวันหยุดประจำเดือนกรกฎาคม 2565</p>\n\r\n							  </body>\r\n								</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/tfgO64.jpeg','2022-07-11 10:14:02','2022-07-11 10:14:02',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,'spsadmin'),(34,'วารสารสหกรณ์ประจำเดือน เมษายน - มิถุนายน 2565','','<!DOCTYPE HTML>\r\n								<html>\r\n								<head>\r\n									<style>\r\n									img {\r\n										max-width: 100%;\r\n									}\r\n									</style>\r\n							  <meta charset=\"UTF-8\">\r\n							  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n							  <p>วารสารสหกรณ์ประจำเดือน เมษายน - มิถุนายน 2565</p>\n\r\n							  </body>\r\n								</html>','https://proxy.thaicoop.co/SPSCOOP/resource/gallery/lApeC5.jpeg','2022-07-12 10:27:22','2022-07-12 10:27:22',NULL,'1',NULL,NULL,NULL,NULL,NULL,'https://proxy.thaicoop.co/SPSCOOP/resource/news/news_34.pdf?TcHGHt','spsadmin');
/*!40000 ALTER TABLE `gcnews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcotp`
--

DROP TABLE IF EXISTS `gcotp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcotp` (
  `id_otp` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `refno_otp` char(6) NOT NULL,
  `otp_password` char(6) NOT NULL,
  `destination_number` char(10) NOT NULL,
  `expire_date` datetime NOT NULL,
  `otp_text` varchar(200) NOT NULL,
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `operate_date` datetime NOT NULL DEFAULT current_timestamp(),
  `otp_status` enum('0','1','-1','-9') NOT NULL DEFAULT '0',
  `id_userlogin` mediumint(8) unsigned DEFAULT NULL,
  PRIMARY KEY (`id_otp`),
  KEY `FK_REQUEST_BY` (`id_userlogin`),
  KEY `refno_otp` (`refno_otp`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcotp`
--

LOCK TABLES `gcotp` WRITE;
/*!40000 ALTER TABLE `gcotp` DISABLE KEYS */;
INSERT INTO `gcotp` VALUES (1,'CMyinw','387039','0634561953','2022-03-08 17:10:41',' OTP : 387039 (Ref. : CMyinw) หมดอายุเมื่อ : 08 มี.ค. 2565 17:10:41 น.','2022-03-08 17:06:29','2022-03-08 17:05:41','1',NULL),(2,'ETU104','816995','0897176694','2022-05-17 12:21:40',' OTP : 816995 (Ref. : ETU104) หมดอายุเมื่อ : 17 พ.ค. 2565 12:21:40 น.','2022-05-17 12:16:51','2022-05-17 12:16:40','1',NULL),(3,'Msep9D','305925','0815933618','2022-05-17 12:36:20',' OTP : 305925 (Ref. : Msep9D) หมดอายุเมื่อ : 17 พ.ค. 2565 12:36:20 น.','2022-05-17 12:31:37','2022-05-17 12:31:20','1',NULL),(4,'99qidV','617165','0898460260','2022-05-17 12:36:39',' OTP : 617165 (Ref. : 99qidV) หมดอายุเมื่อ : 17 พ.ค. 2565 12:36:39 น.','2022-05-17 12:32:13','2022-05-17 12:31:39','1',NULL),(5,'sZmhif','341021','0898650747','2022-05-17 12:36:45',' OTP : 341021 (Ref. : sZmhif) หมดอายุเมื่อ : 17 พ.ค. 2565 12:36:45 น.','2022-05-17 12:32:35','2022-05-17 12:31:45','1',NULL),(6,'Wr7Kve','710107','0895824224','2022-05-17 12:38:36',' OTP : 710107 (Ref. : Wr7Kve) หมดอายุเมื่อ : 17 พ.ค. 2565 12:38:36 น.','2022-05-17 12:33:55','2022-05-17 12:33:36','1',NULL),(7,'a1P5ZK','692930','0840363699','2022-05-17 12:46:13',' OTP : 692930 (Ref. : a1P5ZK) หมดอายุเมื่อ : 17 พ.ค. 2565 12:46:13 น.','2022-05-17 12:42:12','2022-05-17 12:41:13','1',NULL),(8,'jyf9xM','356348','0899469141','2022-05-17 13:06:50',' OTP : 356348 (Ref. : jyf9xM) หมดอายุเมื่อ : 17 พ.ค. 2565 13:06:50 น.','2022-05-17 13:02:47','2022-05-17 13:01:50','1',NULL),(9,'r1G0zx','100972','0610284878','2022-05-17 13:19:18',' OTP : 100972 (Ref. : r1G0zx) หมดอายุเมื่อ : 17 พ.ค. 2565 13:19:18 น.','2022-05-17 13:14:55','2022-05-17 13:14:18','1',NULL),(10,'LGlcPT','313035','0880248888','2022-05-17 13:21:56',' OTP : 313035 (Ref. : LGlcPT) หมดอายุเมื่อ : 17 พ.ค. 2565 13:21:56 น.','2022-05-17 13:17:24','2022-05-17 13:16:56','1',NULL),(11,'KtEUpb','445954','0898485927','2022-05-17 13:35:47',' OTP : 445954 (Ref. : KtEUpb) หมดอายุเมื่อ : 17 พ.ค. 2565 13:35:47 น.','2022-05-17 13:31:06','2022-05-17 13:30:47','1',NULL),(12,'X9YPDw','068198','0992645259','2022-05-23 12:50:56',' OTP : 068198 (Ref. : X9YPDw) หมดอายุเมื่อ : 23 พ.ค. 2565 12:50:56 น.','2022-05-23 12:46:07','2022-05-23 12:45:56','1',NULL),(13,'ixuaDz','724560','0821528248','2022-05-24 15:03:49',' OTP : 724560 (Ref. : ixuaDz) หมดอายุเมื่อ : 24 พ.ค. 2565 15:03:49 น.','2022-05-24 14:58:53','2022-05-24 14:58:49','1',NULL),(14,'jF66CI','196563','0810729174','2022-05-24 15:04:07',' OTP : 196563 (Ref. : jF66CI) หมดอายุเมื่อ : 24 พ.ค. 2565 15:04:07 น.','2022-05-24 14:59:29','2022-05-24 14:59:07','1',NULL);
/*!40000 ALTER TABLE `gcotp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcpalettecolor`
--

DROP TABLE IF EXISTS `gcpalettecolor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcpalettecolor` (
  `id_palette` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `type_palette` enum('1','2') NOT NULL DEFAULT '1',
  `color_main` varchar(9) NOT NULL,
  `color_secon` varchar(9) DEFAULT NULL,
  `color_deg` varchar(3) DEFAULT NULL,
  `color_text` varchar(9) NOT NULL DEFAULT '#FFFFFF',
  `is_use` enum('0','1','-9') NOT NULL DEFAULT '1',
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `type_palette_prev` enum('1','2') NOT NULL DEFAULT '1',
  `color_main_prev` varchar(9) DEFAULT NULL,
  `color_secon_prev` varchar(9) DEFAULT NULL,
  `color_deg_prev` varchar(3) DEFAULT NULL,
  `color_text_prev` varchar(9) DEFAULT NULL,
  PRIMARY KEY (`id_palette`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcpalettecolor`
--

LOCK TABLES `gcpalettecolor` WRITE;
/*!40000 ALTER TABLE `gcpalettecolor` DISABLE KEYS */;
INSERT INTO `gcpalettecolor` VALUES (1,'2','#16a7e3','#f3f3f3','45','#FFFFFF','1','2021-05-27 14:55:45','2021-05-27 14:55:45','1',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `gcpalettecolor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcqrcodegendetail`
--

DROP TABLE IF EXISTS `gcqrcodegendetail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcqrcodegendetail` (
  `qrcodegendt_id` int(12) NOT NULL AUTO_INCREMENT,
  `qrgenerate` varchar(20) NOT NULL,
  `trans_code_qr` char(2) NOT NULL,
  `ref_account` varchar(20) NOT NULL,
  `qrtransferdt_amt` varchar(50) NOT NULL DEFAULT '0',
  `qrtransferdt_fee` varchar(50) NOT NULL DEFAULT '0',
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `trans_status` enum('0','1','9') NOT NULL DEFAULT '0',
  PRIMARY KEY (`qrcodegendt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcqrcodegendetail`
--

LOCK TABLES `gcqrcodegendetail` WRITE;
/*!40000 ALTER TABLE `gcqrcodegendetail` DISABLE KEYS */;
INSERT INTO `gcqrcodegendetail` VALUES (1,'202204071423532311','01','0000000023','5000','0','2022-04-07 14:23:53','0'),(2,'202204071424028430','01','0000000023','1238','0','2022-04-07 14:24:02','0'),(3,'202205061607197634','01','0000015551','125','0','2022-05-06 16:07:19','0'),(4,'202205091407396007','01','0000015551','300','0','2022-05-09 14:07:39','0'),(5,'202205171245226253','01','0000005977','300','0','2022-05-17 12:45:22','0'),(6,'202205171246217021','01','0000000041','100','0','2022-05-17 12:46:21','0'),(7,'202205171429115616','01','0000000031','200','0','2022-05-17 14:29:11','0'),(8,'202205171600396532','01','0000016937','100','0','2022-05-17 16:00:39','0'),(9,'202205191051199853','01','0000015551','89','0','2022-05-19 10:51:19','0'),(10,'202205191307596538','01','0000016937','88','0','2022-05-19 13:07:59','0'),(11,'202205231259068751','01','0000005977','500','0','2022-05-23 12:59:06','0'),(12,'202205241503238310','01','0000015333','100','0','2022-05-24 15:03:23','0'),(13,'202205251413349448','01','0000016937','50','0','2022-05-25 14:13:34','0'),(14,'202205251414218437','01','0000015551','52','0','2022-05-25 14:14:21','0'),(15,'202206081351393893','01','0000015340','199','0','2022-06-08 13:51:39','0'),(16,'202206081356426162','01','0000015551','135','0','2022-06-08 13:56:42','0'),(17,'202206220932253905','01','0000015551','111','0','2022-06-22 09:32:25','0'),(18,'202206231340192536','01','0000015340','109','0','2022-06-23 13:40:19','0'),(19,'202206231341228855','01','0000015340','109','0','2022-06-23 13:41:22','0'),(20,'202206271346426225','01','0000015551','135','0','2022-06-27 13:46:42','0'),(21,'202206291354039841','01','0000015340','99','0','2022-06-29 13:54:03','0'),(22,'202206291355112742','01','0000015340','99','0','2022-06-29 13:55:11','0'),(23,'202206301318471827','01','0000015551','183','0','2022-06-30 13:18:47','0'),(24,'202207041256341117','01','0000015551','88','0','2022-07-04 12:56:34','0'),(25,'202207041418094386','01','0000016937','23','0','2022-07-04 14:18:09','0'),(26,'202207061003484719','01','1400000106','123','0','2022-07-06 10:03:48','0'),(27,'202207061137507665','01','0100008365','111','0','2022-07-06 11:37:50','0'),(28,'202207061138326773','01','0100008365','112','0','2022-07-06 11:38:32','0');
/*!40000 ALTER TABLE `gcqrcodegendetail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcqrcodegenmaster`
--

DROP TABLE IF EXISTS `gcqrcodegenmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcqrcodegenmaster` (
  `qrcodegen_id` int(12) NOT NULL AUTO_INCREMENT,
  `qrgenerate` varchar(20) NOT NULL,
  `member_no` char(8) NOT NULL,
  `generate_date` datetime NOT NULL DEFAULT current_timestamp(),
  `qrtransfer_amt` varchar(50) NOT NULL DEFAULT '0',
  `qrtransfer_fee` varchar(50) NOT NULL DEFAULT '0',
  `expire_date` datetime NOT NULL,
  `qr_path` text DEFAULT NULL,
  `transfer_status` enum('0','1','-9','3','9') NOT NULL DEFAULT '0',
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `id_userlogin` mediumint(8) unsigned DEFAULT NULL,
  `app_version` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`qrcodegen_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcqrcodegenmaster`
--

LOCK TABLES `gcqrcodegenmaster` WRITE;
/*!40000 ALTER TABLE `gcqrcodegenmaster` DISABLE KEYS */;
INSERT INTO `gcqrcodegenmaster` VALUES (1,'202204071423532312','00002728','2022-04-07 14:23:53','5000','0','2022-04-08 14:38:53','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/dev@mode202204071423532311.png','0','2022-04-07 14:24:35',56,'1.0.0'),(2,'202204071424028430','00002728','2022-04-07 14:24:02','1237','0','2022-04-08 14:39:02','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/dev@mode202204071424028430.png','0','2022-04-07 14:25:21',56,'1.0.0'),(3,'202205061607197634','00004491','2022-05-06 16:07:19','125','0','2022-05-06 16:22:19','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00004491202205061607197634.png','0','2022-05-06 16:07:20',53,'1.0.0'),(4,'202205091407396007','00004491','2022-05-09 14:07:39','300','0','2022-05-09 14:22:39','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00004491202205091407396007.png','1','2022-05-09 14:09:11',53,'1.0.0'),(5,'202205171245226253','00003171','2022-05-17 12:45:22','300','0','2022-05-17 13:00:22','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00003171202205171245226253.png','0','2022-05-17 12:45:22',60,'1.0.0'),(6,'202205171246217021','00002232','2022-05-17 12:46:21','100','0','2022-05-17 13:01:21','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00002232202205171246217021.png','0','2022-05-17 12:46:21',61,'1.0.0'),(7,'202205171429115616','00002799','2022-05-17 14:29:11','200','0','2022-05-17 14:44:11','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00002799202205171429115616.png','0','2022-05-17 14:29:11',64,'1.0.0'),(8,'202205171600396532','00005367','2022-05-17 16:00:39','100','0','2022-05-17 16:15:39','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00005367202205171600396532.png','0','2022-05-17 16:00:39',59,'1.0.0'),(9,'202205191051199853','00004491','2022-05-19 10:51:19','89','0','2022-05-19 11:06:19','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00004491202205191051199853.png','1','2022-05-19 10:52:03',53,'1.0.0'),(10,'202205191307596538','00005367','2022-05-19 13:07:59','88','0','2022-05-19 13:22:59','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00005367202205191307596538.png','1','2022-05-19 13:08:42',59,'1.0.0'),(11,'202205231259068751','00003171','2022-05-23 12:59:06','500','0','2022-05-23 13:14:06','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00003171202205231259068751.png','1','2022-05-23 13:00:58',60,'1.0.0'),(12,'202205241503238310','00004356','2022-05-24 15:03:23','100','0','2022-05-24 15:18:23','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00004356202205241503238310.png','0','2022-05-24 15:03:23',71,'1.0.0'),(13,'202205251413349448','00005367','2022-05-25 14:13:34','50','0','2022-05-25 14:28:34','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00005367202205251413349448.png','0','2022-05-25 14:13:35',59,'1.0.0'),(14,'202205251414218437','00004491','2022-05-25 14:14:21','52','0','2022-05-25 14:29:21','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00004491202205251414218437.png','0','2022-05-25 14:14:21',53,'1.0.0'),(15,'202206081351393893','00004378','2022-06-08 13:51:39','199','0','2022-06-08 14:06:39','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00004378202206081351393893.png','1','2022-06-08 13:52:48',6,'1.1.0'),(16,'202206081356426162','00004491','2022-06-08 13:56:42','135','0','2022-06-08 14:11:42','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00004491202206081356426162.png','1','2022-06-08 13:57:17',73,'1.1.0'),(17,'202206220932253905','00004491','2022-06-22 09:32:25','111','0','2022-06-22 09:47:25','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00004491202206220932253905.png','1','2022-06-22 09:33:04',83,'1.1.0'),(18,'202206231340192536','00004378','2022-06-23 13:40:19','109','0','2022-06-23 13:55:19','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00004378202206231340192536.png','0','2022-06-23 13:40:19',6,'1.1.0'),(19,'202206231341228855','00004378','2022-06-23 13:41:22','109','0','2022-06-23 13:56:22','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00004378202206231341228855.png','1','2022-06-23 13:42:07',6,'1.1.0'),(20,'202206271346426225','00004491','2022-06-27 13:46:42','135','0','2022-06-27 14:01:42','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00004491202206271346426225.png','1','2022-06-27 13:47:38',83,'1.1.0'),(21,'202206291354039841','00004378','2022-06-29 13:54:03','99','0','2022-06-29 14:09:03','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00004378202206291354039841.png','0','2022-06-29 13:54:03',6,'1.1.0'),(22,'202206291355112742','00004378','2022-06-29 13:55:11','99','0','2022-06-29 14:10:11','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00004378202206291355112742.png','1','2022-06-29 13:55:56',6,'1.1.0'),(23,'202206301318471827','00004491','2022-06-30 13:18:47','183','0','2022-06-30 13:33:47','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00004491202206301318471827.png','1','2022-06-30 13:19:42',83,'1.1.0'),(24,'202207041256341117','00004491','2022-07-04 12:56:34','88','0','2022-07-04 13:11:34','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00004491202207041256341117.png','1','2022-07-04 12:57:24',83,'1.1.0'),(25,'202207041418094386','00005367','2022-07-04 14:18:09','23','0','2022-07-04 14:33:09','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00005367202207041418094386.png','1','2022-07-04 14:18:47',59,'1.1.0'),(26,'202207061003484719','00004491','2022-07-06 10:03:48','123','0','2022-07-06 10:18:48','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00004491202207061003484719.png','1','2022-07-06 10:04:58',83,'1.1.0'),(27,'202207061137507665','00004491','2022-07-06 11:37:50','111','0','2022-07-06 11:52:50','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00004491202207061137507665.png','0','2022-07-06 11:37:50',83,'1.1.0'),(28,'202207061138326773','00004491','2022-07-06 11:38:32','112','0','2022-07-06 11:53:32','https://proxy.thaicoop.co/SPSCOOP//resource/qrcode/00004491202207061138326773.png','1','2022-07-06 11:39:09',83,'1.1.0');
/*!40000 ALTER TABLE `gcqrcodegenmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcrepayloan`
--

DROP TABLE IF EXISTS `gcrepayloan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcrepayloan` (
  `ref_no` varchar(25) NOT NULL,
  `from_account` varchar(20) NOT NULL,
  `loancontract_no` varchar(20) NOT NULL,
  `source_type` enum('1','2') NOT NULL DEFAULT '1',
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `fee_amt` decimal(15,2) NOT NULL DEFAULT 0.00,
  `penalty_amt` decimal(15,2) NOT NULL DEFAULT 0.00,
  `principal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `interest` decimal(15,2) NOT NULL DEFAULT 0.00,
  `interest_return` decimal(15,2) NOT NULL DEFAULT 0.00,
  `interest_arrear` decimal(15,2) NOT NULL DEFAULT 0.00,
  `bfinterest_return` decimal(15,2) NOT NULL DEFAULT 0.00,
  `bfinterest_arrear` decimal(15,2) NOT NULL DEFAULT 0.00,
  `bank_code` char(3) DEFAULT NULL,
  `operate_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `result_transaction` enum('1','-8','-9') NOT NULL DEFAULT '1',
  `cancel_date` datetime DEFAULT NULL,
  `member_no` varchar(8) NOT NULL,
  `id_userlogin` mediumint(8) unsigned NOT NULL,
  `app_version` varchar(10) DEFAULT NULL,
  `is_offset` enum('1','2') NOT NULL DEFAULT '1',
  `bfkeeping` decimal(15,2) NOT NULL DEFAULT 0.00,
  `calint_to` date DEFAULT NULL,
  PRIMARY KEY (`ref_no`),
  KEY `id_userlogin` (`id_userlogin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcrepayloan`
--

LOCK TABLES `gcrepayloan` WRITE;
/*!40000 ALTER TABLE `gcrepayloan` DISABLE KEYS */;
INSERT INTO `gcrepayloan` VALUES ('1624941344GqI','1000000336','ฉฉ64000105','1',10.00,0.00,0.00,10.00,0.00,0.00,0.00,0.00,0.00,NULL,'2021-06-29 11:35:44','2021-06-29 11:35:44','1',NULL,'etnmode3',80,'1.4.0','1',2500.00,'2021-06-09'),('1624958179RS4','1000000336','ฉฉ64000105','1',1000.00,0.00,0.00,1000.00,0.00,0.16,0.00,0.00,0.00,NULL,'2021-06-29 16:16:20','2021-06-29 16:16:20','1',NULL,'etnmode3',80,'1.4.0','1',2500.00,'2021-06-09'),('1625029197mPZ','1000000336','ฉฉ64000105','1',500.00,0.00,0.00,500.00,0.00,0.00,0.00,0.16,0.00,NULL,'2021-06-30 11:59:57','2021-06-30 11:59:57','1',NULL,'etnmode3',80,'1.4.0','1',2500.00,'2021-06-09'),('16250296502a1','1000000336','ฉฉ64000105','1',500.00,0.00,0.00,500.00,0.00,0.00,0.00,0.00,0.00,NULL,'2021-06-30 12:07:30','2021-06-30 12:07:30','1',NULL,'etnmode3',80,'1.4.0','1',2500.00,'2021-06-09'),('1625029768VQH','0000674001','ฉฉ64000105','1',10000.00,0.00,0.00,10000.00,0.00,0.00,0.00,0.00,0.00,NULL,'2021-06-30 12:09:28','2021-06-30 12:09:28','1',NULL,'etnmode3',80,'1.4.0','1',2500.00,'2021-06-09'),('1625104985Ddp','1000000240','สม64000040','1',2000.00,0.00,0.00,2000.00,0.00,0.34,0.00,0.00,0.00,NULL,'2021-07-01 09:03:07','2021-07-01 09:03:07','1',NULL,'etnmode3',81,'1.4.1','1',3374.93,'2021-05-31'),('1625105009Gew','0000674001','สม64000040','1',80000.00,0.00,0.00,80000.00,0.00,13.69,0.00,0.34,0.00,NULL,'2021-07-01 09:03:30','2021-07-01 09:03:30','1',NULL,'etnmode3',81,'1.4.1','1',3374.93,'2021-05-31'),('1625106762s0V','1000000240','สม64000040','1',1000.00,0.00,0.00,694.08,305.92,0.00,0.00,0.00,0.00,NULL,'2021-07-01 09:32:42','2021-07-01 09:32:42','1',NULL,'etnmode3',82,'1.4.1','1',0.00,'2021-07-01'),('1625107259AvI','0000674001','สม64000040','1',10000.00,0.00,0.00,10000.00,0.00,0.00,0.00,0.00,0.00,NULL,'2021-07-01 09:40:59','2021-07-01 09:40:59','1',NULL,'etnmode3',82,'1.4.1','1',0.00,'2021-07-01'),('20210630193920336','1000000336','ฉป64000001','1',1000.00,0.00,0.00,0.00,1000.00,0.00,1000.00,0.00,0.00,NULL,'2021-06-30 19:39:20','2021-06-30 19:39:20','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630200035336','1000000336','ฉป64000001','1',1000.00,0.00,0.00,0.00,1000.00,0.00,2000.00,0.00,1000.00,NULL,'2021-06-30 20:00:35','2021-06-30 20:00:35','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630200203336','1000000336','ฉป64000001','1',1000.00,0.00,0.00,0.00,1000.00,0.00,2000.00,0.00,1000.00,NULL,'2021-06-30 20:02:03','2021-06-30 20:02:03','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630200254336','1000000336','ฉป64000001','1',1000.00,0.00,0.00,0.00,1000.00,0.00,2000.00,0.00,1000.00,NULL,'2021-06-30 20:02:54','2021-06-30 20:02:54','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630200823336','1000000336','ฉป64000001','1',1000.00,0.00,0.00,1000.00,5091.72,0.00,7091.72,0.00,2000.00,NULL,'2021-06-30 20:08:23','2021-06-30 20:08:23','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630201251240','1000000240','ฉป64000001','1',1999.00,0.00,0.00,1999.00,0.00,0.00,20363.80,0.00,7091.72,NULL,'2021-06-30 20:12:51','2021-06-30 20:12:51','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630212009001','0000674001','ฉป64000001','1',100.00,0.00,0.00,100.00,0.00,0.00,41036.77,0.00,20363.80,NULL,'2021-06-30 21:20:10','2021-06-30 21:20:10','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630212107001','0000674001','ฉป64000001','1',100.00,0.00,0.00,100.00,0.00,0.00,41036.77,0.00,20363.80,NULL,'2021-06-30 21:21:07','2021-06-30 21:21:07','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630212226001','0000674001','ฉป64000001','1',100.00,0.00,0.00,100.00,0.00,0.00,41036.77,0.00,20363.80,NULL,'2021-06-30 21:22:26','2021-06-30 21:22:26','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630212647001','0000674001','ฉป64000001','1',500.00,0.00,0.00,500.00,0.00,0.00,42273.46,0.00,20363.80,NULL,'2021-06-30 21:26:47','2021-06-30 21:26:47','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630213048001','0000674001','ฉป64000001','1',500.00,0.00,0.00,500.00,0.00,0.00,42273.46,0.00,20363.80,NULL,'2021-06-30 21:30:48','2021-06-30 21:30:48','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630213420001','0000674001','ฉป64000001','1',500.00,0.00,0.00,500.00,0.00,0.00,42273.46,0.00,20363.80,NULL,'2021-06-30 21:34:20','2021-06-30 21:34:20','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630214054240','1000000240','ฉป64000001','1',500.00,0.00,0.00,500.00,0.00,0.00,42273.46,0.00,20363.80,NULL,'2021-06-30 21:40:54','2021-06-30 21:40:54','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630214127001','0000674001','ฉป64000001','1',100.00,0.00,0.00,100.00,0.00,0.00,84856.09,0.00,42273.46,NULL,'2021-06-30 21:41:27','2021-06-30 21:41:27','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630214818001','0000674001','ฉป64000001','1',100.00,0.00,0.00,100.00,0.00,0.00,84856.09,0.00,42273.46,NULL,'2021-06-30 21:48:18','2021-06-30 21:48:18','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630215101001','0000674001','ฉป64000001','1',100.00,0.00,0.00,100.00,0.00,0.00,84856.09,0.00,42273.46,NULL,'2021-06-30 21:51:01','2021-06-30 21:51:01','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630215133001','0000674001','ฉป64000001','1',100.00,0.00,0.00,100.00,0.00,0.00,84856.09,0.00,42273.46,NULL,'2021-06-30 21:51:33','2021-06-30 21:51:33','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630215208001','0000674001','ฉป64000001','1',100.00,0.00,0.00,100.00,0.00,0.00,84856.09,0.00,42273.46,NULL,'2021-06-30 21:52:09','2021-06-30 21:52:09','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630215639001','0000674001','ฉป64000001','1',1000.00,0.00,0.00,1000.00,0.00,0.00,87638.64,0.00,42273.46,NULL,'2021-06-30 21:56:39','2021-06-30 21:56:39','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630220224001','0000674001','ฉป64000001','1',1000.00,0.00,0.00,1000.00,0.00,0.00,87638.64,0.00,42273.46,NULL,'2021-06-30 22:02:24','2021-06-30 22:02:24','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630220753001','0000674001','ฉป64000001','1',100.00,0.00,0.00,100.00,0.00,0.00,84856.09,0.00,42273.46,NULL,'2021-06-30 22:07:53','2021-06-30 22:07:53','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210630220839001','0000674001','ฉป64000001','1',500.00,0.00,0.00,500.00,0.00,0.00,171258.04,0.00,84856.09,NULL,'2021-06-30 22:08:39','2021-06-30 22:08:39','1',NULL,'etnmode3',80,'1.4.0','1',0.00,'2021-06-30'),('20210701090438240','1000000240','ฉป64000001','1',4000.00,0.00,0.00,4000.00,0.00,0.00,354883.64,0.00,171258.04,NULL,'2021-07-01 09:04:38','2021-07-01 09:04:38','1',NULL,'etnmode3',81,'1.4.1','1',0.00,'2021-07-01'),('20210701090512001','0000674001','ฉป64000001','1',600.00,0.00,0.00,600.00,0.00,0.00,711622.41,0.00,354883.64,NULL,'2021-07-01 09:05:12','2021-07-01 09:05:12','1',NULL,'etnmode3',81,'1.4.1','1',0.00,'2021-07-01'),('20210701100725001','0000674001','ฉป64000001','1',10000.00,0.00,0.00,10000.00,0.00,0.00,1.64,0.00,0.00,NULL,'2021-07-01 10:07:25','2021-07-01 10:07:25','1',NULL,'etnmode3',82,'1.4.1','2',0.00,'2021-07-01'),('20210701101123001','0000674001','ฉป64000001','1',10000.00,0.00,0.00,10000.00,0.00,0.00,3.28,0.00,1.64,NULL,'2021-07-01 10:11:32','2021-07-01 10:11:32','1',NULL,'etnmode3',82,'1.4.1','1',0.00,'2021-07-01'),('20210701101315001','0000674001','ฉป64000001','1',10000.00,0.00,0.00,10000.00,0.00,0.00,6.56,0.00,3.28,NULL,'2021-07-01 10:13:16','2021-07-01 10:13:16','1',NULL,'etnmode3',82,'1.4.1','1',0.00,'2021-07-01'),('20210701101334001','0000674001','ฉป64000001','1',10000.00,0.00,0.00,10000.00,0.00,0.00,13.12,0.00,6.56,NULL,'2021-07-01 10:13:34','2021-07-01 10:13:34','1',NULL,'etnmode3',82,'1.4.1','1',0.00,'2021-07-01');
/*!40000 ALTER TABLE `gcrepayloan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcreqloan`
--

DROP TABLE IF EXISTS `gcreqloan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcreqloan` (
  `reqloan_doc` char(15) NOT NULL,
  `member_no` char(8) NOT NULL,
  `loantype_code` varchar(5) NOT NULL,
  `request_amt` decimal(15,2) NOT NULL,
  `period_payment` int(12) NOT NULL,
  `period` int(12) NOT NULL,
  `req_status` enum('8','1','-9','7','9','2','3','4','6') NOT NULL DEFAULT '8',
  `loanpermit_amt` decimal(15,2) NOT NULL,
  `diff_old_contract` int(12) NOT NULL DEFAULT 0,
  `receive_net` int(12) NOT NULL,
  `int_rate_at_req` decimal(10,5) NOT NULL,
  `salary_at_req` int(10) DEFAULT NULL,
  `request_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `approve_date` datetime DEFAULT NULL,
  `salary_img` text DEFAULT NULL,
  `citizen_img` text DEFAULT NULL,
  `bookbank_img` text DEFAULT NULL,
  `remark` text DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `id_userlogin` mediumint(8) unsigned NOT NULL,
  `contractdoc_url` text DEFAULT NULL,
  `deptaccount_no_bank` varchar(15) DEFAULT NULL,
  `bank_desc` varchar(200) DEFAULT NULL,
  `deptaccount_no_coop` varchar(15) DEFAULT NULL,
  `objective` text DEFAULT NULL,
  `pay_date` date DEFAULT NULL,
  `channel` enum('web','mobile_app') NOT NULL DEFAULT 'mobile_app',
  PRIMARY KEY (`reqloan_doc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcreqloan`
--

LOCK TABLES `gcreqloan` WRITE;
/*!40000 ALTER TABLE `gcreqloan` DISABLE KEYS */;
INSERT INTO `gcreqloan` VALUES ('000001','etnmode1','10',22400.00,1244,10,'-9',22400.00,0,22400,0.06000,NULL,'2021-02-25 15:12:55','2021-05-11 11:02:32',NULL,NULL,NULL,NULL,NULL,'dev@mode',23,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000001.pdf?v=1614240775','',NULL,NULL,NULL,NULL,'mobile_app'),('000002','etnmode1','10',22400.00,1244,10,'9',22400.00,0,22400,0.06000,NULL,'2021-02-25 15:53:53','2021-02-25 15:56:39',NULL,NULL,NULL,NULL,NULL,NULL,23,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000002.pdf?v=1614243233',NULL,NULL,NULL,NULL,NULL,'mobile_app'),('000003','etnmode1','10',22400.00,1244,10,'9',22400.00,0,22400,0.06000,NULL,'2021-02-25 15:56:49','2021-03-31 09:51:57',NULL,NULL,NULL,NULL,NULL,'dev@mode',23,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000003.pdf?v=1614243409','',NULL,NULL,NULL,NULL,'mobile_app'),('000004','dev@mode','10',22400.00,1244,9,'9',22400.00,0,22400,0.06000,NULL,'2021-03-03 16:48:47','2021-03-08 10:04:29',NULL,NULL,NULL,NULL,NULL,NULL,25,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000004.pdf?v=1614764927','',NULL,NULL,NULL,NULL,'mobile_app'),('000005','dev@mode','10',10000.00,1111,9,'-9',22400.00,0,10000,0.06000,NULL,'2021-03-08 10:08:40','2021-03-08 10:15:57',NULL,NULL,NULL,NULL,NULL,'dev@mode',26,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000005.pdf?v=1615172920','',NULL,NULL,NULL,NULL,'mobile_app'),('000006','etnmode2','10',22400.00,1244,8,'9',22400.00,0,22400,0.06000,NULL,'2021-04-01 10:11:40','2021-04-01 12:20:56',NULL,NULL,NULL,NULL,NULL,NULL,28,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000006.pdf?v=1617246700','',NULL,NULL,NULL,NULL,'mobile_app'),('000007','etnmode3','10',76608.94,4250,18,'9',76608.94,0,76609,0.06000,NULL,'2021-05-10 10:50:47','2021-05-10 10:51:37',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000007/salary.jpeg',NULL,NULL,NULL,NULL,33,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000007.pdf?v=1620618647','',NULL,NULL,NULL,NULL,'mobile_app'),('000008','etnmode3','10',76608.94,4250,18,'9',76608.94,0,76609,0.06000,NULL,'2021-05-10 10:51:50','2021-05-10 11:06:53',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000008/salary.jpeg',NULL,NULL,NULL,NULL,33,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000008.pdf?v=1620618710','',NULL,NULL,NULL,NULL,'mobile_app'),('000009','etnmode3','10',76608.94,4250,18,'9',76608.94,0,76609,0.06000,NULL,'2021-05-10 11:07:09','2021-05-10 11:25:06',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000009/salary.jpeg',NULL,NULL,NULL,NULL,33,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000009.pdf?v=1620619629','',NULL,NULL,NULL,NULL,'mobile_app'),('000010','etnmode3','10',76608.94,4250,18,'9',76608.94,0,76609,0.06000,NULL,'2021-05-10 11:25:30','2021-05-10 13:07:24',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000010/salary.jpeg',NULL,NULL,NULL,NULL,33,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000010.pdf?v=1620620730','',NULL,NULL,NULL,NULL,'mobile_app'),('000011','etnmode3','10',76608.94,4260,18,'9',76608.94,46390,76609,0.06000,38304,'2021-05-11 13:06:50','2021-05-11 13:09:15',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000011/salary.jpeg',NULL,NULL,NULL,NULL,33,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000011.pdf?v=1620713210','',NULL,NULL,NULL,NULL,'mobile_app'),('000012','etnmode3','10',76608.94,4260,18,'9',76608.94,46390,76609,0.06000,38304,'2021-05-11 13:09:58','2021-05-11 13:12:31',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000012/salary.jpeg',NULL,NULL,NULL,NULL,33,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000012.pdf?v=1620713398','',NULL,NULL,NULL,NULL,'mobile_app'),('000013','etnmode3','10',76608.94,4260,18,'9',76608.94,46390,76609,0.06000,38304,'2021-05-11 13:12:46','2021-05-11 16:59:32',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000013/salary.jpeg',NULL,NULL,NULL,NULL,33,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000013.pdf?v=1620713566','',NULL,NULL,NULL,NULL,'mobile_app'),('000014','etnmode3','10',76608.94,4260,18,'9',76608.94,46390,76609,0.06000,38304,'2021-05-11 17:03:12','2021-05-11 17:03:56',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000014/salary.jpeg',NULL,NULL,NULL,NULL,33,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000014.pdf?v=1620727392','',NULL,NULL,NULL,NULL,'mobile_app'),('000015','etnmode3','10',76608.94,4260,18,'9',76608.94,46390,76609,0.06000,38304,'2021-05-11 17:04:10','2021-05-11 17:04:31',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000015/salary.jpeg',NULL,NULL,NULL,NULL,33,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000015.pdf?v=1620727450','',NULL,NULL,NULL,NULL,'mobile_app'),('000016','etnmode3','10',76608.94,4260,18,'9',76608.94,46390,76609,0.06000,38304,'2021-05-11 17:04:43','2021-05-11 17:05:03',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000016/salary.jpeg',NULL,NULL,NULL,NULL,33,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000016.pdf?v=1620727483','',NULL,NULL,NULL,NULL,'mobile_app'),('000017','etnmode3','10',76608.94,4260,18,'9',76608.94,46390,76609,0.06000,38304,'2021-05-11 17:05:18','2021-05-11 17:05:40',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000017/salary.jpeg',NULL,NULL,NULL,NULL,33,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000017.pdf?v=1620727518','',NULL,NULL,NULL,NULL,'mobile_app'),('000018','etnmode3','10',76608.94,4260,18,'9',76608.94,46390,76609,0.06000,38304,'2021-05-11 17:05:53','2021-05-11 17:06:46',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000018/salary.jpeg',NULL,NULL,NULL,NULL,33,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000018.pdf?v=1620727553','',NULL,NULL,NULL,NULL,'mobile_app'),('000019','etnmode3','10',76608.94,4260,18,'9',76608.94,46390,76609,0.06000,38304,'2021-05-11 17:06:59','2021-05-11 17:08:09',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000019/salary.jpeg',NULL,NULL,NULL,NULL,33,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000019.pdf?v=1620727619','',NULL,NULL,NULL,NULL,'mobile_app'),('000020','etnmode3','10',76608.94,4260,18,'9',76608.94,46390,76609,0.06000,38304,'2021-05-11 17:09:14','2021-05-11 17:09:50',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000020/salary.jpeg',NULL,NULL,NULL,NULL,33,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000020.pdf?v=1620727754','',NULL,NULL,NULL,NULL,'mobile_app'),('000021','etnmode3','10',76608.94,4260,18,'9',76608.94,46390,76609,0.06000,38304,'2021-05-11 17:10:11','2021-05-11 17:10:34',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000021/salary.jpeg',NULL,NULL,NULL,NULL,33,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000021.pdf?v=1620727811','',NULL,NULL,NULL,NULL,'mobile_app'),('000022','etnmode3','10',76608.94,4260,18,'-9',76608.94,46390,76609,0.06000,38304,'2021-05-11 17:10:51','2021-05-11 17:11:37',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000022/salary.jpeg',NULL,NULL,NULL,'dev@mode',33,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000022.pdf?v=1620727851','',NULL,NULL,NULL,NULL,'mobile_app'),('000023','etnmode3','10',76608.94,4260,18,'9',76608.94,46390,76609,0.06000,38304,'2021-05-11 17:11:55','2021-05-12 09:26:35',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000023/salary.jpeg',NULL,NULL,NULL,NULL,33,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000023.pdf?v=1620727915','',NULL,NULL,NULL,NULL,'mobile_app'),('000024','etnmode3','10',76608.94,4260,18,'9',76608.94,46390,76609,0.06000,38304,'2021-05-12 11:06:12','2021-05-12 11:06:32',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000024/salary.jpeg',NULL,NULL,NULL,NULL,39,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000024.pdf?v=1620792372','',NULL,NULL,NULL,NULL,'mobile_app'),('000025','etnmode3','10',76608.94,4260,18,'9',76608.94,46390,76609,0.06000,38304,'2021-05-12 16:54:25','2021-05-12 17:30:56',NULL,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST/resource/reqloan_doc/000025/salary.jpeg',NULL,NULL,NULL,NULL,40,'https://mobilecore.gensoft.co.th/MJUCOOP-TEST//resource/pdf/request_loan/000025.pdf?v=1620813265','',NULL,NULL,NULL,NULL,'mobile_app');
/*!40000 ALTER TABLE `gcreqloan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gctaskevent`
--

DROP TABLE IF EXISTS `gctaskevent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gctaskevent` (
  `id_task` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `task_topic` varchar(200) NOT NULL,
  `task_detail` varchar(200) NOT NULL,
  `event_html` longtext DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `event_start_time` time DEFAULT NULL,
  `event_end_time` time DEFAULT NULL,
  `is_settime` enum('0','1') NOT NULL DEFAULT '0',
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_notify` enum('0','1') NOT NULL DEFAULT '1',
  `is_notify_before` enum('0','1') NOT NULL DEFAULT '1',
  `create_by` varchar(20) NOT NULL,
  `is_use` enum('0','1','-9') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_task`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gctaskevent`
--

LOCK TABLES `gctaskevent` WRITE;
/*!40000 ALTER TABLE `gctaskevent` DISABLE KEYS */;
/*!40000 ALTER TABLE `gctaskevent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gctoken`
--

DROP TABLE IF EXISTS `gctoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gctoken` (
  `id_token` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `refresh_token` varchar(100) NOT NULL,
  `access_token` text DEFAULT NULL,
  `rt_expire_date` datetime DEFAULT NULL,
  `at_expire_date` datetime DEFAULT NULL,
  `rt_is_revoke` enum('0','-6','-7','-8','-9','-88','-99') NOT NULL DEFAULT '0',
  `at_is_revoke` enum('0','-6','-7','-8','-9','-88','-99') NOT NULL DEFAULT '0',
  `rt_request_date` datetime NOT NULL DEFAULT current_timestamp(),
  `at_request_date` datetime NOT NULL DEFAULT current_timestamp(),
  `at_update_date` datetime DEFAULT NULL,
  `unique_id` varchar(50) NOT NULL,
  `channel` enum('mobile_app','web','unknown') NOT NULL DEFAULT 'unknown',
  `device_name` text DEFAULT NULL,
  `ip_address` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id_token`),
  KEY `FETCH_REFRESH_TOKEN` (`refresh_token`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gctoken`
--

LOCK TABLES `gctoken` WRITE;
/*!40000 ALTER TABLE `gctoken` DISABLE KEYS */;
INSERT INTO `gctoken` VALUES (1,'8469bb1d-0307-4d65-8d39-a706a1c02371','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIxIiwidXNlcl90eXBlIjoiMCIsImlkX3Rva2VuIjoiMSIsIm1lbWJlcl9ubyI6ImV0bm1vZGUzIiwiZXhwIjoxNjM5NTQ1NzA0LCJyZWZyZXNoX2Ftb3VudCI6MH0.GuVZmw964mbgEG6fEUxjDg4z_njPft3M3-xX73FZfnM','2021-12-15 12:06:59','2021-12-15 12:06:59','-9','-9','2021-12-15 12:06:44','2021-12-15 12:06:44',NULL,'SeVjcV5M18KKGS2g','web','Chrome (96.0.4664.93)','183.88.129.91'),(2,'d5262a01-203a-4745-8e4f-10c91f833117','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIyIiwidXNlcl90eXBlIjoiMCIsImlkX3Rva2VuIjoiMiIsIm1lbWJlcl9ubyI6IjAwMDA0NDkxIiwiZXhwIjoxNjQyMTI5MTI0LCJyZWZyZXNoX2Ftb3VudCI6Mjh9.lf_gP1UTWAHH0qq8wfni2pv3_-XlshtiJSUen64gfvQ','2022-01-14 09:43:45','2022-01-14 09:43:45','-88','-88','2021-12-15 12:18:14','2021-12-15 12:18:14','2022-01-14 09:43:44','616eb0257faf43fb','mobile_app','samsung SM-N986B','49.230.116.103'),(3,'a9af5d61-fa69-4b58-a53c-5082fb9dc361','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIzIiwidXNlcl90eXBlIjoiMCIsImlkX3Rva2VuIjoiMyIsIm1lbWJlcl9ubyI6IjAwMDA0NDkxIiwiZXhwIjoxNjM5NTQ2NTk1LCJyZWZyZXNoX2Ftb3VudCI6MH0.2cj8pSF14ivpllTZ5HROhQpFCP_c_2wcExZozVW1h58','2021-12-15 12:23:29','2021-12-15 12:23:29','-9','-9','2021-12-15 12:21:35','2021-12-15 12:21:35',NULL,'eluUolhZVq9KlcBg','web','Chrome (96.0.4664.104)','49.230.116.103'),(4,'b025660f-27e4-4dbe-aab8-3f480eed883d','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI0IiwidXNlcl90eXBlIjoiMCIsImlkX3Rva2VuIjoiNCIsIm1lbWJlcl9ubyI6IjAwMDA0NDkxIiwiZXhwIjoxNjM5NTQ5MzMzLCJyZWZyZXNoX2Ftb3VudCI6MH0.bIIgGmXwcfDqubd55nREGk3_NXP1RoMKKW2kiMtX1Go','2021-12-15 13:08:37','2021-12-15 13:08:37','-9','-9','2021-12-15 13:07:13','2021-12-15 13:07:13',NULL,'U9fDYpxDaCrDJUAS','web','Firefox (95.0)','183.89.81.131'),(5,'e0f25a28-1ec2-443c-96bc-fe5c034d968c','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI1IiwidXNlcl90eXBlIjoiMCIsImlkX3Rva2VuIjoiNSIsIm1lbWJlcl9ubyI6IjAwMDA1MDYwIiwiZXhwIjoxNjQ1NzgyMTMzLCJyZWZyZXNoX2Ftb3VudCI6Mn0.4qDNFvSwZLRfFuIVlWVS3_RaJ3YWlbG3-xGwkuRKfys',NULL,NULL,'0','0','2021-12-15 13:12:08','2021-12-15 13:12:08','2022-02-25 16:27:13','B07E1931-A940-4ECC-81DC-22FEF59210EF','mobile_app','Apple iPhone 12 Pro','182.232.74.61'),(6,'f0f3ddc3-979b-4f6d-beb4-3411eafb5ae7','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI2IiwidXNlcl90eXBlIjoiMCIsImlkX3Rva2VuIjoiNiIsIm1lbWJlcl9ubyI6IjAwMDA0Mzc4IiwiZXhwIjoxNjU3OTc3NzY5LCJyZWZyZXNoX2Ftb3VudCI6NzJ9.ZmSpmy0Z8SC4eRKnvodx_WbujCehO-lFtuZnXtRTuI0',NULL,NULL,'0','0','2021-12-15 13:13:03','2021-12-15 13:13:03','2022-07-16 20:07:49','998F2077-6BBB-419A-AD4E-23982930BFA5','mobile_app','Apple iPhone SE','1.47.14.243'),(7,'3b119c08-a6cf-4fb8-94f1-ad9ca63b2db2','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI3IiwidXNlcl90eXBlIjoiMCIsImlkX3Rva2VuIjoiNyIsIm1lbWJlcl9ubyI6IjAwMDA1MDYwIiwiZXhwIjoxNjM5NTUwMDExLCJyZWZyZXNoX2Ftb3VudCI6MH0.9W2A-dotN0hMkndZvqySPA9Cq6fG0UvZGMQ4Zqz8Jlg',NULL,NULL,'0','0','2021-12-15 13:18:31','2021-12-15 13:18:31',NULL,'BVedBnZvDRWlroCP','web','Chrome (96.0.4664.110)','183.89.81.131'),(8,'d854814d-16eb-4803-a661-349420e318f6','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI4IiwidXNlcl90eXBlIjoiMCIsImlkX3Rva2VuIjoiOCIsIm1lbWJlcl9ubyI6IjAwMDA0Mzc4IiwiZXhwIjoxNjM5NTUwMDU1LCJyZWZyZXNoX2Ftb3VudCI6MH0.4uZnW0Lpc2x-aVPhAuDdOCR0TUTGkCc5Nal5RC3Relg',NULL,NULL,'0','0','2021-12-15 13:19:15','2021-12-15 13:19:15',NULL,'NGCymkmt3thpeA2E','web','Firefox (95.0)','183.89.81.131'),(9,'2c8c887c-05a6-40b9-a128-caa1e00c21f5','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI5IiwidXNlcl90eXBlIjoiMCIsImlkX3Rva2VuIjoiOSIsIm1lbWJlcl9ubyI6IjAwMDA0NDkxIiwiZXhwIjoxNjM5NzI5NjI5LCJyZWZyZXNoX2Ftb3VudCI6MH0.VmgH6TFfIzbLlQJUeJU3AqBHm1kwO09IdM09ZKzcQJQ','2021-12-17 15:15:31','2021-12-17 15:15:31','-9','-9','2021-12-17 15:12:09','2021-12-17 15:12:09',NULL,'U9fDYpxDaCrDJUAS','web','Firefox (95.0)','180.183.193.132'),(10,'6332b29a-c413-4631-9b33-acf8408f7bd0','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIxMCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjEwIiwibWVtYmVyX25vIjoiZXRubW9kZTEiLCJleHAiOjE2NDIwNDIzNTgsInJlZnJlc2hfYW1vdW50IjowfQ.MBAvxWyhRkcQgUfxvjiN3k_RGFOwA859wjR09h7E6uE',NULL,NULL,'0','0','2022-01-13 09:37:38','2022-01-13 09:37:38',NULL,'a6tvzv2M98oM8YmB','web','Chrome (97.0.4692.71)','180.183.203.101'),(11,'cce7764a-34bd-4fb5-a30b-95552bae193a','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIxMSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjExIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDI3NDkyMjEsInJlZnJlc2hfYW1vdW50IjoxMn0.q0Hsui9P-FUjLWja8-wh2vsaBjVKYOXOJ48adE6dijI','2022-01-24 14:45:32','2022-01-24 14:45:32','-6','-6','2022-01-14 09:46:38','2022-01-14 09:46:38','2022-01-21 13:58:41','616eb0257faf43fb','mobile_app','samsung SM-N986B','182.232.75.91'),(12,'1f4501d9-2512-41a6-9001-feae28c03309','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIxMiIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjEyIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDIxMjkzODYsInJlZnJlc2hfYW1vdW50IjowfQ.3-2rBxnWcf2p8IcRE9qtawUHtZRRjiZmUbk3r3zzNXg','2022-01-14 09:51:47','2022-01-14 09:51:47','-9','-9','2022-01-14 09:48:06','2022-01-14 09:48:06',NULL,'4FXvuiZVMq7ir2nS','web','Firefox (96.0)','14.207.181.169'),(13,'eebcbcd7-0356-4d8a-8e3f-d8c6a54b084f','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIxMyIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjEzIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDIzODgzMTcsInJlZnJlc2hfYW1vdW50IjoxfQ.aPr-FrcInCqWnouDMgpLtsJMJU7cBuvS8IaMNI7RLMo','2022-01-17 09:43:37','2022-01-17 09:43:37','-9','-9','2022-01-17 09:34:54','2022-01-17 09:34:54','2022-01-17 09:43:37','4FXvuiZVMq7ir2nS','web','Firefox (96.0)','14.207.181.169'),(14,'bf888bc0-9052-4acb-9873-0e59cae0c8f9','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIxNCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjE0IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDI2NDQ2MjQsInJlZnJlc2hfYW1vdW50IjoxfQ.y_2e5bp8_MrruyK3xTQZDJq4zA0R-oX-8me7wQfHr_E','2022-01-20 09:55:38','2022-01-20 09:55:38','-6','-6','2022-01-20 08:45:54','2022-01-20 08:45:54','2022-01-20 08:55:24','4FXvuiZVMq7ir2nS','web','Firefox (96.0)','183.89.84.66'),(15,'9cc44028-c738-4c7e-ac98-ad81e7d8531e','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIxNSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjE1IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDI2NDgyMzgsInJlZnJlc2hfYW1vdW50IjowfQ.6QZaOX31fB_cYPGfEU5heCjkENhw3KA6tRzTGNvqPNQ','2022-01-20 13:06:52','2022-01-20 13:06:52','-6','-6','2022-01-20 09:55:38','2022-01-20 09:55:38',NULL,'4FXvuiZVMq7ir2nS','web','Firefox (96.0)','183.89.84.66'),(16,'d46bcf8f-cf62-46af-8a26-c53df072c7fa','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIxNiIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjE2IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDI2NTk3MTIsInJlZnJlc2hfYW1vdW50IjowfQ.ZU9K-fklqCwbn-pGX6tZDAFCPXXV5i8XnCbeQz-FoCM','2022-01-20 13:07:32','2022-01-20 13:07:32','-9','-9','2022-01-20 13:06:52','2022-01-20 13:06:52',NULL,'4FXvuiZVMq7ir2nS','web','Firefox (96.0)','183.89.84.66'),(17,'284f97bc-527a-4cf2-9dbe-bece30f2a5da','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIxNyIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjE3IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDI2NjE5MDEsInJlZnJlc2hfYW1vdW50IjowfQ.uLgH5Kko7ejjQbup7qf0OgtIc34AT6AB_dlHRWIUHSY','2022-01-20 13:43:39','2022-01-20 13:43:39','-9','-9','2022-01-20 13:43:21','2022-01-20 13:43:21',NULL,'4FXvuiZVMq7ir2nS','web','Firefox (96.0)','183.89.84.66'),(18,'b3dd3651-3ea2-41b1-84da-be966039a1c5','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIxOCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjE4IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDI2NzMzMTUsInJlZnJlc2hfYW1vdW50IjoxfQ.eVnCMseXmG6BVkgcQQWdoGTWco3uOH1LTFZDci2ze1Q','2022-01-20 16:58:52','2022-01-20 16:58:52','-9','-9','2022-01-20 16:45:59','2022-01-20 16:45:59','2022-01-20 16:53:35','4FXvuiZVMq7ir2nS','web','Firefox (96.0)','183.89.84.66'),(19,'85d820ba-39f5-48a6-9291-e1f8b0271955','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIxOSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjE5IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDI3MzgwMDYsInJlZnJlc2hfYW1vdW50IjowfQ.cnVXLkGM2iq85XTKSBinnNXzJu-7pGRiVCJFkjENSfo','2022-01-21 10:52:15','2022-01-21 10:52:15','-9','-9','2022-01-21 10:51:46','2022-01-21 10:51:46',NULL,'4FXvuiZVMq7ir2nS','web','Firefox (96.0)','183.89.84.66'),(20,'c2881e6a-9c3f-4cab-b4f2-b4be6cee8fe3','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIyMCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjIwIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDMwMTE1MDAsInJlZnJlc2hfYW1vdW50IjoxfQ.7QDYS67-6Z6GY52G5QQKYPCroeuH8FIEdxvOIeNg5DE','2022-01-24 14:50:55','2022-01-24 14:50:55','-9','-9','2022-01-24 14:41:00','2022-01-24 14:41:00','2022-01-24 14:50:00','4FXvuiZVMq7ir2nS','web','Firefox (96.0)','14.207.178.148'),(21,'59c08b7b-9186-481d-b6e7-258c8666d8e7','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIyMSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjIxIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDY3MzQwODIsInJlZnJlc2hfYW1vdW50IjoxMDh9.6GjN4YbkgiytDkLWscI-IIvJGgoLbFOaADikuddbTTE','2022-03-08 16:53:03','2022-03-08 16:53:03','-88','-88','2022-01-24 14:45:32','2022-01-24 14:45:32','2022-03-08 16:53:02','8acf69b296d4ab7a','mobile_app','samsung SM-N986B','14.207.178.148'),(22,'d4ef5a32-81a6-4e76-8f1a-451f8a34e8b9','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIyMiIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjIyIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDMwMTk5MzksInJlZnJlc2hfYW1vdW50IjowfQ.z-B3_PkAn7oQ0rZR_fEmf-LuCPiOfdG8DBRoKtu1Amg','2022-01-24 17:14:49','2022-01-24 17:14:49','-9','-9','2022-01-24 17:10:39','2022-01-24 17:10:39',NULL,'4FXvuiZVMq7ir2nS','web','Firefox (96.0)','14.207.178.148'),(23,'56f0aa37-f601-449f-8d8e-50252b5dfe04','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIyMyIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjIzIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDMwMjAyMDQsInJlZnJlc2hfYW1vdW50IjowfQ.yMplXAKfEzpPsicaaOsTWJDf7cOccqiJLxhQHLLnLUo','2022-01-24 17:15:23','2022-01-24 17:15:23','-9','-9','2022-01-24 17:15:04','2022-01-24 17:15:04',NULL,'4FXvuiZVMq7ir2nS','web','Firefox (96.0)','14.207.178.148'),(24,'b66bd51f-59a5-457c-877d-cbf9ee63ebaf','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIyNCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjI0IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDMwOTE5NDksInJlZnJlc2hfYW1vdW50IjoxfQ.0H3GlSI4PoJxk9QMWLpEVW8rtJQezQdCB6Dbjb1-6mY','2022-01-25 13:11:16','2022-01-25 13:11:16','-9','-9','2022-01-25 12:58:28','2022-01-25 12:58:28','2022-01-25 13:10:49','4FXvuiZVMq7ir2nS','web','Firefox (96.0)','14.207.178.148'),(25,'797abbde-c1a5-45d2-8ebe-cbcad36a39d3','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIyNSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjI1IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDMxNjIwODIsInJlZnJlc2hfYW1vdW50IjoxfQ.16Cw3HO8VlHculNSg7_y_j4aDjAdSSar4FiDLvU-NS4','2022-01-26 08:39:42','2022-01-26 08:39:42','-9','-9','2022-01-26 08:28:09','2022-01-26 08:28:09','2022-01-26 08:39:42','4FXvuiZVMq7ir2nS','web','Firefox (96.0)','14.207.178.148'),(26,'d249d1ac-2bed-449b-a096-926c0cb7cd42','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIyNiIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjI2IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDMyNzQ2NDcsInJlZnJlc2hfYW1vdW50IjoxfQ.--0A2efny2DkmuahnKHmnsLC_lCTNNetj7Ha8b_zNmw','2022-01-27 16:01:31','2022-01-27 16:01:31','-9','-9','2022-01-27 15:45:54','2022-01-27 15:45:54','2022-01-27 15:55:47','4FXvuiZVMq7ir2nS','web','Firefox (96.0)','14.207.178.148'),(27,'e243145f-8fa5-4bb5-a658-5f0d9a73bc56','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIyNyIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjI3IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDM2MTA3NDYsInJlZnJlc2hfYW1vdW50IjowfQ.G0kMnlTo2OJXn5AU3qkr48UoMyQKeOnlO2hcMpic3rs','2022-02-01 13:36:49','2022-02-01 13:36:49','-6','-6','2022-01-31 13:17:26','2022-01-31 13:17:26',NULL,'rWSMd8DgjmCmABCi','web','Edge (97.0.1072.76)','14.207.178.165'),(28,'b352c819-9f9a-48dc-81dd-cb9de0937793','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIyOCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjI4IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDM2OTgzMDksInJlZnJlc2hfYW1vdW50IjowfQ.5NWGCuw-MZCcF-_MF6z5Xl3HFwJI8Ukl0KOJaCd-CA0','2022-02-01 13:58:17','2022-02-01 13:58:17','-6','-6','2022-02-01 13:36:49','2022-02-01 13:36:49',NULL,'rWSMd8DgjmCmABCi','web','Edge (97.0.1072.76)','14.207.178.165'),(29,'09fba02a-bf31-4215-b7f8-c1114e48d5bb','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIyOSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjI5IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDM3MDAzMDksInJlZnJlc2hfYW1vdW50IjoxfQ.7vA0yXTkOOXlyjTRw-y19cRgCBv9TfuZj2sJ6qHGKaU','2022-02-01 14:10:09','2022-02-01 14:10:09','-9','-9','2022-02-01 13:58:17','2022-02-01 13:58:17','2022-02-01 14:10:09','rWSMd8DgjmCmABCi','web','Edge (97.0.1072.76)','14.207.178.165'),(30,'5d128492-0f8b-4561-94ae-fad1d37b22a2','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIzMCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjMwIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDM3Njk3MzYsInJlZnJlc2hfYW1vdW50IjowfQ.obuJni4EU3sMMJKt3xrjvgPuLXTO24JWer-YVoLPHPE','2022-02-02 09:27:36','2022-02-02 09:27:36','-9','-9','2022-02-02 09:27:16','2022-02-02 09:27:16',NULL,'rWSMd8DgjmCmABCi','web','Edge (97.0.1072.76)','14.207.178.165'),(31,'4c297332-49ff-4e98-955c-81d3744c5567','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIzMSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjMxIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDM4NzE1NDUsInJlZnJlc2hfYW1vdW50IjowfQ.pf_coG4Ja5FFfqj3yluHzsFgt0Ml8pKc55I4pqAXn4Q','2022-02-03 13:45:09','2022-02-03 13:45:09','-9','-9','2022-02-03 13:44:05','2022-02-03 13:44:05',NULL,'rWSMd8DgjmCmABCi','web','Edge (97.0.1072.76)','14.207.178.165'),(32,'99016eba-f99e-4f70-bedd-506c396aa70f','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIzMiIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjMyIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDM5Mzk1NDEsInJlZnJlc2hfYW1vdW50IjowfQ.UlyEevqOdiXi4QEpEGjeTuEiT3_utGGlU5-z7uEmiSw','2022-02-04 08:39:43','2022-02-04 08:39:43','-9','-9','2022-02-04 08:37:21','2022-02-04 08:37:21',NULL,'rWSMd8DgjmCmABCi','web','Edge (97.0.1072.76)','14.207.178.165'),(33,'b72b7d62-6142-4cdd-b474-d9daa2087f2b','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIzMyIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjMzIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDM5NzQ0NzgsInJlZnJlc2hfYW1vdW50IjowfQ.Itqj6Si6M7vUvrNikCOFSlQJpE7iXwmYRHTr_KR-Roc','2022-02-04 18:20:45','2022-02-04 18:20:45','-9','-9','2022-02-04 18:19:37','2022-02-04 18:19:37',NULL,'rWSMd8DgjmCmABCi','web','Edge (97.0.1072.76)','14.207.178.165'),(34,'1f3354bc-f78a-4305-ad2e-489ec477aae3','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIzNCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjM0IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDQyMDM4ODUsInJlZnJlc2hfYW1vdW50IjowfQ.2E114SGeZekYNZyf4WOJB5IiWGrgTx0emmNHKRu8SzU','2022-02-07 10:04:30','2022-02-07 10:04:30','-9','-9','2022-02-07 10:03:05','2022-02-07 10:03:05',NULL,'rWSMd8DgjmCmABCi','web','Edge (98.0.1108.43)','14.207.181.50'),(35,'424765be-1560-4387-80c2-feaaeedb4f0c','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIzNSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjM1IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDQyODY1NTcsInJlZnJlc2hfYW1vdW50IjowfQ.7R6vc17VL4BIKCdJwMwkRvl-DagFfhZqANjVNwCMzRU','2022-02-08 09:01:28','2022-02-08 09:01:28','-9','-9','2022-02-08 09:00:57','2022-02-08 09:00:57',NULL,'rWSMd8DgjmCmABCi','web','Edge (98.0.1108.43)','14.207.181.50'),(36,'764a52da-60f6-426e-bafc-f706a70717c0','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIzNiIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjM2IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDQ4MDU1NjUsInJlZnJlc2hfYW1vdW50IjowfQ.M_jhD3c3GW2pi6GlgITY1Nqh6N_n3g1unxAO1CsNgNI','2022-02-14 09:12:16','2022-02-14 09:12:16','-9','-9','2022-02-14 09:11:05','2022-02-14 09:11:05',NULL,'rWSMd8DgjmCmABCi','web','Edge (98.0.1108.43)','14.207.182.33'),(37,'1fa8fce2-5fa3-4e18-8017-5f02b7ed7646','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIzNyIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjM3IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDQ4OTUzNzcsInJlZnJlc2hfYW1vdW50IjowfQ.FnySq62rSht_9g7rqIbixdTxG5hXqkdKEey4WW2wr9M','2022-02-15 10:11:23','2022-02-15 10:11:23','-9','-9','2022-02-15 10:07:57','2022-02-15 10:07:57',NULL,'rWSMd8DgjmCmABCi','web','Edge (98.0.1108.50)','14.207.182.33'),(38,'5b924d44-ee81-41b1-943c-ebb5b254b6ee','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIzOCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjM4IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDU0OTQyMzAsInJlZnJlc2hfYW1vdW50IjowfQ.u1AdLi10eoBuhg3t-vtPPEMgsqIDStHNsEZKSw4nUWc','2022-02-22 08:30:46','2022-02-22 08:30:46','-9','-9','2022-02-22 08:28:50','2022-02-22 08:28:50',NULL,'rWSMd8DgjmCmABCi','web','Edge (98.0.1108.56)','183.89.80.245'),(39,'15b002a5-3395-4c93-9264-cad93b2e2b24','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiIzOSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjM5IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDU1MTY5OTksInJlZnJlc2hfYW1vdW50IjoxfQ.Jp28FQRDHJ5GHmr364vquHw5KecFMuqV6tIuqB4g0pU','2022-02-23 14:33:37','2022-02-23 14:33:37','-6','-6','2022-02-22 14:38:25','2022-02-22 14:38:25','2022-02-22 14:48:19','rWSMd8DgjmCmABCi','web','Edge (98.0.1108.56)','183.89.80.245'),(40,'b8ee5d03-1b8d-4c04-9b7b-af2e4a150360','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI0MCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjQwIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDU2MDI5ODEsInJlZnJlc2hfYW1vdW50IjoxfQ.g-hLjnE7c5vkb7T6n0cQueJqz-rU-vNVWzRRNvNwHtI','2022-02-23 14:44:20','2022-02-23 14:44:20','-9','-9','2022-02-23 14:33:37','2022-02-23 14:33:37','2022-02-23 14:41:21','rWSMd8DgjmCmABCi','web','Edge (98.0.1108.56)','183.89.80.245'),(41,'ef981cca-56d5-4cae-b9ec-6bd1c87a51cd','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI0MSIsInVzZXJfdHlwZSI6IjEiLCJpZF90b2tlbiI6IjQxIiwibWVtYmVyX25vIjoiZXRubW9kZTQiLCJleHAiOjE2NDU2OTMyNzcsInJlZnJlc2hfYW1vdW50Ijo2fQ.oGHFGCv9BEm43nNWsWBzaa4pItmprkmB50nJQbrJG58','2022-02-24 15:46:20','2022-02-24 15:46:20','-9','-9','2022-02-24 14:53:02','2022-02-24 14:53:02','2022-02-24 15:46:17','24b3bd50fec9cd8a','mobile_app','Redmi M2101K6G','183.89.187.91'),(42,'689d2926-a541-4c9c-b77b-3053ba183ed1','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI0MiIsInVzZXJfdHlwZSI6IjEiLCJpZF90b2tlbiI6IjQyIiwibWVtYmVyX25vIjoiZXRubW9kZTQiLCJleHAiOjE2NDYwMzM4MDgsInJlZnJlc2hfYW1vdW50IjozfQ.SugKPZOyJk1Rnn9Z_WFCPuFubanvslK-OxNVsF33vTU','2022-02-28 14:22:35','2022-02-28 14:22:35','-9','-9','2022-02-24 16:13:24','2022-02-24 16:13:24','2022-02-28 14:21:48','24b3bd50fec9cd8a','mobile_app','Redmi M2101K6G','183.89.187.91'),(43,'a50cccd3-c0e1-44f4-9f1a-edd36fff454c','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI0MyIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjQzIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDYwMjY4NTgsInJlZnJlc2hfYW1vdW50IjoxfQ.JH7leFFJM0QYSk4pBmRrQ29_sNYPu9l7U1mqym8lN5A','2022-02-28 16:44:56','2022-02-28 16:44:56','-6','-6','2022-02-28 12:17:53','2022-02-28 12:17:53','2022-02-28 12:25:58','rWSMd8DgjmCmABCi','web','Edge (98.0.1108.56)','183.89.80.245'),(44,'c39d2ffc-4c8d-48c5-a610-3bf4a21b9fb1','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI0NCIsInVzZXJfdHlwZSI6IjEiLCJpZF90b2tlbiI6IjQ0IiwibWVtYmVyX25vIjoiZXRubW9kZTQiLCJleHAiOjE2NDk2NjExNDMsInJlZnJlc2hfYW1vdW50IjoxMn0.v9tKwFamI0tfX4FXSvfn37Z50oyYHLG8VGqAbuZT8S8',NULL,NULL,'0','0','2022-02-28 15:14:54','2022-02-28 15:14:54','2022-04-11 13:57:23','159B66EE-4C88-4807-B867-7103124C52EC','mobile_app','Apple iPad','183.89.187.91'),(45,'b3597267-e5db-4027-93d7-8867a4f5ba37','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI0NSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjQ1IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDYwNDI4NDYsInJlZnJlc2hfYW1vdW50IjoxfQ.yMR0alKwPmpBAwTQCUNWcljGliJLGpfLaHIC-uS_G88','2022-02-28 16:59:18','2022-02-28 16:59:18','-9','-9','2022-02-28 16:44:56','2022-02-28 16:44:56','2022-02-28 16:52:26','rWSMd8DgjmCmABCi','web','Edge (98.0.1108.56)','183.89.80.245'),(46,'79a51417-698b-4649-942c-91c261053b51','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI0NiIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjQ2IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDYxMDI0NjIsInJlZnJlc2hfYW1vdW50IjowfQ.VmA5JFdpI9uouAQoVoEZx5jRIbkzV7fXk10luvUYnY0','2022-03-01 09:29:18','2022-03-01 09:29:18','-9','-9','2022-03-01 09:26:02','2022-03-01 09:26:02',NULL,'rWSMd8DgjmCmABCi','web','Edge (98.0.1108.62)','183.89.80.245'),(47,'9e8f3c00-307f-48a9-8d65-afd60390e440','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI0NyIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjQ3IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDYyMTA0NTgsInJlZnJlc2hfYW1vdW50IjoyfQ.XNf6vm1SxZGUtiD79OpksCj4bpqb2PA6uMmZzldhb6s','2022-03-02 15:28:57','2022-03-02 15:28:57','-9','-9','2022-03-02 15:09:35','2022-03-02 15:09:35','2022-03-02 15:25:58','rWSMd8DgjmCmABCi','web','Edge (98.0.1108.62)','183.89.80.245'),(48,'dbdf69b5-ad31-4f3a-9d4e-9af8fb6d1ff4','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI0OCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjQ4IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDYzNzA4MDYsInJlZnJlc2hfYW1vdW50IjowfQ.Zy0eakoKMakmO0nNdk44D9v-L4Jq6i0-dWAO_wAQEaY','2022-03-04 12:00:05','2022-03-04 12:00:05','-9','-9','2022-03-04 11:58:26','2022-03-04 11:58:26',NULL,'rWSMd8DgjmCmABCi','web','Edge (98.0.1108.62)','183.89.81.135'),(49,'cd8f5b9f-2eb3-4e55-9dd5-4a99ca7be949','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI0OSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjQ5IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDY3MzUxNDMsInJlZnJlc2hfYW1vdW50Ijo3fQ.-FZ9CF9Mx9EuzU6pYxrHvV93UJkVN94uOeYQyBO3Q78','2022-03-08 17:14:38','2022-03-08 17:14:38','-9','-9','2022-03-08 17:06:39','2022-03-08 17:06:39','2022-03-08 17:10:43','8acf69b296d4ab7a','mobile_app','samsung SM-N986B','182.232.77.172'),(50,'6f9b60e7-0442-46bf-95da-e3c27f036a3c','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI1MCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjUwIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDY3OTU1NjgsInJlZnJlc2hfYW1vdW50Ijo1fQ.A_BXr7-Fly7NkCSVhixOnkHJ8rm9ye6qZAuTU8P1uik','2022-03-09 16:34:05','2022-03-09 16:34:05','-9','-9','2022-03-08 17:17:25','2022-03-08 17:17:25','2022-03-09 09:57:48','8acf69b296d4ab7a','mobile_app','samsung SM-N986B','182.232.77.172'),(51,'87646187-76b9-491d-b4a6-6d90c9bb5c58','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI1MSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjUxIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDcyMzM4OTksInJlZnJlc2hfYW1vdW50Ijo4fQ.4QoUt7tp4p8_S0kgCAAur9FhQQ2c_vJceOatawhEwbU','2022-03-14 16:31:51','2022-03-14 16:31:51','-9','-9','2022-03-14 11:02:59','2022-03-14 11:02:59','2022-03-14 11:43:19','8acf69b296d4ab7a','mobile_app','samsung SM-N986B','49.230.180.137'),(52,'2eb7ac86-e470-4f56-9d42-c0aeefb8c54b','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI1MiIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjUyIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDczMTMxMDMsInJlZnJlc2hfYW1vdW50IjoxfQ.7JPCzQipw4kdqJz7eZpNmGOFh_-GPxg3BQNufZespeE','2022-03-15 10:56:12','2022-03-15 10:56:12','-9','-9','2022-03-15 09:43:19','2022-03-15 09:43:19','2022-03-15 09:43:23','8acf69b296d4ab7a','mobile_app','samsung SM-N986B','182.232.70.142'),(53,'bec3ee10-ff76-45b2-8f6c-834f33df7a5e','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI1MyIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjUzIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NTM4OTc2NTYsInJlZnJlc2hfYW1vdW50IjoxMjV9.0yDv7BKpwvekr8ztZuPvkGK2iiHGY4aa1d7P5qOUrvY','2022-05-30 14:45:58','2022-05-30 14:45:58','-9','-9','2022-03-18 14:22:07','2022-03-18 14:22:07','2022-05-30 14:45:56','8acf69b296d4ab7a','mobile_app','samsung SM-N986B','49.230.122.71'),(54,'7942dbbc-dd02-4f18-b365-7c86a10115ae','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI1NCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjU0IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NDkxNTY5NDksInJlZnJlc2hfYW1vdW50IjowfQ.i2W-Ounmnd-HvM5sKKguH6YCWjeDIriaXvSJ9GJpYHo','2022-04-05 17:56:13','2022-04-05 17:56:13','-9','-9','2022-04-05 17:54:09','2022-04-05 17:54:09',NULL,'iXxEEtDJbRq2fCsc','web','Chrome (100.0.4896.75)','183.89.85.243'),(55,'f2329198-6707-4c21-bea7-a56b089b39ce','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI1NSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjU1IiwibWVtYmVyX25vIjoiZXRubW9kZTEiLCJleHAiOjE2NDkyNTk0NTgsInJlZnJlc2hfYW1vdW50IjoxfQ.LjJr5isEvf5WM-ogIxW9UpIbGi4DFKzSbf9t1Z3Jz10','2022-06-06 10:41:47','2022-06-06 10:41:47','-6','-6','2022-04-06 22:22:28','2022-04-06 22:22:28','2022-04-06 22:22:38','79c8d8c64d2b2380','mobile_app','HUAWEI ELE-L09','37.228.245.116'),(56,'5bc3f08b-5679-4066-8ade-86103e9b3e82','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI1NiIsInVzZXJfdHlwZSI6IjkiLCJpZF90b2tlbiI6IjU2IiwibWVtYmVyX25vIjoiZGV2QG1vZGUiLCJleHAiOjE2NDkzMTY5OTQsInJlZnJlc2hfYW1vdW50IjowfQ.IVyrmQqRiMCNbY68gQdyMYj85WJnDiNmlq0MXJVkJ88','2022-05-06 15:10:48','2022-05-06 15:10:48','-9','-9','2022-04-07 14:21:34','2022-04-07 14:21:34',NULL,'11B46D64-C0F9-470E-8494-2FE94CAA164D','mobile_app','Apple iPhone 13 Pro','180.183.229.111'),(57,'93930eac-32f4-4ae0-a1f8-f7ea0e9cb634','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI1NyIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjU3IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NTEwNDY5MzYsInJlZnJlc2hfYW1vdW50IjowfQ.ryjeo8BvaAbhwGQa7G1zeGEtFmCYzEzgBL34f_V8Hro','2022-04-27 15:00:22','2022-04-27 15:00:22','-9','-9','2022-04-27 14:53:56','2022-04-27 14:53:56',NULL,'iXxEEtDJbRq2fCsc','web','Chrome (100.0.4896.127)','183.89.83.68'),(58,'f007f8a7-74e2-4a8f-9a6b-6305b7fc78c2','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI1OCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjU4IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NTIxNDgxOTMsInJlZnJlc2hfYW1vdW50IjoxfQ.XGNJnqropHMeix_iSk1mo4jU9IS--9cUGaHh0-Uhdxw','2022-05-27 10:34:51','2022-05-27 10:34:51','-6','-6','2022-05-10 08:36:12','2022-05-10 08:36:12','2022-05-10 08:48:13','iXxEEtDJbRq2fCsc','web','Chrome (101.0.4951.54)','14.207.179.21'),(59,'ccb6d72e-7937-4bcd-ba91-186e040979c1','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI1OSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjU5IiwibWVtYmVyX25vIjoiMDAwMDUzNjciLCJleHAiOjE2NTcxODM1MDcsInJlZnJlc2hfYW1vdW50Ijo0MH0.XnPe7pgsQK7qbE_jjp4Sw1Y1W1L63oPDn8pFW6VfTdA',NULL,NULL,'0','0','2022-05-17 12:16:54','2022-05-17 12:16:54','2022-07-07 15:30:07','e7022fa179fd036c','mobile_app','OPPO CPH1969','223.24.144.142'),(60,'1bd9537a-cb32-4567-b0c6-dbd1761c74ec','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI2MCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjYwIiwibWVtYmVyX25vIjoiMDAwMDMxNzEiLCJleHAiOjE2NTY5NDEzMDksInJlZnJlc2hfYW1vdW50IjoxNX0.w5tTTJXopWoP5FrN57C64__1CABhc40RF-33qX5ffH8',NULL,NULL,'0','0','2022-05-17 12:31:51','2022-05-17 12:31:51','2022-07-04 20:13:29','942af199e53f43e4','mobile_app','OPPO CPH1819','1.46.151.25'),(61,'70a5e152-999d-4774-a388-aae2465b0e48','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI2MSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjYxIiwibWVtYmVyX25vIjoiMDAwMDIyMzIiLCJleHAiOjE2NTYzMDYyOTgsInJlZnJlc2hfYW1vdW50Ijo0fQ.WcBAaTdrqSR1OhRBav2f8TpC55k0dKLgihCXi9QYyFo',NULL,NULL,'0','0','2022-05-17 12:32:19','2022-05-17 12:32:19','2022-06-27 11:49:58','80F01475-AD3F-4609-8F5B-02104CA9284B','mobile_app','Apple iPhone SE','49.230.121.104'),(62,'d7024815-9ea1-4c80-ab5a-c625cb6d40b9','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI2MiIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjYyIiwibWVtYmVyX25vIjoiMDAwMDI5NDkiLCJleHAiOjE2NTc4OTY0MDAsInJlZnJlc2hfYW1vdW50IjozfQ.lgqYXT5CH8fJE1WeJKzcEdLzweIn3YhIL3QxtYzgkMw',NULL,NULL,'0','0','2022-05-17 12:32:40','2022-05-17 12:32:40','2022-07-15 21:31:40','7DA75B13-3C78-44A3-91B4-DC64E7B5AEAA','mobile_app','Apple iPhone XR','49.230.177.222'),(63,'bc29c0ee-358f-4fc0-83b7-f9349983a9d2','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI2MyIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjYzIiwibWVtYmVyX25vIjoiMDAwMDMwODkiLCJleHAiOjE2NTY5MTg5MDEsInJlZnJlc2hfYW1vdW50Ijo3fQ._CVSvFhkgmFOdwB8Kcp9VTprr16mfUwSWvWLym80k9E',NULL,NULL,'0','0','2022-05-17 12:34:12','2022-05-17 12:34:12','2022-07-04 14:00:01','5697244389026fc2','mobile_app','samsung SM-A125F','49.230.122.9'),(64,'1d75b645-603a-4365-9bf5-b8e5262a5d74','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI2NCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjY0IiwibWVtYmVyX25vIjoiMDAwMDI3OTkiLCJleHAiOjE2NTU0NDU0ODIsInJlZnJlc2hfYW1vdW50IjoxMX0.4TU1q_FLtmmue1RfcwiHQKaVVekTf4Rg5vXn-08a_5w',NULL,NULL,'0','0','2022-05-17 12:42:27','2022-05-17 12:42:27','2022-06-17 12:43:02','29cf7b6c9a76e667','mobile_app','samsung SM-G925F','183.89.81.126'),(65,'ac86e974-9e17-4f2d-98ad-2db085f494b5','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI2NSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjY1IiwibWVtYmVyX25vIjoiMDAwMDA4NzMiLCJleHAiOjE2NTczMzg5MTUsInJlZnJlc2hfYW1vdW50IjoxNH0.2F_nPfF2lXZLYFXHKjYoS5EDsX0rzdEpFhMy9lcPG-s',NULL,NULL,'0','0','2022-05-17 13:02:51','2022-05-17 13:02:51','2022-07-09 10:40:15','41b912b63e229c10','mobile_app','samsung SM-A515F','182.232.178.250'),(66,'f8df82c3-8909-452c-9c85-05c94f313fdd','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI2NiIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjY2IiwibWVtYmVyX25vIjoiMDAwMDI1MzkiLCJleHAiOjE2NTY5NDA5MzksInJlZnJlc2hfYW1vdW50Ijo3fQ.9HRFpNj6viXn906Wpem56U0AQPwKdf6dIf018AnvWns',NULL,NULL,'0','0','2022-05-17 13:15:01','2022-05-17 13:15:01','2022-07-04 20:07:19','6cc0333ac337238f','mobile_app','OPPO CPH2237','182.232.80.107'),(67,'7eb45293-483c-4613-9ad1-e67a6d6a5d0b','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI2NyIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjY3IiwibWVtYmVyX25vIjoiMDAwMDQ0MDgiLCJleHAiOjE2NTc5MDM1OTYsInJlZnJlc2hfYW1vdW50IjoxN30.wJFIqZim0nnbHyf3zLBgXXiGfyI-3utuWO2Vg23x3GM',NULL,NULL,'0','0','2022-05-17 13:17:27','2022-05-17 13:17:27','2022-07-15 23:31:36','9a487fda14af05d6','mobile_app','samsung SM-N975F','182.232.83.173'),(68,'54a12219-a7ef-4cab-adbb-218dc6ddc83f','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI2OCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjY4IiwibWVtYmVyX25vIjoiMDAwMDMwNzYiLCJleHAiOjE2NTI3NzI3NzgsInJlZnJlc2hfYW1vdW50Ijo0fQ._7dcD_lwslnXLV59cL8ksGQy0cQ2q6kBf4m_2AldW6I','2022-06-04 06:14:12','2022-06-04 06:14:12','-9','-9','2022-05-17 13:31:15','2022-05-17 13:31:15','2022-05-17 14:17:58','203e15225b3c6932','mobile_app','OPPO CPH1911','182.232.2.104'),(69,'6d76b3f3-e9f6-4f7e-851b-bca448675e16','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI2OSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjY5IiwibWVtYmVyX25vIjoiMDAwMDM4MjMiLCJleHAiOjE2NTY2NjE1MDksInJlZnJlc2hfYW1vdW50IjoxMn0.otn8phT3XNRmMp9_LH1puXV1sD3O3omG_gC-NA4Ke04',NULL,NULL,'0','0','2022-05-23 12:46:12','2022-05-23 12:46:12','2022-07-01 14:30:09','1e6abd6578ebe644','mobile_app','HUAWEI CLT-L29','111.84.138.1'),(70,'cf0ce4b4-280f-4eb9-8149-3ec56371f771','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI3MCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjcwIiwibWVtYmVyX25vIjoiMDAwMDUzNTciLCJleHAiOjE2NTQ5NTQ5MjAsInJlZnJlc2hfYW1vdW50Ijo0fQ.IJojV5p5BBUcmzQi0QSNP2O_u2c12a9aMUf418s2oto',NULL,NULL,'0','0','2022-05-24 14:58:56','2022-05-24 14:58:56','2022-06-11 20:27:00','4A0FF276-4167-41A8-9735-4E7467EEAF9B','mobile_app','Apple iPhone 13 Pro Max','49.237.8.203'),(71,'2b123aac-bc10-4067-95d6-a3be228c0e7d','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI3MSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjcxIiwibWVtYmVyX25vIjoiMDAwMDQzNTYiLCJleHAiOjE2NTgwNjM5MzMsInJlZnJlc2hfYW1vdW50IjoxMH0.Wy6YovqIeYeLzzIpANK3254iTt8LJS_w9BHBGP23HvM',NULL,NULL,'0','0','2022-05-24 14:59:32','2022-05-24 14:59:32','2022-07-17 20:03:53','a4d097fe60a593b8','mobile_app','samsung SM-A800F','183.89.82.186'),(72,'bcbd0f19-2dd6-4fef-a55f-c608efad1cb2','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI3MiIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjcyIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NTM2MjMzOTEsInJlZnJlc2hfYW1vdW50IjowfQ.chEbUKEbapvzZKRBrvDy_cER31hVdrdn3qhXLVxuOUI','2022-05-27 10:37:27','2022-05-27 10:37:27','-9','-9','2022-05-27 10:34:51','2022-05-27 10:34:51',NULL,'4FXvuiZVMq7ir2nS','web','Firefox (100.0)','14.207.180.87'),(73,'96ed37eb-de98-492f-affd-65f242cbfd99','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI3MyIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjczIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NTQ4MjU5NTMsInJlZnJlc2hfYW1vdW50Ijo0MX0.ShxWTW5IdM5Yajy5Nc9p7ck4GMd1aDVSvzLOApo7xAM','2022-06-10 08:37:43','2022-06-10 08:37:43','-9','-9','2022-05-30 14:46:45','2022-05-30 14:46:45','2022-06-10 08:37:33','8acf69b296d4ab7a','mobile_app','samsung SM-N986B','49.230.4.255'),(74,'f921703b-2d45-445e-abf6-409412568346','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI3NCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6Ijc0IiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NTQwNzMwNzgsInJlZnJlc2hfYW1vdW50IjowfQ.slegw20xEXj1tRndV7eOBRkM3cJqqWF5ASFTajQ3BLU','2022-06-01 15:31:53','2022-06-01 15:31:53','-9','-9','2022-06-01 15:29:38','2022-06-01 15:29:38',NULL,'4FXvuiZVMq7ir2nS','web','Firefox (100.0)','14.207.179.55'),(75,'67b955f7-4027-4a4d-9905-0489d6a2a435','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI3NSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6Ijc1IiwibWVtYmVyX25vIjoiZXRubW9kZTEiLCJleHAiOjE2NTQ0ODc4MDksInJlZnJlc2hfYW1vdW50IjoxfQ.ANCUUU10Yyv3ThTRSTyQOuRWmePz6v_yobn_djzIa-8','2022-06-06 10:59:39','2022-06-06 10:59:39','-6','-6','2022-06-06 10:41:47','2022-06-06 10:41:47','2022-06-06 10:41:49','E298B170-0327-438F-8ED4-55AB1A3307BE','mobile_app','Apple iPhone 13 Pro Max','180.183.155.90'),(76,'4435efb0-fff7-45b2-a52f-bb72317d6ae8','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI3NiIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6Ijc2IiwibWVtYmVyX25vIjoiZXRubW9kZTEiLCJleHAiOjE2NTQ0ODg4ODEsInJlZnJlc2hfYW1vdW50IjoxfQ.eOGMHNkElcSCRdit-xrbvCAaWt6e0iyOUzB25Ap9YS0','2022-06-06 22:14:47','2022-06-06 22:14:47','-6','-6','2022-06-06 10:59:39','2022-06-06 10:59:39','2022-06-06 10:59:41','7E4305C7-AAE3-41B9-BD16-74640DE29CF2','mobile_app','Apple iPhone 13','180.183.155.90'),(77,'bbc21b3b-7f32-45b0-b676-47d56e1366a1','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI3NyIsInVzZXJfdHlwZSI6IjkiLCJpZF90b2tlbiI6Ijc3IiwibWVtYmVyX25vIjoiZGV2QG1vZGUiLCJleHAiOjE2NTQ0OTgxMDcsInJlZnJlc2hfYW1vdW50IjowfQ.S1-Ay9KeFdiHV66BNw6kODJOoXslc42OJ86EOnAxyAc','2022-06-07 15:54:15','2022-06-07 15:54:15','-6','-6','2022-06-06 13:33:27','2022-06-06 13:33:27',NULL,'4dXLmTDyZ2jJC7A9','web','Chrome (102.0.0.0)','180.183.155.90'),(78,'6dd6ad1b-09ab-4bc8-ab2b-62049f29846a','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI3OCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6Ijc4IiwibWVtYmVyX25vIjoiZXRubW9kZTEiLCJleHAiOjE2NTQ1MjkzOTIsInJlZnJlc2hfYW1vdW50IjoxfQ.0hh0PukH_x4mzjjPUY6nzFNWCkpnzdG37o0uqAGD_uw','2022-06-07 16:02:52','2022-06-07 16:02:52','-6','-6','2022-06-06 22:14:47','2022-06-06 22:14:47','2022-06-06 22:14:52','B3EF66B1-340D-4CF0-AD94-15C42700F88B','mobile_app','Apple iPad Air (3rd generation)','198.27.180.116'),(79,'2fd1e5b9-788a-41a5-b351-8d98ee058a28','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI3OSIsInVzZXJfdHlwZSI6IjkiLCJpZF90b2tlbiI6Ijc5IiwibWVtYmVyX25vIjoiZGV2QG1vZGUiLCJleHAiOjE2NTQ1OTI5NTUsInJlZnJlc2hfYW1vdW50IjowfQ.EOCtbbbH5Evt7Tqmd9vOPMFGk-8Q4hCZsYpkcDmFJxY','2022-06-07 16:07:43','2022-06-07 16:07:43','-6','-6','2022-06-07 15:54:15','2022-06-07 15:54:15',NULL,'U2usDdswBpqjVfuL','web','Chrome (102.0.0.0)','180.183.155.90'),(80,'af599e2c-9b2e-488d-a500-37f3f21ba464','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI4MCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjgwIiwibWVtYmVyX25vIjoiZXRubW9kZTEiLCJleHAiOjE2NTQ1OTM0NzksInJlZnJlc2hfYW1vdW50IjoxfQ.7Ey5wMPoJVTul8s4e2QkEVFrSoR4RRyhtIBj5vd5sEg','2022-06-07 16:04:14','2022-06-07 16:04:14','-6','-6','2022-06-07 16:02:52','2022-06-07 16:02:52','2022-06-07 16:02:59','43972dec075d3e22','mobile_app','HUAWEI ANA-NX9','42.3.86.12'),(81,'d9486841-2cc3-41a0-838c-3219133a4d7f','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI4MSIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjgxIiwibWVtYmVyX25vIjoiZXRubW9kZTEiLCJleHAiOjE2NTQ1OTM1NTcsInJlZnJlc2hfYW1vdW50IjoxfQ.ecwUtXRGpTDGp2pAVHjnMIbPjeagSrQNnRUTaB1anuc',NULL,NULL,'0','0','2022-06-07 16:04:14','2022-06-07 16:04:14','2022-06-07 16:04:17','188660758485606b','mobile_app','HONOR STK-LX1','42.3.86.12'),(82,'be569571-66f3-4f15-8d86-2a543435b603','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI4MiIsInVzZXJfdHlwZSI6IjkiLCJpZF90b2tlbiI6IjgyIiwibWVtYmVyX25vIjoiZGV2QG1vZGUiLCJleHAiOjE2NTQ1OTM3NjMsInJlZnJlc2hfYW1vdW50IjowfQ.usMqvn6CX_YUkp7b_Oi4RXbnQfWbh4GWvX7AioFy5jE',NULL,NULL,'0','0','2022-06-07 16:07:43','2022-06-07 16:07:43',NULL,'h3IUB9Znpg4LGB2E','web','Chrome (102.0.0.0)','180.183.155.90'),(83,'4c4d995f-7433-4f4e-a916-7eed9277a8ad','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI4MyIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6IjgzIiwibWVtYmVyX25vIjoiMDAwMDQ0OTEiLCJleHAiOjE2NTgwNjExNzcsInJlZnJlc2hfYW1vdW50Ijo1Mn0.FrmTz59KODCUPDI-dleLLn8vbZe87xZX6JmBLegUCnQ',NULL,NULL,'0','0','2022-06-10 08:38:34','2022-06-10 08:38:34','2022-07-17 19:17:57','8acf69b296d4ab7a','mobile_app','samsung SM-N986B','49.230.119.144'),(84,'a1bfef72-6bd8-4512-a9c1-2288123a382f','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZF91c2VybG9naW4iOiI4NCIsInVzZXJfdHlwZSI6IjAiLCJpZF90b2tlbiI6Ijg0IiwibWVtYmVyX25vIjoiMDAwMDMwNzYiLCJleHAiOjE2NTUxMDU0OTksInJlZnJlc2hfYW1vdW50Ijo0fQ.WasYK4xOfsgPufz0U21aRTuHzWe2vPogvxKkhj8Jiu8',NULL,NULL,'0','0','2022-06-13 14:02:47','2022-06-13 14:02:47','2022-06-13 14:16:39','203e15225b3c6932','mobile_app','OPPO CPH1911','49.229.217.148');
/*!40000 ALTER TABLE `gctoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gctransaction`
--

DROP TABLE IF EXISTS `gctransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gctransaction` (
  `ref_no` varchar(25) NOT NULL,
  `transaction_type_code` char(3) NOT NULL,
  `from_account` varchar(100) NOT NULL,
  `destination_type` enum('1','2','3') NOT NULL DEFAULT '1',
  `destination` varchar(50) NOT NULL,
  `transfer_mode` enum('1','2','3','9','4','5') NOT NULL DEFAULT '9',
  `amount` decimal(12,2) NOT NULL,
  `fee_amt` decimal(10,2) NOT NULL DEFAULT 0.00,
  `penalty_amt` decimal(10,2) NOT NULL DEFAULT 0.00,
  `amount_receive` decimal(15,2) NOT NULL,
  `trans_flag` enum('1','-1') NOT NULL DEFAULT '1',
  `operate_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `result_transaction` enum('1','-8','-9') NOT NULL DEFAULT '1',
  `cancel_date` datetime DEFAULT NULL,
  `member_no` char(8) NOT NULL,
  `ref_no_1` varchar(50) DEFAULT NULL,
  `coop_slip_no` varchar(30) DEFAULT NULL,
  `etn_refno` text DEFAULT NULL,
  `id_userlogin` mediumint(8) unsigned NOT NULL,
  `ref_no_source` text DEFAULT NULL,
  `bank_code` char(3) DEFAULT NULL,
  PRIMARY KEY (`ref_no`),
  KEY `FK_TRANSACTION_BY` (`id_userlogin`),
  KEY `FK_MEMBER_TRANSACTION` (`member_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gctransaction`
--

LOCK TABLES `gctransaction` WRITE;
/*!40000 ALTER TABLE `gctransaction` DISABLE KEYS */;
INSERT INTO `gctransaction` VALUES ('1638976654aA6','WTX','0000015551','1','8500242248','9',100.00,10.00,0.00,100.00,'-1','2021-12-08 22:17:34','2021-12-08 22:17:35','1',NULL,'00004491','0000015551',NULL,NULL,3,NULL,'006'),('16520798171us','WTX','0000015551','1','8500242248','9',200.00,7.00,0.00,200.00,'-1','2022-05-09 14:03:37','2022-05-09 14:03:38','1',NULL,'00004491','0000015551',NULL,NULL,53,NULL,'006'),('16533763932xe','WTX','0000015551','1','8500242248','9',129.00,7.00,0.00,129.00,'-1','2022-05-24 14:13:13','2022-05-24 14:13:13','1',NULL,'00004491','0000015551',NULL,NULL,53,NULL,'006'),('1653462563Chg','WTX','0000016937','1','7730241242','9',50.00,7.00,0.00,50.00,'-1','2022-05-25 14:09:23','2022-05-25 14:09:24','1',NULL,'00005367','0000016937',NULL,NULL,59,NULL,'006'),('1653462707Om1','WTX','0000015551','1','8500242248','9',93.00,7.00,0.00,93.00,'-1','2022-05-25 14:11:47','2022-05-25 14:11:47','1',NULL,'00004491','0000015551',NULL,NULL,53,NULL,'006'),('1654671229DBC','WTX','0000015340','1','9851006637','9',189.00,7.00,0.00,189.00,'-1','2022-06-08 13:53:49','2022-06-08 13:53:50','1',NULL,'00004378','0000015340',NULL,NULL,6,NULL,'006'),('16546712992tw','WTX','0000015551','1','8500242248','9',125.00,7.00,0.00,125.00,'-1','2022-06-08 13:54:59','2022-06-08 13:55:00','1',NULL,'00004491','0000015551',NULL,NULL,73,NULL,'006'),('1654745128zts','WTX','0000015340','1','9851006637','9',4891.00,7.00,0.00,4891.00,'-1','2022-06-09 10:25:28','2022-06-09 10:25:29','1',NULL,'00004378','0000015340',NULL,NULL,6,NULL,'006'),('1654746073NLd','WTX','0000005977','1','3220492614','9',400.00,7.00,0.00,400.00,'-1','2022-06-09 10:41:13','2022-06-09 10:41:14','1',NULL,'00003171','0000005977',NULL,NULL,60,NULL,'006'),('1654829407f2Q','WTX','0000015340','1','9851006637','9',4993.00,7.00,0.00,4993.00,'-1','2022-06-10 09:50:07','2022-06-10 09:50:08','1',NULL,'00004378','0000015340',NULL,NULL,6,NULL,'006'),('1655104600iCB','WTX','0000016952','1','4520174716','9',18500.00,7.00,0.00,18500.00,'-1','2022-06-13 14:16:40','2022-06-13 14:16:41','1',NULL,'00003076','0000016952',NULL,NULL,84,NULL,'006'),('1655397607Fid','WTX','0000015340','1','9851006637','9',2993.00,7.00,0.00,2993.00,'-1','2022-06-16 23:40:07','2022-06-16 23:40:08','1',NULL,'00004378','0000015340',NULL,NULL,6,NULL,'006'),('1655864937IG0','WTX','0000015551','1','8500242248','9',200.00,7.00,0.00,200.00,'-1','2022-06-22 09:28:57','2022-06-22 09:28:57','1',NULL,'00004491','0000015551',NULL,NULL,83,NULL,'006'),('1655865183njO','DIM','INET-BANK   70907079','1','202206220932253905','5',111.00,0.00,0.00,111.00,'-1','2022-06-22 09:33:03','2022-06-22 09:33:03','1',NULL,'00004491',NULL,NULL,NULL,83,'202206220932253905',NULL),('16559665260E0','DIM','ITMX        91153347','1','202206231341228855','5',109.00,0.00,0.00,109.00,'-1','2022-06-23 13:42:06','2022-06-23 13:42:07','1',NULL,'00004378',NULL,NULL,NULL,6,'202206231341228855',NULL),('16559667405tt','WTX','0000015340','1','9851006637','9',1993.00,7.00,0.00,1993.00,'-1','2022-06-23 13:45:40','2022-06-23 13:45:40','1',NULL,'00004378','0000015340',NULL,NULL,6,NULL,'006'),('16563123365M5','WTX','0000015551','1','8500242248','9',10543.00,7.00,0.00,10543.00,'-1','2022-06-27 13:45:36','2022-06-27 13:45:37','1',NULL,'00004491','0000015551',NULL,NULL,83,NULL,'006'),('1656312457nRO','DIM','INET-BANK   56350376','1','202206271346426225','5',135.00,0.00,0.00,135.00,'-1','2022-06-27 13:47:37','2022-06-27 13:47:37','1',NULL,'00004491',NULL,NULL,NULL,83,'202206271346426225',NULL),('165648575522K','DIM','INET-BANK   92942468','1','202206291355112742','5',99.00,0.00,0.00,99.00,'-1','2022-06-29 13:55:55','2022-06-29 13:55:55','1',NULL,'00004378',NULL,NULL,NULL,6,'202206291355112742',NULL),('1656485971Tka','WTX','0000015340','1','9851006637','9',4003.00,7.00,0.00,4003.00,'-1','2022-06-29 13:59:31','2022-06-29 13:59:32','1',NULL,'00004378','0000015340',NULL,NULL,6,NULL,'006'),('1656569981xWr','DIM','ITMX        12317290','1','202206301318471827','5',183.00,0.00,0.00,183.00,'-1','2022-06-30 13:19:41','2022-06-30 13:19:41','1',NULL,'00004491',NULL,NULL,NULL,83,'202206301318471827',NULL),('1656570088R2O','WTX','0000015551','1','8500242248','9',135.00,7.00,0.00,135.00,'-1','2022-06-30 13:21:28','2022-06-30 13:21:28','1',NULL,'00004491','0000015551',NULL,NULL,83,NULL,'006'),('1656767366MhI','WTX','0000005977','1','3220492614','9',1700.00,7.00,0.00,1700.00,'-1','2022-07-02 20:09:26','2022-07-02 20:09:27','1',NULL,'00003171','0000005977',NULL,NULL,60,NULL,'006'),('16569142444tP','DIM','INET-BANK   95348787','1','202207041256341117','5',88.00,0.00,0.00,88.00,'-1','2022-07-04 12:57:24','2022-07-04 12:57:24','1',NULL,'00004491',NULL,NULL,NULL,83,'202207041256341117',NULL),('1656914308GsM','WTX','0000015551','1','8500242248','9',199.00,7.00,0.00,199.00,'-1','2022-07-04 12:58:28','2022-07-04 12:58:28','1',NULL,'00004491','0000015551',NULL,NULL,83,NULL,'006'),('1656918963pjM','WTX','0000016937','1','7730241242','9',23.00,7.00,0.00,23.00,'-1','2022-07-04 14:16:03','2022-07-04 14:16:04','1',NULL,'00005367','0000016937',NULL,NULL,59,NULL,'006'),('1656919126HqR','DIM','INET-BANK   96825808','1','202207041418094386','5',23.00,0.00,0.00,23.00,'-1','2022-07-04 14:18:46','2022-07-04 14:18:46','1',NULL,'00005367',NULL,NULL,NULL,59,'202207041418094386',NULL),('16569191916ui','WTX','0000015340','1','9851006637','9',6000.00,7.00,0.00,6000.00,'-1','2022-07-04 14:19:51','2022-07-04 14:19:52','1',NULL,'00004378','0000015340',NULL,NULL,6,NULL,'006'),('1657076696JXi','DIM','INET-BANK   29676920','1','202207061003484719','5',123.00,0.00,0.00,123.00,'-1','2022-07-06 10:04:56','2022-07-06 10:04:56','1',NULL,'00004491',NULL,NULL,NULL,83,'202207061003484719',NULL),('16570770427lX','WTX','1400000106','1','8500242248','9',101.00,7.00,0.00,101.00,'-1','2022-07-06 10:10:42','2022-07-06 10:10:43','1',NULL,'00004491','1400000106',NULL,NULL,83,NULL,'006'),('1657082349H62','DIM','INET-BANK   31290529','1','202207061138326773','5',112.00,0.00,0.00,112.00,'-1','2022-07-06 11:39:09','2022-07-06 11:39:09','1',NULL,'00004491',NULL,NULL,NULL,83,'202207061138326773',NULL),('1657082485ILf','WTX','0100008365','1','8500242248','9',321.00,7.00,100.00,321.00,'-1','2022-07-06 11:41:25','2022-07-06 11:41:26','1',NULL,'00004491','0100008365',NULL,NULL,83,NULL,'006');
/*!40000 ALTER TABLE `gctransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcuserallowacctransaction`
--

DROP TABLE IF EXISTS `gcuserallowacctransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcuserallowacctransaction` (
  `id_userallowacctran` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `deptaccount_no` varchar(15) NOT NULL,
  `member_no` char(8) NOT NULL,
  `limit_transaction_amt` decimal(15,2) NOT NULL DEFAULT 999999999.00,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_use` enum('0','1','-9') NOT NULL DEFAULT '1',
  `id_accountconstant` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id_userallowacctran`),
  KEY `FK_USER_CONSENT_ALLOW_ACC` (`member_no`),
  KEY `FK_ALLOW_DEPOSITTYPE_TRANSACTION` (`id_accountconstant`),
  KEY `deptaccount_no` (`deptaccount_no`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcuserallowacctransaction`
--

LOCK TABLES `gcuserallowacctransaction` WRITE;
/*!40000 ALTER TABLE `gcuserallowacctransaction` DISABLE KEYS */;
INSERT INTO `gcuserallowacctransaction` VALUES (1,'0000015551','00004491',999999999.00,'2021-12-08 21:54:36','2022-05-30 16:31:09','-9',1),(2,'0000015340','00004378',999999999.00,'2022-05-06 16:46:22','2022-05-06 16:46:22','1',1),(3,'0000016937','00005367',999999999.00,'2022-05-17 12:18:19','2022-05-17 12:18:19','1',1),(4,'0000000041','00002232',999999999.00,'2022-05-17 12:38:52','2022-05-17 12:38:52','1',1),(5,'0000005977','00003171',999999999.00,'2022-05-17 12:39:52','2022-05-17 12:39:52','1',1),(6,'0000000031','00002799',999999999.00,'2022-05-17 12:52:47','2022-05-17 12:52:47','1',1),(7,'0000016952','00003076',999999999.00,'2022-05-17 14:10:55','2022-05-17 14:10:55','1',1),(8,'0100008365','00004491',999999999.00,'2022-05-20 13:18:40','2022-05-20 13:20:22','-9',2),(9,'0000015333','00004356',999999999.00,'2022-05-24 15:01:49','2022-05-24 15:01:49','1',1),(10,'0000015551','00004491',999999999.00,'2022-05-30 16:34:25','2022-06-01 15:40:50','-9',1),(11,'0000015551','00004491',999999999.00,'2022-06-01 15:42:39','2022-06-02 09:11:45','-9',1),(12,'0000015551','00004491',999999999.00,'2022-06-02 09:11:52','2022-06-02 09:11:52','1',1),(13,'0000016951','00000873',999999999.00,'2022-06-10 14:58:14','2022-06-10 14:58:14','1',1),(14,'1400000106','00004491',999999999.00,'2022-07-05 15:22:54','2022-07-05 15:22:54','1',14),(15,'0100008365','00004491',999999999.00,'2022-07-06 11:14:20','2022-07-06 11:14:20','1',2);
/*!40000 ALTER TABLE `gcuserallowacctransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gcuserlogin`
--

DROP TABLE IF EXISTS `gcuserlogin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gcuserlogin` (
  `id_userlogin` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `member_no` char(8) NOT NULL,
  `device_name` text NOT NULL,
  `channel` enum('mobile_app','web','line','unknown') NOT NULL DEFAULT 'unknown',
  `login_date` datetime NOT NULL DEFAULT current_timestamp(),
  `logout_date` datetime DEFAULT NULL,
  `is_login` enum('0','1','-5','-6','-7','-8','-9','-10','-88','-99') NOT NULL DEFAULT '1',
  `unique_id` varchar(50) NOT NULL,
  `status_firstapp` enum('0','1','2') NOT NULL DEFAULT '1',
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `id_token` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id_userlogin`),
  KEY `FK_TOKEN` (`id_token`),
  KEY `FK_MEMBER_LOGIN` (`member_no`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gcuserlogin`
--

LOCK TABLES `gcuserlogin` WRITE;
/*!40000 ALTER TABLE `gcuserlogin` DISABLE KEYS */;
INSERT INTO `gcuserlogin` VALUES (1,'etnmode3','Chrome (96.0.4664.93)','web','2021-12-15 12:06:44','2021-12-15 12:06:59','0','SeVjcV5M18KKGS2g','1','2021-12-15 12:06:59',1),(2,'00004491','samsung SM-N986B','mobile_app','2021-12-15 12:18:14','2022-01-14 09:43:45','-88','616eb0257faf43fb','1','2022-01-14 09:43:45',2),(3,'00004491','Chrome (96.0.4664.104)','web','2021-12-15 12:21:35','2021-12-15 12:23:29','0','eluUolhZVq9KlcBg','1','2021-12-15 12:23:29',3),(4,'00004491','Firefox (95.0)','web','2021-12-15 13:07:13','2021-12-15 13:08:37','0','U9fDYpxDaCrDJUAS','1','2021-12-15 13:08:37',4),(5,'00005060','Apple iPhone 12 Pro','mobile_app','2021-12-15 13:12:08',NULL,'1','B07E1931-A940-4ECC-81DC-22FEF59210EF','1','2021-12-15 13:12:08',5),(6,'00004378','Apple iPhone SE','mobile_app','2021-12-15 13:13:03',NULL,'1','998F2077-6BBB-419A-AD4E-23982930BFA5','1','2021-12-15 13:13:03',6),(7,'00005060','Chrome (96.0.4664.110)','web','2021-12-15 13:18:31',NULL,'1','BVedBnZvDRWlroCP','1','2021-12-15 13:18:31',7),(8,'00004378','Firefox (95.0)','web','2021-12-15 13:19:15',NULL,'1','NGCymkmt3thpeA2E','1','2021-12-15 13:19:15',8),(9,'00004491','Firefox (95.0)','web','2021-12-17 15:12:09','2021-12-17 15:15:31','0','U9fDYpxDaCrDJUAS','1','2021-12-17 15:15:31',9),(10,'etnmode1','Chrome (97.0.4692.71)','web','2022-01-13 09:37:38',NULL,'1','a6tvzv2M98oM8YmB','1','2022-01-13 09:37:38',10),(11,'00004491','samsung SM-N986B','mobile_app','2022-01-14 09:46:38','2022-01-24 14:45:32','-5','616eb0257faf43fb','1','2022-01-24 14:45:32',11),(12,'00004491','Firefox (96.0)','web','2022-01-14 09:48:06','2022-01-14 09:51:47','0','4FXvuiZVMq7ir2nS','1','2022-01-14 09:51:47',12),(13,'00004491','Firefox (96.0)','web','2022-01-17 09:34:54','2022-01-17 09:43:37','0','4FXvuiZVMq7ir2nS','1','2022-01-17 09:43:37',13),(14,'00004491','Firefox (96.0)','web','2022-01-20 08:45:54','2022-01-20 09:55:38','-5','4FXvuiZVMq7ir2nS','1','2022-01-20 09:55:38',14),(15,'00004491','Firefox (96.0)','web','2022-01-20 09:55:38','2022-01-20 13:06:52','-5','4FXvuiZVMq7ir2nS','1','2022-01-20 13:06:52',15),(16,'00004491','Firefox (96.0)','web','2022-01-20 13:06:52','2022-01-20 13:07:32','0','4FXvuiZVMq7ir2nS','1','2022-01-20 13:07:32',16),(17,'00004491','Firefox (96.0)','web','2022-01-20 13:43:21','2022-01-20 13:43:39','0','4FXvuiZVMq7ir2nS','1','2022-01-20 13:43:39',17),(18,'00004491','Firefox (96.0)','web','2022-01-20 16:45:59','2022-01-20 16:58:52','0','4FXvuiZVMq7ir2nS','1','2022-01-20 16:58:52',18),(19,'00004491','Firefox (96.0)','web','2022-01-21 10:51:46','2022-01-21 10:52:15','0','4FXvuiZVMq7ir2nS','1','2022-01-21 10:52:15',19),(20,'00004491','Firefox (96.0)','web','2022-01-24 14:41:00','2022-01-24 14:50:55','0','4FXvuiZVMq7ir2nS','1','2022-01-24 14:50:55',20),(21,'00004491','samsung SM-N986B','mobile_app','2022-01-24 14:45:32','2022-03-08 16:53:03','-88','8acf69b296d4ab7a','1','2022-03-08 16:53:03',21),(22,'00004491','Firefox (96.0)','web','2022-01-24 17:10:39','2022-01-24 17:14:49','0','4FXvuiZVMq7ir2nS','1','2022-01-24 17:14:49',22),(23,'00004491','Firefox (96.0)','web','2022-01-24 17:15:04','2022-01-24 17:15:23','0','4FXvuiZVMq7ir2nS','1','2022-01-24 17:15:23',23),(24,'00004491','Firefox (96.0)','web','2022-01-25 12:58:28','2022-01-25 13:11:16','0','4FXvuiZVMq7ir2nS','1','2022-01-25 13:11:16',24),(25,'00004491','Firefox (96.0)','web','2022-01-26 08:28:09','2022-01-26 08:39:42','0','4FXvuiZVMq7ir2nS','1','2022-01-26 08:39:42',25),(26,'00004491','Firefox (96.0)','web','2022-01-27 15:45:54','2022-01-27 16:01:31','0','4FXvuiZVMq7ir2nS','1','2022-01-27 16:01:31',26),(27,'00004491','Edge (97.0.1072.76)','web','2022-01-31 13:17:26','2022-02-01 13:36:49','-5','rWSMd8DgjmCmABCi','1','2022-02-01 13:36:49',27),(28,'00004491','Edge (97.0.1072.76)','web','2022-02-01 13:36:49','2022-02-01 13:58:17','-5','rWSMd8DgjmCmABCi','1','2022-02-01 13:58:17',28),(29,'00004491','Edge (97.0.1072.76)','web','2022-02-01 13:58:17','2022-02-01 14:10:09','0','rWSMd8DgjmCmABCi','1','2022-02-01 14:10:09',29),(30,'00004491','Edge (97.0.1072.76)','web','2022-02-02 09:27:16','2022-02-02 09:27:36','0','rWSMd8DgjmCmABCi','1','2022-02-02 09:27:36',30),(31,'00004491','Edge (97.0.1072.76)','web','2022-02-03 13:44:05','2022-02-03 13:45:09','0','rWSMd8DgjmCmABCi','1','2022-02-03 13:45:09',31),(32,'00004491','Edge (97.0.1072.76)','web','2022-02-04 08:37:21','2022-02-04 08:39:43','0','rWSMd8DgjmCmABCi','1','2022-02-04 08:39:43',32),(33,'00004491','Edge (97.0.1072.76)','web','2022-02-04 18:19:38','2022-02-04 18:20:45','0','rWSMd8DgjmCmABCi','1','2022-02-04 18:20:45',33),(34,'00004491','Edge (98.0.1108.43)','web','2022-02-07 10:03:05','2022-02-07 10:04:30','0','rWSMd8DgjmCmABCi','1','2022-02-07 10:04:30',34),(35,'00004491','Edge (98.0.1108.43)','web','2022-02-08 09:00:57','2022-02-08 09:01:28','0','rWSMd8DgjmCmABCi','1','2022-02-08 09:01:28',35),(36,'00004491','Edge (98.0.1108.43)','web','2022-02-14 09:11:05','2022-02-14 09:12:16','0','rWSMd8DgjmCmABCi','1','2022-02-14 09:12:16',36),(37,'00004491','Edge (98.0.1108.50)','web','2022-02-15 10:07:57','2022-02-15 10:11:23','0','rWSMd8DgjmCmABCi','1','2022-02-15 10:11:23',37),(38,'00004491','Edge (98.0.1108.56)','web','2022-02-22 08:28:50','2022-02-22 08:30:46','0','rWSMd8DgjmCmABCi','1','2022-02-22 08:30:46',38),(39,'00004491','Edge (98.0.1108.56)','web','2022-02-22 14:38:25','2022-02-23 14:33:37','-5','rWSMd8DgjmCmABCi','1','2022-02-23 14:33:37',39),(40,'00004491','Edge (98.0.1108.56)','web','2022-02-23 14:33:37','2022-02-23 14:44:20','0','rWSMd8DgjmCmABCi','1','2022-02-23 14:44:20',40),(41,'etnmode4','Redmi M2101K6G','mobile_app','2022-02-24 14:53:02','2022-02-24 15:46:20','0','24b3bd50fec9cd8a','1','2022-02-24 15:46:20',41),(42,'etnmode4','Redmi M2101K6G','mobile_app','2022-02-24 16:13:24','2022-02-28 14:22:35','0','24b3bd50fec9cd8a','1','2022-02-28 14:22:35',42),(43,'00004491','Edge (98.0.1108.56)','web','2022-02-28 12:17:53','2022-02-28 16:44:56','-5','rWSMd8DgjmCmABCi','1','2022-02-28 16:44:56',43),(44,'etnmode4','Apple iPad','mobile_app','2022-02-28 15:14:54',NULL,'1','159B66EE-4C88-4807-B867-7103124C52EC','1','2022-02-28 15:14:54',44),(45,'00004491','Edge (98.0.1108.56)','web','2022-02-28 16:44:56','2022-02-28 16:59:18','0','rWSMd8DgjmCmABCi','1','2022-02-28 16:59:18',45),(46,'00004491','Edge (98.0.1108.62)','web','2022-03-01 09:26:02','2022-03-01 09:29:18','0','rWSMd8DgjmCmABCi','1','2022-03-01 09:29:18',46),(47,'00004491','Edge (98.0.1108.62)','web','2022-03-02 15:09:35','2022-03-02 15:28:57','0','rWSMd8DgjmCmABCi','1','2022-03-02 15:28:57',47),(48,'00004491','Edge (98.0.1108.62)','web','2022-03-04 11:58:26','2022-03-04 12:00:05','0','rWSMd8DgjmCmABCi','1','2022-03-04 12:00:05',48),(49,'00004491','samsung SM-N986B','mobile_app','2022-03-08 17:06:39','2022-03-08 17:14:38','0','8acf69b296d4ab7a','1','2022-03-08 17:14:38',49),(50,'00004491','samsung SM-N986B','mobile_app','2022-03-08 17:17:25','2022-03-09 16:34:05','0','8acf69b296d4ab7a','1','2022-03-09 16:34:05',50),(51,'00004491','samsung SM-N986B','mobile_app','2022-03-14 11:02:59','2022-03-14 16:31:51','0','8acf69b296d4ab7a','1','2022-03-14 16:31:51',51),(52,'00004491','samsung SM-N986B','mobile_app','2022-03-15 09:43:19','2022-03-15 10:56:12','0','8acf69b296d4ab7a','1','2022-03-15 10:56:12',52),(53,'00004491','samsung SM-N986B','mobile_app','2022-03-18 14:22:07','2022-05-30 14:45:58','0','8acf69b296d4ab7a','1','2022-05-30 14:45:58',53),(54,'00004491','Chrome (100.0.4896.75)','web','2022-04-05 17:54:09','2022-04-05 17:56:13','0','iXxEEtDJbRq2fCsc','1','2022-04-05 17:56:13',54),(55,'etnmode1','HUAWEI ELE-L09','mobile_app','2022-04-06 22:22:28','2022-06-06 10:41:47','-5','79c8d8c64d2b2380','1','2022-06-06 10:41:47',55),(56,'dev@mode','Apple iPhone 13 Pro','mobile_app','2022-04-07 14:21:34','2022-05-06 15:10:48','0','11B46D64-C0F9-470E-8494-2FE94CAA164D','1','2022-05-06 15:10:48',56),(57,'00004491','Chrome (100.0.4896.127)','web','2022-04-27 14:53:56','2022-04-27 15:00:22','0','iXxEEtDJbRq2fCsc','1','2022-04-27 15:00:22',57),(58,'00004491','Chrome (101.0.4951.54)','web','2022-05-10 08:36:12','2022-05-27 10:34:51','-5','iXxEEtDJbRq2fCsc','1','2022-05-27 10:34:51',58),(59,'00005367','OPPO CPH1969','mobile_app','2022-05-17 12:16:54',NULL,'1','e7022fa179fd036c','1','2022-05-17 12:16:54',59),(60,'00003171','OPPO CPH1819','mobile_app','2022-05-17 12:31:51',NULL,'1','942af199e53f43e4','1','2022-05-17 12:31:51',60),(61,'00002232','Apple iPhone SE','mobile_app','2022-05-17 12:32:19',NULL,'1','80F01475-AD3F-4609-8F5B-02104CA9284B','1','2022-05-17 12:32:19',61),(62,'00002949','Apple iPhone XR','mobile_app','2022-05-17 12:32:40',NULL,'1','7DA75B13-3C78-44A3-91B4-DC64E7B5AEAA','1','2022-05-17 12:32:40',62),(63,'00003089','samsung SM-A125F','mobile_app','2022-05-17 12:34:12',NULL,'1','5697244389026fc2','1','2022-05-17 12:34:12',63),(64,'00002799','samsung SM-G925F','mobile_app','2022-05-17 12:42:27',NULL,'1','29cf7b6c9a76e667','1','2022-05-17 12:42:27',64),(65,'00000873','samsung SM-A515F','mobile_app','2022-05-17 13:02:51',NULL,'1','41b912b63e229c10','1','2022-05-17 13:02:51',65),(66,'00002539','OPPO CPH2237','mobile_app','2022-05-17 13:15:01',NULL,'1','6cc0333ac337238f','1','2022-05-17 13:15:01',66),(67,'00004408','samsung SM-N975F','mobile_app','2022-05-17 13:17:27',NULL,'1','9a487fda14af05d6','1','2022-05-17 13:17:27',67),(68,'00003076','OPPO CPH1911','mobile_app','2022-05-17 13:31:15','2022-06-04 06:14:12','0','203e15225b3c6932','1','2022-06-04 06:14:12',68),(69,'00003823','HUAWEI CLT-L29','mobile_app','2022-05-23 12:46:12',NULL,'1','1e6abd6578ebe644','1','2022-05-23 12:46:12',69),(70,'00005357','Apple iPhone 13 Pro Max','mobile_app','2022-05-24 14:58:56',NULL,'1','4A0FF276-4167-41A8-9735-4E7467EEAF9B','1','2022-05-24 14:58:56',70),(71,'00004356','samsung SM-A800F','mobile_app','2022-05-24 14:59:32',NULL,'1','a4d097fe60a593b8','1','2022-05-24 14:59:32',71),(72,'00004491','Firefox (100.0)','web','2022-05-27 10:34:51','2022-05-27 10:37:27','0','4FXvuiZVMq7ir2nS','1','2022-05-27 10:37:27',72),(73,'00004491','samsung SM-N986B','mobile_app','2022-05-30 14:46:45','2022-06-10 08:37:43','0','8acf69b296d4ab7a','1','2022-06-10 08:37:43',73),(74,'00004491','Firefox (100.0)','web','2022-06-01 15:29:38','2022-06-01 15:31:53','0','4FXvuiZVMq7ir2nS','1','2022-06-01 15:31:53',74),(75,'etnmode1','Apple iPhone 13 Pro Max','mobile_app','2022-06-06 10:41:47','2022-06-06 10:59:39','-5','E298B170-0327-438F-8ED4-55AB1A3307BE','1','2022-06-06 10:59:39',75),(76,'etnmode1','Apple iPhone 13','mobile_app','2022-06-06 10:59:39','2022-06-06 22:14:47','-5','7E4305C7-AAE3-41B9-BD16-74640DE29CF2','1','2022-06-06 22:14:47',76),(77,'dev@mode','Chrome (102.0.0.0)','web','2022-06-06 13:33:27','2022-06-07 15:54:15','-5','4dXLmTDyZ2jJC7A9','1','2022-06-07 15:54:15',77),(78,'etnmode1','Apple iPad Air (3rd generation)','mobile_app','2022-06-06 22:14:47','2022-06-07 16:02:52','-5','B3EF66B1-340D-4CF0-AD94-15C42700F88B','1','2022-06-07 16:02:52',78),(79,'dev@mode','Chrome (102.0.0.0)','web','2022-06-07 15:54:15','2022-06-07 16:07:43','-5','U2usDdswBpqjVfuL','1','2022-06-07 16:07:43',79),(80,'etnmode1','HUAWEI ANA-NX9','mobile_app','2022-06-07 16:02:52','2022-06-07 16:04:14','-5','43972dec075d3e22','1','2022-06-07 16:04:14',80),(81,'etnmode1','HONOR STK-LX1','mobile_app','2022-06-07 16:04:14',NULL,'1','188660758485606b','1','2022-06-07 16:04:14',81),(82,'dev@mode','Chrome (102.0.0.0)','web','2022-06-07 16:07:43',NULL,'1','h3IUB9Znpg4LGB2E','1','2022-06-07 16:07:43',82),(83,'00004491','samsung SM-N986B','mobile_app','2022-06-10 08:38:34',NULL,'1','8acf69b296d4ab7a','1','2022-06-10 08:38:34',83),(84,'00003076','OPPO CPH1911','mobile_app','2022-06-13 14:02:47',NULL,'1','203e15225b3c6932','1','2022-06-13 14:02:47',84);
/*!40000 ALTER TABLE `gcuserlogin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logacceptannounce`
--

DROP TABLE IF EXISTS `logacceptannounce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logacceptannounce` (
  `id_accept_ann` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_no` char(8) NOT NULL,
  `id_announce` mediumint(8) unsigned NOT NULL,
  `status_accept` enum('1','0') NOT NULL DEFAULT '1',
  `accept_date` datetime NOT NULL DEFAULT current_timestamp(),
  `id_userlogin` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id_accept_ann`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logacceptannounce`
--

LOCK TABLES `logacceptannounce` WRITE;
/*!40000 ALTER TABLE `logacceptannounce` DISABLE KEYS */;
/*!40000 ALTER TABLE `logacceptannounce` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logbindaccount`
--

DROP TABLE IF EXISTS `logbindaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logbindaccount` (
  `id_logbindaccount` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_no` char(8) NOT NULL,
  `id_userlogin` mediumint(8) NOT NULL,
  `bind_status` enum('1','-9') NOT NULL,
  `attempt_bind_date` datetime NOT NULL DEFAULT current_timestamp(),
  `response_code` char(6) DEFAULT NULL,
  `response_message` longtext DEFAULT NULL,
  `coop_account_no` varchar(15) DEFAULT NULL,
  `data_bind_error` longtext DEFAULT NULL,
  `query_error` text DEFAULT NULL,
  `query_flag` enum('1','-9') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_logbindaccount`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logbindaccount`
--

LOCK TABLES `logbindaccount` WRITE;
/*!40000 ALTER TABLE `logbindaccount` DISABLE KEYS */;
INSERT INTO `logbindaccount` VALUES (1,'00004491',3,'-9','2021-12-08 21:45:54','WS0039','Cannot insert bindaccountktb','00004491',NULL,NULL,'1'),(2,'00004491',3,'-9','2021-12-08 21:55:55','WS0039','Cannot insert bindaccountktb','00004491',NULL,NULL,'1'),(3,'00004491',3,'-9','2021-12-08 21:57:37','WS0039','Cannot insert bindaccountktb','00004491',NULL,NULL,'1'),(4,'00004491',3,'1','2021-12-08 22:06:54',NULL,NULL,'00004491',NULL,NULL,'1'),(5,'00004378',6,'1','2022-05-06 16:51:54',NULL,NULL,'00004378',NULL,NULL,'1'),(6,'00002232',61,'1','2022-05-17 12:42:25',NULL,NULL,'00002232',NULL,NULL,'1'),(7,'00003171',60,'1','2022-05-17 12:43:01',NULL,NULL,'00003171',NULL,NULL,'1'),(8,'00003089',63,'1','2022-05-17 12:43:08',NULL,NULL,'00003089',NULL,NULL,'1'),(9,'00003076',68,'1','2022-05-17 14:18:12',NULL,NULL,'00003076',NULL,NULL,'1'),(10,'00002799',64,'1','2022-05-17 14:26:37',NULL,NULL,'00002799',NULL,NULL,'1'),(11,'00005367',59,'1','2022-05-17 15:55:46',NULL,NULL,'00005367',NULL,NULL,'1'),(12,'00005367',59,'1','2022-05-19 16:03:32',NULL,NULL,'00005367',NULL,NULL,'1'),(13,'00005367',59,'1','2022-05-24 14:34:48',NULL,NULL,'00005367',NULL,NULL,'1'),(14,'00005367',59,'1','2022-05-25 14:03:54',NULL,NULL,'00005367',NULL,NULL,'1'),(15,'00005367',59,'1','2022-05-25 14:09:07',NULL,NULL,'00005367',NULL,NULL,'1'),(16,'00005367',59,'1','2022-07-07 15:30:11',NULL,NULL,'00005367',NULL,NULL,'1');
/*!40000 ALTER TABLE `logbindaccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logbuyshare`
--

DROP TABLE IF EXISTS `logbuyshare`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logbuyshare` (
  `id_buyshare` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_no` char(8) NOT NULL,
  `id_userlogin` mediumint(8) NOT NULL,
  `transaction_date` datetime NOT NULL DEFAULT current_timestamp(),
  `deptaccount_no` varchar(15) NOT NULL,
  `amt_transfer` decimal(15,2) NOT NULL,
  `status_flag` enum('0','1') NOT NULL,
  `destination` varchar(15) DEFAULT NULL,
  `response_code` char(6) DEFAULT NULL,
  `response_message` longtext DEFAULT NULL,
  PRIMARY KEY (`id_buyshare`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logbuyshare`
--

LOCK TABLES `logbuyshare` WRITE;
/*!40000 ALTER TABLE `logbuyshare` DISABLE KEYS */;
/*!40000 ALTER TABLE `logbuyshare` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logchangeinfo`
--

DROP TABLE IF EXISTS `logchangeinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logchangeinfo` (
  `id_editinfo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_no` char(8) NOT NULL,
  `old_data` char(10) NOT NULL,
  `new_data` char(10) NOT NULL,
  `data_type` enum('email','tel','address') NOT NULL,
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `id_userlogin` mediumint(8) NOT NULL,
  PRIMARY KEY (`id_editinfo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logchangeinfo`
--

LOCK TABLES `logchangeinfo` WRITE;
/*!40000 ALTER TABLE `logchangeinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `logchangeinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logdepttransbankerror`
--

DROP TABLE IF EXISTS `logdepttransbankerror`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logdepttransbankerror` (
  `id_deptransbankerr` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_no` char(8) NOT NULL,
  `id_userlogin` mediumint(8) NOT NULL,
  `transaction_date` datetime NOT NULL DEFAULT current_timestamp(),
  `sigma_key` char(36) NOT NULL,
  `amt_transfer` decimal(15,2) NOT NULL,
  `response_code` char(6) DEFAULT NULL,
  `response_message` longtext DEFAULT NULL,
  PRIMARY KEY (`id_deptransbankerr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logdepttransbankerror`
--

LOCK TABLES `logdepttransbankerror` WRITE;
/*!40000 ALTER TABLE `logdepttransbankerror` DISABLE KEYS */;
/*!40000 ALTER TABLE `logdepttransbankerror` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logeditadmincontrol`
--

DROP TABLE IF EXISTS `logeditadmincontrol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logeditadmincontrol` (
  `id_logeditadmincontrol` int(10) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(100) NOT NULL,
  `username` varchar(20) NOT NULL,
  `edit_date` datetime NOT NULL DEFAULT current_timestamp(),
  `use_list` text DEFAULT NULL,
  `details` text DEFAULT NULL,
  PRIMARY KEY (`id_logeditadmincontrol`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logeditadmincontrol`
--

LOCK TABLES `logeditadmincontrol` WRITE;
/*!40000 ALTER TABLE `logeditadmincontrol` DISABLE KEYS */;
INSERT INTO `logeditadmincontrol` VALUES (1,'manageuser','dev@mode','2021-12-15 10:44:24','delete core user','username demo was deleted'),(2,'manageuser','dev@mode','2021-12-15 10:44:26','delete core user','username Omsubsaman was deleted'),(3,'manageuser','dev@mode','2021-12-15 10:44:49','insert core user','add username : spsadmin'),(4,'manageuser','dev@mode','2021-12-15 10:44:54','change department ','id_section : 6 on username : spsadmin'),(5,'permissionmenu','dev@mode','2021-12-15 10:44:59','change permission menu','change permission all to status : 1 of username : spsadmin');
/*!40000 ALTER TABLE `logeditadmincontrol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logeditdocument`
--

DROP TABLE IF EXISTS `logeditdocument`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logeditdocument` (
  `id_editdocument` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(100) NOT NULL,
  `use_list` varchar(50) NOT NULL,
  `details` text NOT NULL,
  `edit_date` datetime NOT NULL DEFAULT current_timestamp(),
  `username` varchar(20) NOT NULL,
  PRIMARY KEY (`id_editdocument`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logeditdocument`
--

LOCK TABLES `logeditdocument` WRITE;
/*!40000 ALTER TABLE `logeditdocument` DISABLE KEYS */;
/*!40000 ALTER TABLE `logeditdocument` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logeditmobileadmin`
--

DROP TABLE IF EXISTS `logeditmobileadmin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logeditmobileadmin` (
  `id_logeditmobileadmin` int(10) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(100) NOT NULL,
  `username` varchar(20) NOT NULL,
  `date_usage` datetime NOT NULL DEFAULT current_timestamp(),
  `use_list` text DEFAULT NULL,
  `details` text DEFAULT NULL,
  PRIMARY KEY (`id_logeditmobileadmin`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logeditmobileadmin`
--

LOCK TABLES `logeditmobileadmin` WRITE;
/*!40000 ALTER TABLE `logeditmobileadmin` DISABLE KEYS */;
INSERT INTO `logeditmobileadmin` VALUES (1,'constantdeptaccount','dev@mode','2021-12-08 21:52:19','edit constant dept','DEPTTYPE_CODE=> 00 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =1 ALLOW_WITHDRAW_INSIDE =1 ALLOW_DEPOSIT_OUTSIDE =1 ALLOW_WITHDRAW_OUTSIDE =1 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 01 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 02 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 03 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 04 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 05 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 06 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 07 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 08 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 09 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 11 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 12 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 13 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 14 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 15 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 16 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 17 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 18 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 19 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 20 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 21 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 22 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0,DEPTTYPE_CODE=> 23 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0 '),(2,'userlogin','spsadmin','2021-12-15 11:43:35','logout','115'),(3,'userlogin','spsadmin','2021-12-15 11:43:41','logout','114'),(4,'userlogin','spsadmin','2021-12-15 11:43:45','logout','113'),(5,'userlogin','spsadmin','2021-12-15 11:43:49','logout','111'),(6,'userlogin','spsadmin','2021-12-15 11:43:53','logout','110'),(7,'userlogin','spsadmin','2021-12-15 11:43:55','logout','109'),(8,'userlogin','spsadmin','2021-12-15 11:43:59','logout','108'),(9,'userlogin','spsadmin','2021-12-15 11:44:02','logout','107'),(10,'userlogin','spsadmin','2021-12-15 11:44:05','logout','106'),(11,'userlogin','spsadmin','2021-12-15 11:44:07','logout','105'),(12,'userlogin','spsadmin','2021-12-15 11:44:09','logout','103'),(13,'userlogin','spsadmin','2021-12-15 11:44:12','logout','102'),(14,'userlogin','spsadmin','2021-12-15 11:44:13','logout','101'),(15,'userlogin','spsadmin','2021-12-15 11:44:14','logout','100'),(16,'userlogin','spsadmin','2021-12-15 11:44:17','logout','99'),(17,'userlogin','spsadmin','2021-12-15 11:44:18','logout','98'),(18,'userlogin','spsadmin','2021-12-15 11:44:21','logout','97'),(19,'userlogin','spsadmin','2021-12-15 11:44:24','logout','96'),(20,'userlogin','spsadmin','2021-12-15 11:44:26','logout','95'),(21,'userlogin','spsadmin','2021-12-15 11:44:28','logout','94'),(22,'userlogin','spsadmin','2021-12-15 11:44:30','logout','93'),(23,'userlogin','spsadmin','2021-12-15 11:44:31','logout','92'),(24,'userlogin','spsadmin','2021-12-15 11:44:33','logout','91'),(25,'userlogin','spsadmin','2021-12-15 11:44:35','logout','90'),(26,'userlogin','spsadmin','2021-12-15 11:44:38','logout','89'),(27,'userlogin','spsadmin','2021-12-15 11:44:40','logout','88'),(28,'userlogin','spsadmin','2021-12-15 11:44:42','logout','87'),(29,'userlogin','spsadmin','2021-12-15 11:44:44','logout','86'),(30,'userlogin','spsadmin','2021-12-15 11:44:45','logout','85'),(31,'userlogin','spsadmin','2021-12-15 11:44:47','logout','84'),(32,'userlogin','spsadmin','2021-12-15 11:44:48','logout','83'),(33,'userlogin','spsadmin','2021-12-15 11:44:50','logout','82'),(34,'userlogin','spsadmin','2021-12-15 11:44:52','logout','81'),(35,'userlogin','spsadmin','2021-12-15 11:44:55','logout','80'),(36,'userlogin','spsadmin','2021-12-15 11:44:57','logout','79'),(37,'userlogin','spsadmin','2021-12-15 11:44:59','logout','78'),(38,'userlogin','spsadmin','2021-12-15 11:45:00','logout','77'),(39,'userlogin','spsadmin','2021-12-15 11:45:02','logout','76'),(40,'userlogin','spsadmin','2021-12-15 11:45:04','logout','75'),(41,'userlogin','spsadmin','2021-12-15 11:45:06','logout','74'),(42,'userlogin','spsadmin','2021-12-15 11:45:07','logout','73'),(43,'userlogin','spsadmin','2021-12-15 11:45:09','logout','72'),(44,'userlogin','spsadmin','2021-12-15 11:45:10','logout','71'),(45,'userlogin','spsadmin','2021-12-15 11:45:11','logout','69'),(46,'userlogin','spsadmin','2021-12-15 11:45:14','logout','68'),(47,'userlogin','spsadmin','2021-12-15 11:45:15','logout','67'),(48,'userlogin','spsadmin','2021-12-15 11:45:18','logout','66'),(49,'userlogin','spsadmin','2021-12-15 11:45:20','logout','65'),(50,'userlogin','spsadmin','2021-12-15 11:45:22','logout','64'),(51,'userlogin','spsadmin','2021-12-15 11:45:23','logout','63'),(52,'userlogin','spsadmin','2021-12-15 11:45:26','logout','62'),(53,'userlogin','spsadmin','2021-12-15 11:45:28','logout','61'),(54,'userlogin','spsadmin','2021-12-15 11:45:30','logout','60'),(55,'userlogin','spsadmin','2021-12-15 11:45:31','logout','59'),(56,'userlogin','spsadmin','2021-12-15 11:45:33','logout','58'),(57,'userlogin','spsadmin','2021-12-15 11:45:35','logout','57'),(58,'userlogin','spsadmin','2021-12-15 11:45:36','logout','56'),(59,'userlogin','spsadmin','2021-12-15 11:45:37','logout','55'),(60,'userlogin','spsadmin','2021-12-15 11:45:39','logout','54'),(61,'userlogin','spsadmin','2021-12-15 11:45:40','logout','53'),(62,'userlogin','spsadmin','2021-12-15 11:45:42','logout','52'),(63,'userlogin','spsadmin','2021-12-15 11:45:43','logout','51'),(64,'userlogin','spsadmin','2021-12-15 11:45:45','logout','50'),(65,'userlogin','spsadmin','2021-12-15 11:45:46','logout','49'),(66,'userlogin','spsadmin','2021-12-15 11:45:49','logout','48'),(67,'userlogin','spsadmin','2021-12-15 11:45:50','logout','47'),(68,'userlogin','spsadmin','2021-12-15 11:45:53','logout','46'),(69,'userlogin','spsadmin','2021-12-15 11:45:55','logout','45'),(70,'userlogin','spsadmin','2021-12-15 11:45:56','logout','44'),(71,'userlogin','spsadmin','2021-12-15 11:45:58','logout','43'),(72,'userlogin','spsadmin','2021-12-15 11:45:59','logout','41'),(73,'userlogin','spsadmin','2021-12-15 11:46:00','logout','40'),(74,'userlogin','spsadmin','2021-12-15 11:46:01','logout','39'),(75,'userlogin','spsadmin','2021-12-15 11:46:03','logout','38'),(76,'userlogin','spsadmin','2021-12-15 11:46:05','logout','37'),(77,'userlogin','spsadmin','2021-12-15 11:46:06','logout','36'),(78,'userlogin','spsadmin','2021-12-15 11:46:07','logout','34'),(79,'userlogin','spsadmin','2021-12-15 11:46:08','logout','33'),(80,'userlogin','spsadmin','2021-12-15 11:46:09','logout','32'),(81,'userlogin','spsadmin','2021-12-15 11:46:11','logout','31'),(82,'userlogin','spsadmin','2021-12-15 11:46:12','logout','30'),(83,'userlogin','spsadmin','2021-12-15 11:46:13','logout','29'),(84,'userlogin','spsadmin','2021-12-15 11:46:14','logout','28'),(85,'userlogin','spsadmin','2021-12-15 11:46:15','logout','27'),(86,'userlogin','spsadmin','2021-12-15 11:46:17','logout','26'),(87,'userlogin','spsadmin','2021-12-15 11:46:18','logout','25'),(88,'userlogin','spsadmin','2021-12-15 11:46:20','logout','24'),(89,'userlogin','spsadmin','2021-12-15 11:46:21','logout','23'),(90,'userlogin','spsadmin','2021-12-15 11:46:23','logout','22'),(91,'userlogin','spsadmin','2021-12-15 11:46:24','logout','21'),(92,'userlogin','spsadmin','2021-12-15 11:46:40','logout','20'),(93,'userlogin','spsadmin','2021-12-15 11:46:41','logout','19'),(94,'userlogin','spsadmin','2021-12-15 11:46:42','logout','18'),(95,'userlogin','spsadmin','2021-12-15 11:46:44','logout','17'),(96,'userlogin','spsadmin','2021-12-15 11:46:45','logout','15'),(97,'userlogin','spsadmin','2021-12-15 11:46:46','logout','14'),(98,'userlogin','spsadmin','2021-12-15 11:46:48','logout','13'),(99,'userlogin','spsadmin','2021-12-15 11:46:55','logout','3'),(100,'manageuseraccount','spsadmin','2022-01-14 09:45:15','unlock account','00004491'),(101,'constantdeptaccount','spsadmin','2022-05-20 13:16:34','edit constant dept','DEPTTYPE_CODE=> 24 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE =0 ALLOW_WITHDRAW_INSIDE =0 ALLOW_DEPOSIT_OUTSIDE =0 ALLOW_WITHDRAW_OUTSIDE =0 ALLOW_PAYLOAN =0 ALLOW_BUYSHARE =0 ALLOW_RECEIVE_LOAN =0 DEPTTYPE_CODE=> 01 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE=0 ALLOW_WITHDRAW_INSIDE=0 ALLOW_DEPOSIT_OUTSIDE=1 ALLOW_WITHDRAW_OUTSIDE=1 ALLOW_PAY_LOAN=0 ALLOW_BUYSHARE=0 ALLOW_RECEIVE_LOAN=0'),(102,'constantdeptaccount','spsadmin','2022-05-20 13:18:13','edit constant dept',' DEPTTYPE_CODE=> 01 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE=1 ALLOW_WITHDRAW_INSIDE=1 ALLOW_DEPOSIT_OUTSIDE=1 ALLOW_WITHDRAW_OUTSIDE=1 ALLOW_PAY_LOAN=0 ALLOW_BUYSHARE=0 ALLOW_RECEIVE_LOAN=0'),(103,'constantdeptaccount','spsadmin','2022-05-20 13:19:11','edit constant dept',' DEPTTYPE_CODE=> 01 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE=0 ALLOW_WITHDRAW_INSIDE=0 ALLOW_DEPOSIT_OUTSIDE=0 ALLOW_WITHDRAW_OUTSIDE=0 ALLOW_PAY_LOAN=0 ALLOW_BUYSHARE=0 ALLOW_RECEIVE_LOAN=0'),(104,'constantdeptaccount','spsadmin','2022-06-01 15:41:55','edit constant dept',' DEPTTYPE_CODE=> 01 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE=1 ALLOW_WITHDRAW_INSIDE=1 ALLOW_DEPOSIT_OUTSIDE=1 ALLOW_WITHDRAW_OUTSIDE=1 ALLOW_PAY_LOAN=0 ALLOW_BUYSHARE=0 ALLOW_RECEIVE_LOAN=0'),(105,'constantdeptaccount','spsadmin','2022-06-01 15:42:05','edit constant dept',' DEPTTYPE_CODE=> 14 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE=1 ALLOW_WITHDRAW_INSIDE=1 ALLOW_DEPOSIT_OUTSIDE=1 ALLOW_WITHDRAW_OUTSIDE=1 ALLOW_PAY_LOAN=0 ALLOW_BUYSHARE=0 ALLOW_RECEIVE_LOAN=0'),(106,'constantdeptaccount','spsadmin','2022-06-01 15:42:59','edit constant dept',' DEPTTYPE_CODE=> 14 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE=0 ALLOW_WITHDRAW_INSIDE=0 ALLOW_DEPOSIT_OUTSIDE=0 ALLOW_WITHDRAW_OUTSIDE=0 ALLOW_PAY_LOAN=0 ALLOW_BUYSHARE=0 ALLOW_RECEIVE_LOAN=0'),(107,'constantdeptaccount','spsadmin','2022-06-01 15:43:06','edit constant dept',' DEPTTYPE_CODE=> 01 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE=0 ALLOW_WITHDRAW_INSIDE=0 ALLOW_DEPOSIT_OUTSIDE=0 ALLOW_WITHDRAW_OUTSIDE=0 ALLOW_PAY_LOAN=0 ALLOW_BUYSHARE=0 ALLOW_RECEIVE_LOAN=0'),(108,'constantdeptaccount','spsadmin','2022-06-01 15:48:58','edit constant dept',' DEPTTYPE_CODE=> 00 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE=0 ALLOW_WITHDRAW_INSIDE=0 ALLOW_DEPOSIT_OUTSIDE=1 ALLOW_WITHDRAW_OUTSIDE=1 ALLOW_PAY_LOAN=0 ALLOW_BUYSHARE=0 ALLOW_RECEIVE_LOAN=0'),(109,'constantdeptaccount','spsadmin','2022-06-01 15:49:15','edit constant dept',' DEPTTYPE_CODE=> 00 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE=1 ALLOW_WITHDRAW_INSIDE=1 ALLOW_DEPOSIT_OUTSIDE=0 ALLOW_WITHDRAW_OUTSIDE=0 ALLOW_PAY_LOAN=0 ALLOW_BUYSHARE=0 ALLOW_RECEIVE_LOAN=0'),(110,'constantdeptaccount','spsadmin','2022-06-01 15:49:25','edit constant dept',' DEPTTYPE_CODE=> 00 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE=1 ALLOW_WITHDRAW_INSIDE=1 ALLOW_DEPOSIT_OUTSIDE=1 ALLOW_WITHDRAW_OUTSIDE=1 ALLOW_PAY_LOAN=0 ALLOW_BUYSHARE=0 ALLOW_RECEIVE_LOAN=0'),(111,'constantdeptaccount','spsadmin','2022-07-05 15:21:38','edit constant dept',' DEPTTYPE_CODE=> 14 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE=0 ALLOW_WITHDRAW_INSIDE=0 ALLOW_DEPOSIT_OUTSIDE=1 ALLOW_WITHDRAW_OUTSIDE=1 ALLOW_PAY_LOAN=0 ALLOW_BUYSHARE=0 ALLOW_RECEIVE_LOAN=0'),(112,'constantdeptaccount','spsadmin','2022-07-05 15:22:28','edit constant dept',' DEPTTYPE_CODE=> 14 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE=1 ALLOW_WITHDRAW_INSIDE=1 ALLOW_DEPOSIT_OUTSIDE=1 ALLOW_WITHDRAW_OUTSIDE=1 ALLOW_PAY_LOAN=0 ALLOW_BUYSHARE=0 ALLOW_RECEIVE_LOAN=0'),(113,'constantdeptaccount','spsadmin','2022-07-06 11:13:59','edit constant dept',' DEPTTYPE_CODE=> 01 MEMBER_TYPE_CODE =AL ALLOW_DEPOSIT_INSIDE=1 ALLOW_WITHDRAW_INSIDE=1 ALLOW_DEPOSIT_OUTSIDE=1 ALLOW_WITHDRAW_OUTSIDE=1 ALLOW_PAY_LOAN=0 ALLOW_BUYSHARE=0 ALLOW_RECEIVE_LOAN=0');
/*!40000 ALTER TABLE `logeditmobileadmin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logerrorusageapplication`
--

DROP TABLE IF EXISTS `logerrorusageapplication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logerrorusageapplication` (
  `id_errorusage` int(10) NOT NULL AUTO_INCREMENT,
  `error_menu` varchar(100) NOT NULL,
  `error_code` char(6) NOT NULL,
  `error_desc` text NOT NULL,
  `error_date` datetime NOT NULL DEFAULT current_timestamp(),
  `error_device` varchar(200) NOT NULL,
  PRIMARY KEY (`id_errorusage`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logerrorusageapplication`
--

LOCK TABLES `logerrorusageapplication` WRITE;
/*!40000 ALTER TABLE `logerrorusageapplication` DISABLE KEYS */;
INSERT INTO `logerrorusageapplication` VALUES (1,'fetch_menu','WS0001','ไม่สามารถยืนยันข้อมูลได้\n{\"channel\":\"mobile_app\",\"platform\":\"android\",\"device_name\":\"google sdk_gphone_x86_64_arm64\",\"app_version\":\"0.1.0\",\"unique_id\":\"f83464273c83dea1\",\"ip_address\":\"180.183.231.39\",\"api_token\":\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjaGFubmVsIjoibW9iaWxlX2FwcCIsInJlc291cmNlX2FwcF9pZCI6ImNvbS5zcHNzYXZpbmcubW9iaWxlIiwiZGV2aWNlX25hbWUiOiJnb29nbGUgc2RrX2dwaG9uZV94ODZfNjRfYXJtNjQiLCJpcF9hZGRyZXNzIjoiMTgwLjE4My4yMzEuMzkiLCJleHAiOjE2MzQyNzM0OTl9.KezRM2HpgpxBBgDsl8AXYOgNWV9ECzGN8LVu33HfY8c\",\"menu_parent\":\"-1\"}','2021-10-15 11:38:01','mobile_app - f83464273c83dea1 on V.0.1.0'),(2,'fetch_menu','WS0001','ไม่สามารถยืนยันข้อมูลได้\n{\"channel\":\"mobile_app\",\"platform\":\"android\",\"device_name\":\"google sdk_gphone_x86_64_arm64\",\"app_version\":\"0.1.0\",\"unique_id\":\"f83464273c83dea1\",\"ip_address\":\"180.183.231.39\",\"api_token\":\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjaGFubmVsIjoibW9iaWxlX2FwcCIsInJlc291cmNlX2FwcF9pZCI6ImNvbS5zcHNzYXZpbmcubW9iaWxlIiwiZGV2aWNlX25hbWUiOiJnb29nbGUgc2RrX2dwaG9uZV94ODZfNjRfYXJtNjQiLCJpcF9hZGRyZXNzIjoiMTgwLjE4My4yMzEuMzkiLCJleHAiOjE2MzQyNzM1MjR9.E8X8R1wZ_DDok1wPrfx2n0HpvGAyzfJUSp7wj5ucU_U\",\"menu_parent\":\"-1\"}','2021-10-15 11:38:01','mobile_app - f83464273c83dea1 on V.0.1.0'),(3,'fetch_menu','WS0001','ไม่สามารถยืนยันข้อมูลได้\n{\"channel\":\"mobile_app\",\"platform\":\"android\",\"device_name\":\"google sdk_gphone_x86_64_arm64\",\"app_version\":\"0.1.0\",\"unique_id\":\"f83464273c83dea1\",\"ip_address\":\"180.183.231.39\",\"api_token\":\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjaGFubmVsIjoibW9iaWxlX2FwcCIsInJlc291cmNlX2FwcF9pZCI6ImNvbS5zcHNzYXZpbmcubW9iaWxlIiwiZGV2aWNlX25hbWUiOiJnb29nbGUgc2RrX2dwaG9uZV94ODZfNjRfYXJtNjQiLCJpcF9hZGRyZXNzIjoiMTgwLjE4My4yMzEuMzkiLCJleHAiOjE2MzQyNzM1MTh9.pSlCDQc0ZzMuL-RI2B8NzJcRapOq0B3-jyqpzawjZGk\",\"menu_parent\":\"-1\"}','2021-10-15 11:38:01','mobile_app - f83464273c83dea1 on V.0.1.0'),(4,'check_login_and_insert_userlog','WS4004','ส่ง Argument มาไม่ครบ \n{\"channel\":\"mobile_app\",\"platform\":\"android\",\"device_name\":\"HUAWEI WLZ-AL10\",\"app_version\":\"1.0.0\",\"unique_id\":\"afa1c790ca4c195d\",\"ip_address\":\"219.143.5.75\",\"api_token\":\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjaGFubmVsIjoibW9iaWxlX2FwcCIsInJlc291cmNlX2FwcF9pZCI6ImNvbS5zcHNzYXZpbmcubW9iaWxlIiwiZGV2aWNlX25hbWUiOiJIVUFXRUkgV0xaLUFMMTAiLCJpcF9hZGRyZXNzIjoiMjE5LjE0My41Ljc1IiwiZXhwIjoxNjM4OTU2MDg0fQ.B7pp-_d-vOe60diI8R9o9xKozxpXIrJJPT5ViRgjYsQ\",\"fcm_token\":\"\",\"hms_token\":\"IQAAAACy0m-iAABwydUAnpb-hL90wKtS9By3-7oM2ZBYgRecMI07BD3hpAh5tzyMQVqY87tRXFap594rRqlR6Nn6vtKu0GkBytMqFTDejIVJRUni9w\",\"is_root\":\"1\",\"member_no\":\"\",\"password\":\"#\",\"card_person\":\"\",\"auto_login\":\"\"}','2021-12-08 16:18:54','mobile_app - afa1c790ca4c195d on V.1.0.0'),(5,'check_login_and_insert_userlog','WS4004','ส่ง Argument มาไม่ครบ \n{\"channel\":\"mobile_app\",\"platform\":\"android\",\"device_name\":\"HUAWEI WLZ-AL10\",\"app_version\":\"1.0.0\",\"unique_id\":\"afa1c790ca4c195d\",\"ip_address\":\"219.143.5.75\",\"api_token\":\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjaGFubmVsIjoibW9iaWxlX2FwcCIsInJlc291cmNlX2FwcF9pZCI6ImNvbS5zcHNzYXZpbmcubW9iaWxlIiwiZGV2aWNlX25hbWUiOiJIVUFXRUkgV0xaLUFMMTAiLCJpcF9hZGRyZXNzIjoiMjE5LjE0My41Ljc1IiwiZXhwIjoxNjM4OTU2OTY0fQ.ATsQPCP5TpcuE1h1ivX6jSvbWwCmtMjOpWd5T7MPf-Q\",\"fcm_token\":\"\",\"hms_token\":\"IQAAAACy0m-iAABwydUAnpb-hL90wKtS9By3-7oM2ZBYgRecMI07BD3hpAh5tzyMQVqY87tRXFap594rRqlR6Nn6vtKu0GkBytMqFTDejIVJRUni9w\",\"is_root\":\"1\",\"member_no\":\"\",\"password\":\"#\",\"card_person\":\"\",\"auto_login\":\"\"}','2021-12-08 16:33:35','mobile_app - afa1c790ca4c195d on V.1.0.0'),(6,'check_login_and_insert_userlog','WS4004','ส่ง Argument มาไม่ครบ \n{\"channel\":\"mobile_app\",\"platform\":\"android\",\"device_name\":\"HUAWEI WLZ-AL10\",\"app_version\":\"1.0.0\",\"unique_id\":\"afa1c790ca4c195d\",\"ip_address\":\"219.143.5.75\",\"api_token\":\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjaGFubmVsIjoibW9iaWxlX2FwcCIsInJlc291cmNlX2FwcF9pZCI6ImNvbS5zcHNzYXZpbmcubW9iaWxlIiwiZGV2aWNlX25hbWUiOiJIVUFXRUkgV0xaLUFMMTAiLCJpcF9hZGRyZXNzIjoiMjE5LjE0My41Ljc1IiwiZXhwIjoxNjM4OTU3NTg0fQ.XxHWYLzJdld5DDE5mY_rIR7X5j627HrkeUK3I7Rs9Qs\",\"fcm_token\":\"\",\"hms_token\":\"IQAAAACy0m-iAABwydUAnpb-hL90wKtS9By3-7oM2ZBYgRecMI07BD3hpAh5tzyMQVqY87tRXFap594rRqlR6Nn6vtKu0GkBytMqFTDejIVJRUni9w\",\"is_root\":\"1\",\"member_no\":\"\",\"password\":\"#\",\"card_person\":\"\",\"auto_login\":\"\"}','2021-12-08 16:43:55','mobile_app - afa1c790ca4c195d on V.1.0.0'),(7,'fetch_menu','WS0001','ไม่สามารถยืนยันข้อมูลได้\n{\"channel\":\"mobile_app\",\"platform\":\"android\",\"device_name\":\"HUAWEI JNY-LX2\",\"app_version\":\"1.0.0\",\"refresh_token\":\"9e74c69b-ad3e-4df7-9443-18c071d669d8\",\"unique_id\":\"b0f841881f3872b4\",\"ip_address\":\"unknown\",\"api_token\":\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjaGFubmVsIjoibW9iaWxlX2FwcCIsInJlc291cmNlX2FwcF9pZCI6ImNvbS5zcHNzYXZpbmcubW9iaWxlIiwiZGV2aWNlX25hbWUiOiJIVUFXRUkgSk5ZLUxYMiIsImlwX2FkZHJlc3MiOiJ1bmtub3duIiwiZXhwIjoxNjM5MzY4OTI3fQ.Vm8pmJfYRp4tw3OVsPzjg0SmUVAa3SCf8b2QIllXWgc\",\"menu_parent\":\"-1\"}','2021-12-13 11:41:56','mobile_app - b0f841881f3872b4 on V.1.0.0'),(8,'send_otp','WS4004','ส่ง Argument มาไม่ครบ \n{\"channel\":\"mobile_app\",\"platform\":\"android\",\"device_name\":\"samsung SM-N986B\",\"app_version\":\"1.0.0\",\"unique_id\":\"8acf69b296d4ab7a\",\"ip_address\":\"182.232.77.172\",\"api_token\":\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjaGFubmVsIjoibW9iaWxlX2FwcCIsInJlc291cmNlX2FwcF9pZCI6ImNvbS5zcHNzYXZpbmcubW9iaWxlIiwiZGV2aWNlX25hbWUiOiJzYW1zdW5nIFNNLU45ODZCIiwiaXBfYWRkcmVzcyI6IjE4Mi4yMzIuNzcuMTcyIiwiZXhwIjoxNjQ2NzM0NDQwfQ.3PhPnkxp4mn_LHB07uV3CckoF6ELbNODdf2GVXK1m50\",\"menu_component\":\"AppRegister\",\"member_no\":\"00004491\",\"tel\":\"0634561953\"}','2022-03-08 16:57:51','mobile_app - 8acf69b296d4ab7a on V.1.0.0'),(9,'send_otp','WS4004','ส่ง Argument มาไม่ครบ \n{\"channel\":\"mobile_app\",\"platform\":\"android\",\"device_name\":\"samsung SM-N986B\",\"app_version\":\"1.0.0\",\"unique_id\":\"8acf69b296d4ab7a\",\"ip_address\":\"182.232.77.172\",\"api_token\":\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjaGFubmVsIjoibW9iaWxlX2FwcCIsInJlc291cmNlX2FwcF9pZCI6ImNvbS5zcHNzYXZpbmcubW9iaWxlIiwiZGV2aWNlX25hbWUiOiJzYW1zdW5nIFNNLU45ODZCIiwiaXBfYWRkcmVzcyI6IjE4Mi4yMzIuNzcuMTcyIiwiZXhwIjoxNjQ2NzM0NTI4fQ.257qZbWEk-qeGe7EcVKTIOp62mRRxXDdzc9RzxMzojc\",\"menu_component\":\"AppRegister\",\"member_no\":\"00004491\",\"tel\":\"0634561953\"}','2022-03-08 16:59:19','mobile_app - 8acf69b296d4ab7a on V.1.0.0');
/*!40000 ALTER TABLE `logerrorusageapplication` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loglockaccount`
--

DROP TABLE IF EXISTS `loglockaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loglockaccount` (
  `id_lockacc` int(11) NOT NULL AUTO_INCREMENT,
  `member_no` char(8) NOT NULL,
  `device_name` text NOT NULL,
  `unique_id` varchar(200) NOT NULL,
  `lock_date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_lockacc`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loglockaccount`
--

LOCK TABLES `loglockaccount` WRITE;
/*!40000 ALTER TABLE `loglockaccount` DISABLE KEYS */;
INSERT INTO `loglockaccount` VALUES (1,'00010732','HUAWEI JNY-LX2','b0f841881f3872b4','2021-12-13 16:33:11'),(2,'00000152','Apple iPhone 6s','7A96C3D6-52FF-4B0E-944E-6889C7677D9B','2021-12-15 11:56:58'),(3,'00004491','Firefox (96.0)','4FXvuiZVMq7ir2nS','2022-01-14 09:43:21');
/*!40000 ALTER TABLE `loglockaccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logreceiveloan`
--

DROP TABLE IF EXISTS `logreceiveloan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logreceiveloan` (
  `id_receiveloan` int(10) NOT NULL AUTO_INCREMENT,
  `member_no` varchar(8) NOT NULL,
  `request_amt` decimal(15,2) NOT NULL DEFAULT 0.00,
  `deptaccount_no` varchar(15) NOT NULL,
  `loancontract_no` varchar(20) NOT NULL,
  `request_date` datetime NOT NULL DEFAULT current_timestamp(),
  `status_flag` enum('0','1') NOT NULL,
  `response_code` varchar(6) DEFAULT NULL,
  `response_message` longtext DEFAULT NULL,
  `id_userlogin` mediumint(8) NOT NULL,
  PRIMARY KEY (`id_receiveloan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logreceiveloan`
--

LOCK TABLES `logreceiveloan` WRITE;
/*!40000 ALTER TABLE `logreceiveloan` DISABLE KEYS */;
/*!40000 ALTER TABLE `logreceiveloan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logrepayloan`
--

DROP TABLE IF EXISTS `logrepayloan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logrepayloan` (
  `id_repayloan` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_no` char(8) NOT NULL,
  `id_userlogin` mediumint(8) NOT NULL,
  `transaction_date` datetime NOT NULL DEFAULT current_timestamp(),
  `deptaccount_no` varchar(15) NOT NULL,
  `amt_transfer` decimal(15,2) NOT NULL,
  `penalty_amt` decimal(15,2) NOT NULL DEFAULT 0.00,
  `status_flag` enum('0','1') NOT NULL,
  `destination` varchar(15) DEFAULT NULL,
  `response_code` char(6) DEFAULT NULL,
  `response_message` longtext DEFAULT NULL,
  PRIMARY KEY (`id_repayloan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logrepayloan`
--

LOCK TABLES `logrepayloan` WRITE;
/*!40000 ALTER TABLE `logrepayloan` DISABLE KEYS */;
/*!40000 ALTER TABLE `logrepayloan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logtransferinsidecoop`
--

DROP TABLE IF EXISTS `logtransferinsidecoop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logtransferinsidecoop` (
  `id_transferinsidecoop` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_no` char(8) NOT NULL,
  `id_userlogin` mediumint(8) NOT NULL,
  `transaction_date` datetime NOT NULL DEFAULT current_timestamp(),
  `deptaccount_no` varchar(15) NOT NULL,
  `amt_transfer` decimal(15,2) NOT NULL,
  `penalty_amt` decimal(15,2) DEFAULT 0.00,
  `type_request` enum('1','2') NOT NULL,
  `transfer_flag` enum('1','2') NOT NULL,
  `destination` varchar(15) DEFAULT NULL,
  `response_code` char(6) DEFAULT NULL,
  `response_message` longtext DEFAULT NULL,
  PRIMARY KEY (`id_transferinsidecoop`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logtransferinsidecoop`
--

LOCK TABLES `logtransferinsidecoop` WRITE;
/*!40000 ALTER TABLE `logtransferinsidecoop` DISABLE KEYS */;
INSERT INTO `logtransferinsidecoop` VALUES (1,'etnmode3',5,'2021-09-27 10:56:56','0010224479',500.00,0.00,'2','1','0010126377','WS0064','insert for deposit ลงตาราง DPDEPTSLIP ไม่ได้INSERT INTO DPDEPTSLIP(DEPTSLIP_NO,COOP_ID,DEPTACCOUNT_NO,DEPTTYPE_CODE,   \r\n												deptcoop_id,DEPTGROUP_CODE,DEPTSLIP_DATE,RECPPAYTYPE_CODE,DEPTSLIP_AMT,CASH_TYPE,\r\n												PRNCBAL,WITHDRAWABLE_AMT,CHECKPEND_AMT,ENTRY_ID,ENTRY_DATE, \r\n												DPSTM_NO,DEPTITEMTYPE_CODE,CALINT_FROM,CALINT_TO,ITEM_STATUS,CLOSEDAY_STATUS,OTHER_AMT,\r\n												NOBOOK_FLAG,CHEQUE_SEND_FLAG,TOFROM_ACCID,PAYFEE_METH,REFER_SLIPNO,DUE_FLAG,DEPTAMT_OTHER,DEPTSLIP_NETAMT,\r\n												POSTTOVC_FLAG,TAX_AMT,INT_BFYEAR,ACCID_FLAG,SHOWFOR_DEPT,GENVC_FLAG,PEROID_DEPT,CHECKCLEAR_STATUS,   \r\n												TELLER_FLAG,OPERATE_TIME) \r\n												VALUES(?,?,?,?,?,?,CONVERT(VARCHAR(10),GETDATE(),20),?,?,?,?,?,?,\'MOBILE\',CONVERT(VARCHAR(10),?,20),?,?,\r\n												CONVERT(VARCHAR(10),?,20),CONVERT(VARCHAR(10),GETDATE(),20),1,0,?,0,0,?,2,?,0,0,\r\n												?,1,0,0,1,1,1,0,1,1,CONVERT(VARCHAR(19),?,20))[\"0016400006550\",\"075001\",\"0010126377\",\"01\",\"075001\",\"00\",\"DTX\",\"500\",null,\"109.62\",\"109.62\",\".00\",\"2021-09-27 10:56:56\",2042,\"DTX\",\"2020-12-31 00:00:00\",0,\"20104003\",\"0016400006549\",\"500\",\"2021-09-27 10:56:56\"]'),(2,'etnmode3',5,'2021-10-05 09:47:48','0010226846',500.00,0.00,'2','1','0010133036','WS0066','Insert DPDEPTSLIP ไม่ได้INSERT INTO DPDEPTSLIP(DEPTSLIP_NO,COOP_ID,DEPTACCOUNT_NO,DEPTTYPE_CODE,   \r\n								deptcoop_id,DEPTGROUP_CODE,MEMBCAT_CODE,DEPTSLIP_DATE,RECPPAYTYPE_CODE,DEPTSLIP_AMT,CASH_TYPE,\r\n								PRNCBAL,WITHDRAWABLE_AMT,CHECKPEND_AMT,ENTRY_ID,ENTRY_DATE, \r\n								DPSTM_NO,DEPTITEMTYPE_CODE,CALINT_FROM,CALINT_TO,ITEM_STATUS,OTHER_AMT,\r\n								NOBOOK_FLAG,CHEQUE_SEND_FLAG,TOFROM_ACCID,PAYFEE_METH,DUE_FLAG,DEPTAMT_OTHER,DEPTSLIP_NETAMT,\r\n								POSTTOVC_FLAG,TAX_AMT,INT_BFYEAR,ACCID_FLAG,GENVC_FLAG,PEROID_DEPT,CHECKCLEAR_STATUS,   \r\n								TELLER_FLAG,OPERATE_TIME) \r\n								VALUES(?,?,?,?,?,?,?,CONVERT(VARCHAR(10),GETDATE(),20),?,?,?,?,?,?,\'MOBILE\',CONVERT(VARCHAR(10),?,20),?,?,\r\n								CONVERT(VARCHAR(10),?,20),CONVERT(VARCHAR(10),GETDATE(),20),1,?,0,0,?,0,0,?,?,0,0,0,1,1,0,1,1,CONVERT(VARCHAR(19),?,20))\n[\"0016400006789\",\"075001\",\"0010226846\",\"02\",\"075001\",\"02\",\"10\",\"WTX\",\"500\",\"TRN\",\"13329.65\",\"13329.65\",\".00\",\"2021-10-05 09:47:48\",2011,\"WTX\",\"2021-08-31 00:00:00\",\"0\",\"20104001\",\"0\",\"500\",\"2021-10-05 09:47:48\"]'),(3,'etnmode3',11,'2021-10-06 10:36:14','0010226846',1000.00,0.00,'2','1','0010133036','WS0066','Insert DPDEPTSLIP ไม่ได้INSERT INTO DPDEPTSLIP(DEPTSLIP_NO,COOP_ID,DEPTACCOUNT_NO,DEPTTYPE_CODE,   \r\n								deptcoop_id,DEPTGROUP_CODE,MEMBCAT_CODE,DEPTSLIP_DATE,RECPPAYTYPE_CODE,DEPTSLIP_AMT,CASH_TYPE,\r\n								PRNCBAL,WITHDRAWABLE_AMT,CHECKPEND_AMT,ENTRY_ID,ENTRY_DATE, \r\n								DPSTM_NO,DEPTITEMTYPE_CODE,CALINT_FROM,CALINT_TO,ITEM_STATUS,OTHER_AMT,\r\n								NOBOOK_FLAG,CHEQUE_SEND_FLAG,TOFROM_ACCID,PAYFEE_METH,DUE_FLAG,DEPTAMT_OTHER,DEPTSLIP_NETAMT,\r\n								POSTTOVC_FLAG,TAX_AMT,INT_BFYEAR,ACCID_FLAG,GENVC_FLAG,PEROID_DEPT,CHECKCLEAR_STATUS,   \r\n								TELLER_FLAG,OPERATE_TIME) \r\n								VALUES(?,?,?,?,?,?,?,CONVERT(VARCHAR(10),GETDATE(),20),?,?,?,?,?,?,\'MOBILE\',CONVERT(VARCHAR(10),?,20),?,?,\r\n								CONVERT(VARCHAR(10),?,20),CONVERT(VARCHAR(10),GETDATE(),20),1,?,0,0,?,0,0,?,?,0,0,0,1,1,0,1,1,CONVERT(VARCHAR(19),?,20))\n[\"0016400006790\",\"075001\",\"0010226846\",\"02\",\"075001\",\"02\",\"10\",\"WTX\",\"1000\",\"TRN\",\"14780.06\",\"14780.06\",\".00\",\"2021-10-06 10:36:14\",2011,\"WTX\",\"2021-09-30 00:00:00\",\"0\",\"20104001\",\"0\",\"1000\",\"2021-10-06 10:36:14\"]'),(4,'etnmode3',11,'2021-10-06 10:36:48','0010226846',1000.00,0.00,'2','1','0010133036','WS0066','Insert DPDEPTSLIP ไม่ได้INSERT INTO DPDEPTSLIP(DEPTSLIP_NO,COOP_ID,DEPTACCOUNT_NO,DEPTTYPE_CODE,   \r\n								deptcoop_id,DEPTGROUP_CODE,MEMBCAT_CODE,DEPTSLIP_DATE,RECPPAYTYPE_CODE,DEPTSLIP_AMT,CASH_TYPE,\r\n								PRNCBAL,WITHDRAWABLE_AMT,CHECKPEND_AMT,ENTRY_ID,ENTRY_DATE, \r\n								DPSTM_NO,DEPTITEMTYPE_CODE,CALINT_FROM,CALINT_TO,ITEM_STATUS,OTHER_AMT,\r\n								NOBOOK_FLAG,CHEQUE_SEND_FLAG,TOFROM_ACCID,PAYFEE_METH,DUE_FLAG,DEPTAMT_OTHER,DEPTSLIP_NETAMT,\r\n								POSTTOVC_FLAG,TAX_AMT,INT_BFYEAR,ACCID_FLAG,GENVC_FLAG,PEROID_DEPT,CHECKCLEAR_STATUS,   \r\n								TELLER_FLAG,OPERATE_TIME) \r\n								VALUES(?,?,?,?,?,?,?,CONVERT(VARCHAR(10),GETDATE(),20),?,?,?,?,?,?,\'MOBILE\',CONVERT(VARCHAR(10),?,20),?,?,\r\n								CONVERT(VARCHAR(10),?,20),CONVERT(VARCHAR(10),GETDATE(),20),1,?,0,0,?,0,0,?,?,0,0,0,1,1,0,1,1,CONVERT(VARCHAR(19),?,20))\r\n[\"0016400006792\",\"075001\",\"0010226846\",\"02\",\"075001\",\"02\",\"10\",\"WTX\",\"1000\",\"TRN\",\"14780.06\",\"14780.06\",\".00\",\"2021-10-06 10:36:48\",2011,\"WTX\",\"2021-09-30 00:00:00\",\"0\",\"20104001\",\"0\",\"1000\",\"2021-10-06 10:36:48\"]'),(5,'etnmode3',11,'2021-10-06 10:37:18','0010226846',1000.00,0.00,'2','1','0010133036','WS0066','Insert DPDEPTSLIP ไม่ได้INSERT INTO DPDEPTSLIP(DEPTSLIP_NO,COOP_ID,DEPTACCOUNT_NO,DEPTTYPE_CODE,   \r\n								deptcoop_id,DEPTGROUP_CODE,MEMBCAT_CODE,DEPTSLIP_DATE,RECPPAYTYPE_CODE,DEPTSLIP_AMT,CASH_TYPE,\r\n								PRNCBAL,WITHDRAWABLE_AMT,CHECKPEND_AMT,ENTRY_ID,ENTRY_DATE, \r\n								DPSTM_NO,DEPTITEMTYPE_CODE,CALINT_FROM,CALINT_TO,ITEM_STATUS,OTHER_AMT,\r\n								NOBOOK_FLAG,CHEQUE_SEND_FLAG,TOFROM_ACCID,PAYFEE_METH,DUE_FLAG,DEPTAMT_OTHER,DEPTSLIP_NETAMT,\r\n								POSTTOVC_FLAG,TAX_AMT,INT_BFYEAR,ACCID_FLAG,GENVC_FLAG,PEROID_DEPT,CHECKCLEAR_STATUS,   \r\n								TELLER_FLAG,OPERATE_TIME) \r\n								VALUES(?,?,?,?,?,?,?,CONVERT(VARCHAR(10),GETDATE(),20),?,?,?,?,?,?,\'MOBILE\',CONVERT(VARCHAR(10),?,20),?,?,\r\n								CONVERT(VARCHAR(10),?,20),CONVERT(VARCHAR(10),GETDATE(),20),1,?,0,0,?,0,0,?,?,0,0,0,1,1,0,1,1,CONVERT(VARCHAR(19),?,20))\n[\"0016400006794\",\"075001\",\"0010226846\",\"02\",\"075001\",\"02\",\"10\",\"WTX\",\"1000\",\"TRN\",\"14780.06\",\"14780.06\",\".00\",\"2021-10-06 10:37:18\",2011,\"WTX\",\"2021-09-30 00:00:00\",\"0\",\"20104001\",\"0\",\"1000\",\"2021-10-06 10:37:18\"]'),(6,'etnmode3',11,'2021-10-06 10:37:53','0010226846',1000.00,0.00,'2','1','0010133036','WS0066','Insert DPDEPTSLIP ไม่ได้INSERT INTO DPDEPTSLIP(DEPTSLIP_NO,COOP_ID,DEPTACCOUNT_NO,DEPTTYPE_CODE,   \r\n								deptcoop_id,DEPTGROUP_CODE,MEMBCAT_CODE,DEPTSLIP_DATE,RECPPAYTYPE_CODE,DEPTSLIP_AMT,CASH_TYPE,\r\n								PRNCBAL,WITHDRAWABLE_AMT,CHECKPEND_AMT,ENTRY_ID,ENTRY_DATE, \r\n								DPSTM_NO,DEPTITEMTYPE_CODE,CALINT_FROM,CALINT_TO,ITEM_STATUS,OTHER_AMT,\r\n								NOBOOK_FLAG,CHEQUE_SEND_FLAG,TOFROM_ACCID,PAYFEE_METH,DUE_FLAG,DEPTAMT_OTHER,DEPTSLIP_NETAMT,\r\n								POSTTOVC_FLAG,TAX_AMT,INT_BFYEAR,ACCID_FLAG,GENVC_FLAG,PEROID_DEPT,CHECKCLEAR_STATUS,   \r\n								TELLER_FLAG,OPERATE_TIME) \r\n								VALUES(?,?,?,?,?,?,?,CONVERT(VARCHAR(10),GETDATE(),20),?,?,?,?,?,?,\'MOBILE\',CONVERT(VARCHAR(10),?,20),?,?,\r\n								CONVERT(VARCHAR(10),?,20),CONVERT(VARCHAR(10),GETDATE(),20),1,?,0,0,?,0,0,?,?,0,0,0,1,1,0,1,1,CONVERT(VARCHAR(19),?,20))\r\n[\"0016400006796\",\"075001\",\"0010226846\",\"02\",\"075001\",\"02\",\"10\",\"WTX\",\"1000\",\"TRN\",\"14780.06\",\"14780.06\",\".00\",\"2021-10-06 10:37:53\",2011,\"WTX\",\"2021-09-30 00:00:00\",\"0\",\"20104001\",\"0\",\"1000\",\"2021-10-06 10:37:53\"]'),(7,'etnmode3',11,'2021-10-06 10:41:53','0010226846',500.00,0.00,'2','1','0010133036','WS0066','Insert DPDEPTSLIP ไม่ได้INSERT INTO DPDEPTSLIP(DEPTSLIP_NO,COOP_ID,DEPTACCOUNT_NO,DEPTTYPE_CODE,   \r\n								deptcoop_id,DEPTGROUP_CODE,MEMBCAT_CODE,DEPTSLIP_DATE,RECPPAYTYPE_CODE,DEPTSLIP_AMT,CASH_TYPE,\r\n								PRNCBAL,WITHDRAWABLE_AMT,CHECKPEND_AMT,ENTRY_ID,ENTRY_DATE, \r\n								DPSTM_NO,DEPTITEMTYPE_CODE,CALINT_FROM,CALINT_TO,ITEM_STATUS,OTHER_AMT,\r\n								NOBOOK_FLAG,CHEQUE_SEND_FLAG,TOFROM_ACCID,PAYFEE_METH,DUE_FLAG,DEPTAMT_OTHER,DEPTSLIP_NETAMT,\r\n								POSTTOVC_FLAG,TAX_AMT,INT_BFYEAR,ACCID_FLAG,GENVC_FLAG,PEROID_DEPT,CHECKCLEAR_STATUS,   \r\n								TELLER_FLAG,OPERATE_TIME) \r\n								VALUES(?,?,?,?,?,?,?,CONVERT(VARCHAR(10),GETDATE(),20),?,?,?,?,?,?,\'MOBILE\',CONVERT(VARCHAR(10),?,20),?,?,\r\n								CONVERT(VARCHAR(10),?,20),CONVERT(VARCHAR(10),GETDATE(),20),1,?,0,0,?,0,0,?,?,0,0,0,1,1,0,1,1,CONVERT(VARCHAR(19),?,20))\r\n[\"0016400006798\",\"075001\",\"0010226846\",\"02\",\"075001\",\"02\",\"10\",\"WTX\",\"500\",\"TRN\",\"14780.06\",\"14780.06\",\".00\",\"2021-10-06 10:41:53\",2011,\"WTX\",\"2021-09-30 00:00:00\",\"0\",\"20104001\",\"0\",\"500\",\"2021-10-06 10:41:53\"]'),(8,'etnmode3',11,'2021-10-06 10:42:42','0010226846',500.00,0.00,'2','1','0010227325','WS0066','Insert DPDEPTSLIP ไม่ได้INSERT INTO DPDEPTSLIP(DEPTSLIP_NO,COOP_ID,DEPTACCOUNT_NO,DEPTTYPE_CODE,   \r\n								deptcoop_id,DEPTGROUP_CODE,MEMBCAT_CODE,DEPTSLIP_DATE,RECPPAYTYPE_CODE,DEPTSLIP_AMT,CASH_TYPE,\r\n								PRNCBAL,WITHDRAWABLE_AMT,CHECKPEND_AMT,ENTRY_ID,ENTRY_DATE, \r\n								DPSTM_NO,DEPTITEMTYPE_CODE,CALINT_FROM,CALINT_TO,ITEM_STATUS,OTHER_AMT,\r\n								NOBOOK_FLAG,CHEQUE_SEND_FLAG,TOFROM_ACCID,PAYFEE_METH,DUE_FLAG,DEPTAMT_OTHER,DEPTSLIP_NETAMT,\r\n								POSTTOVC_FLAG,TAX_AMT,INT_BFYEAR,ACCID_FLAG,GENVC_FLAG,PEROID_DEPT,CHECKCLEAR_STATUS,   \r\n								TELLER_FLAG,OPERATE_TIME) \r\n								VALUES(?,?,?,?,?,?,?,CONVERT(VARCHAR(10),GETDATE(),20),?,?,?,?,?,?,\'MOBILE\',CONVERT(VARCHAR(10),?,20),?,?,\r\n								CONVERT(VARCHAR(10),?,20),CONVERT(VARCHAR(10),GETDATE(),20),1,?,0,0,?,0,0,?,?,0,0,0,1,1,0,1,1,CONVERT(VARCHAR(19),?,20))\r\n[\"0016400006800\",\"075001\",\"0010226846\",\"02\",\"075001\",\"02\",\"10\",\"WTX\",\"500\",\"TRN\",\"14780.06\",\"14780.06\",\".00\",\"2021-10-06 10:42:42\",2011,\"WTX\",\"2021-09-30 00:00:00\",\"0\",\"20104003\",\"0\",\"500\",\"2021-10-06 10:42:42\"]');
/*!40000 ALTER TABLE `logtransferinsidecoop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logunbindaccount`
--

DROP TABLE IF EXISTS `logunbindaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logunbindaccount` (
  `id_logunbindaccount` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_no` char(8) NOT NULL,
  `id_userlogin` mediumint(8) NOT NULL,
  `unbind_status` enum('1','-9') NOT NULL,
  `attempt_unbind_date` datetime NOT NULL DEFAULT current_timestamp(),
  `response_code` char(6) DEFAULT NULL,
  `response_message` longtext DEFAULT NULL,
  `id_bindaccount` mediumint(8) DEFAULT NULL,
  `data_unbind_error` longtext DEFAULT NULL,
  `query_error` text DEFAULT NULL,
  `query_flag` enum('1','-9') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_logunbindaccount`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logunbindaccount`
--

LOCK TABLES `logunbindaccount` WRITE;
/*!40000 ALTER TABLE `logunbindaccount` DISABLE KEYS */;
INSERT INTO `logunbindaccount` VALUES (1,'00005367',59,'1','2022-05-19 16:02:51',NULL,NULL,11,NULL,NULL,'1'),(2,'00005367',59,'1','2022-05-24 14:34:09',NULL,NULL,12,NULL,NULL,'1'),(3,'00005367',59,'1','2022-05-25 14:02:57',NULL,NULL,13,NULL,NULL,'1'),(4,'00005367',59,'1','2022-05-25 14:05:00',NULL,NULL,14,NULL,NULL,'1'),(5,'00005367',59,'1','2022-07-07 15:29:09',NULL,NULL,15,NULL,NULL,'1');
/*!40000 ALTER TABLE `logunbindaccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loguseapplication`
--

DROP TABLE IF EXISTS `loguseapplication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loguseapplication` (
  `id_loguseapp` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_no` char(8) NOT NULL,
  `id_userlogin` mediumint(8) NOT NULL,
  `access_date` datetime NOT NULL DEFAULT current_timestamp(),
  `ip_address` varchar(15) NOT NULL,
  PRIMARY KEY (`id_loguseapp`)
) ENGINE=InnoDB AUTO_INCREMENT=536 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loguseapplication`
--

LOCK TABLES `loguseapplication` WRITE;
/*!40000 ALTER TABLE `loguseapplication` DISABLE KEYS */;
INSERT INTO `loguseapplication` VALUES (1,'etnmode4',1,'2021-10-15 13:36:16','180.183.231.39'),(2,'etnmode4',2,'2021-10-15 15:53:13','180.183.231.39'),(3,'etnmode4',2,'2021-10-15 15:54:13','180.183.231.39'),(4,'etnmode4',2,'2021-10-15 15:55:08','180.183.231.39'),(5,'etnmode4',2,'2021-10-15 15:56:15','180.183.231.39'),(6,'etnmode4',2,'2021-10-15 15:58:01','180.183.231.39'),(7,'etnmode4',2,'2021-10-15 15:59:14','180.183.231.39'),(8,'00004491',3,'2021-10-18 10:56:46','182.232.70.223'),(9,'00004491',3,'2021-10-18 11:02:17','182.232.70.223'),(10,'00004491',3,'2021-10-18 12:10:57','182.232.70.223'),(11,'00004491',3,'2021-10-18 17:08:15','182.232.70.223'),(12,'00004491',3,'2021-10-18 18:08:55','182.232.70.223'),(13,'00004491',3,'2021-11-03 14:26:53','49.230.177.253'),(14,'etnmode1',4,'2021-12-07 11:41:00','183.88.131.138'),(15,'etnmode1',5,'2021-12-07 15:48:11','183.88.131.138'),(16,'etnmode1',6,'2021-12-07 16:13:13','183.88.131.138'),(17,'etnmode1',7,'2021-12-07 16:15:21','183.88.131.138'),(18,'etnmode1',8,'2021-12-07 16:17:16','183.88.131.138'),(19,'etnmode1',9,'2021-12-08 09:48:01','183.88.131.138'),(20,'etnmode1',10,'2021-12-08 12:04:14','183.88.131.138'),(21,'etnmode1',10,'2021-12-08 12:48:13','183.88.131.138'),(22,'etnmode1',11,'2021-12-08 16:00:37','119.8.240.32'),(23,'etnmode1',12,'2021-12-08 16:01:03','119.8.240.31'),(24,'00005036',14,'2021-12-09 17:58:58','124.122.63.166'),(25,'00011144',15,'2021-12-09 18:05:16','182.232.78.22'),(26,'00005036',14,'2021-12-09 18:29:13','124.122.63.166'),(27,'00011144',15,'2021-12-09 18:37:55','182.232.78.22'),(28,'00011144',15,'2021-12-09 18:47:20','182.232.78.22'),(29,'00011144',15,'2021-12-09 19:36:30','182.232.84.87'),(30,'00011144',15,'2021-12-09 20:22:28','182.232.84.87'),(31,'00002747',16,'2021-12-09 21:24:00','171.97.112.229'),(32,'00002747',17,'2021-12-09 21:32:58','171.97.112.229'),(33,'00011144',15,'2021-12-09 23:54:35','182.232.84.227'),(34,'00004659',18,'2021-12-10 00:52:56','115.87.129.164'),(35,'00004659',18,'2021-12-10 01:18:41','115.87.129.164'),(36,'00004870',19,'2021-12-10 02:39:53','49.229.131.55'),(37,'00011144',15,'2021-12-10 02:45:37','182.232.84.227'),(38,'00011144',15,'2021-12-10 03:00:06','182.232.84.227'),(39,'00004532',20,'2021-12-10 03:01:53','1.46.149.15'),(40,'00004532',20,'2021-12-10 03:02:12','1.46.149.15'),(41,'00010261',21,'2021-12-10 03:06:25','27.55.67.131'),(42,'00011144',15,'2021-12-10 03:13:31','182.232.84.227'),(43,'00011144',15,'2021-12-10 03:24:17','182.232.84.227'),(44,'00004699',22,'2021-12-10 03:32:07','223.24.156.8'),(45,'00004532',20,'2021-12-10 04:29:19','unknown'),(46,'00002195',23,'2021-12-10 05:17:59','1.47.148.152'),(47,'00004146',24,'2021-12-10 07:00:35','182.232.69.242'),(48,'00004146',24,'2021-12-10 07:11:20','182.232.69.242'),(49,'00011013',25,'2021-12-10 07:47:59','1.47.0.2'),(50,'00011013',25,'2021-12-10 08:07:40','1.47.0.2'),(51,'00004870',19,'2021-12-10 08:20:40','49.230.238.103'),(52,'00002747',17,'2021-12-10 08:21:49','171.97.112.229'),(53,'00005036',14,'2021-12-10 08:38:28','124.122.63.166'),(54,'00002195',23,'2021-12-10 09:27:49','1.47.148.152'),(55,'00002195',23,'2021-12-10 09:46:03','1.47.148.152'),(56,'00004146',24,'2021-12-10 10:04:19','182.232.73.7'),(57,'00011013',25,'2021-12-10 12:47:08','1.47.0.2'),(58,'00009863',26,'2021-12-10 18:00:26','223.205.240.51'),(59,'00005036',14,'2021-12-10 18:18:23','171.5.133.101'),(60,'00004850',27,'2021-12-10 18:34:16','182.232.81.225'),(61,'00005249',28,'2021-12-10 18:49:21','182.232.79.55'),(62,'00005249',28,'2021-12-10 18:58:25','182.232.79.55'),(63,'00011014',29,'2021-12-10 19:49:51','182.232.66.6'),(64,'00010261',21,'2021-12-10 20:09:11','223.205.236.138'),(65,'00004870',19,'2021-12-10 22:24:09','49.230.224.75'),(66,'00005248',30,'2021-12-11 01:31:56','49.230.116.148'),(67,'00011000',31,'2021-12-11 02:37:42','124.122.15.148'),(68,'00011000',31,'2021-12-11 03:02:37','124.122.15.148'),(69,'00011013',25,'2021-12-11 08:11:39','1.47.132.115'),(70,'00011000',31,'2021-12-11 08:27:59','49.229.128.118'),(71,'00009863',26,'2021-12-11 08:40:46','171.97.73.184'),(72,'00010869',32,'2021-12-11 09:01:53','49.228.49.188'),(73,'00004485',33,'2021-12-11 10:27:08','1.46.5.80'),(74,'00004485',33,'2021-12-11 10:47:15','1.46.5.80'),(75,'00004146',24,'2021-12-11 11:41:59','49.230.44.50'),(76,'00004146',24,'2021-12-11 11:45:06','49.230.44.50'),(77,'00010496',34,'2021-12-11 12:27:51','124.122.15.148'),(78,'00010496',34,'2021-12-11 13:38:09','124.122.15.148'),(79,'00011014',29,'2021-12-11 13:41:54','182.232.66.33'),(80,'00010407',35,'2021-12-11 15:30:26','223.205.240.173'),(81,'00004870',19,'2021-12-11 15:55:37','49.230.230.249'),(82,'00010888',36,'2021-12-11 15:56:00','49.237.18.233'),(83,'00003308',37,'2021-12-11 15:57:47','49.237.19.241'),(84,'00004652',38,'2021-12-11 15:59:00','49.229.128.189'),(85,'00010872',39,'2021-12-11 16:12:40','1.47.133.12'),(86,'00010888',36,'2021-12-11 17:08:37','27.145.136.105'),(87,'00010826',40,'2021-12-11 17:16:06','49.237.22.103'),(88,'00009863',26,'2021-12-11 17:20:22','223.205.240.51'),(89,'00010719',41,'2021-12-11 17:55:11','49.228.48.151'),(90,'00011144',15,'2021-12-11 18:14:00','182.232.84.83'),(91,'00004189',42,'2021-12-11 18:43:11','1.47.128.132'),(92,'00004189',42,'2021-12-11 18:57:48','1.47.128.132'),(93,'00004189',43,'2021-12-11 19:05:33','49.230.119.156'),(94,'00004189',43,'2021-12-11 19:12:51','49.230.119.156'),(95,'00004146',24,'2021-12-11 19:39:25','49.228.49.174'),(96,'00004189',43,'2021-12-11 20:34:06','49.230.119.156'),(97,'00010523',44,'2021-12-11 21:44:25','49.231.4.10'),(98,'00004280',45,'2021-12-11 22:20:15','1.47.17.34'),(99,'00004280',45,'2021-12-11 22:23:52','1.47.17.34'),(100,'00011144',15,'2021-12-11 23:42:27','182.232.64.177'),(101,'00011144',15,'2021-12-11 23:48:26','182.232.64.177'),(102,'00005249',28,'2021-12-12 00:59:21','182.232.67.43'),(103,'00004652',38,'2021-12-12 01:03:23','49.230.118.13'),(104,'00011146',46,'2021-12-12 01:16:03','49.237.20.213'),(105,'00002747',17,'2021-12-12 05:21:27','124.122.17.65'),(106,'00003626',47,'2021-12-12 07:33:48','49.228.50.162'),(107,'00010523',44,'2021-12-12 07:54:07','49.231.4.10'),(108,'00009863',26,'2021-12-12 08:40:22','171.97.73.184'),(109,'00010888',36,'2021-12-12 08:41:15','27.145.136.105'),(110,'00011047',48,'2021-12-12 08:41:49','223.24.158.243'),(111,'00011047',48,'2021-12-12 08:42:20','223.24.158.243'),(112,'00003626',47,'2021-12-12 09:39:12','49.228.50.162'),(113,'00011018',50,'2021-12-12 11:30:46','182.232.71.105'),(114,'00003925',49,'2021-12-12 11:31:42','223.205.245.240'),(115,'00005133',51,'2021-12-12 11:45:19','1.46.16.235'),(116,'00004806',52,'2021-12-12 11:45:27','124.122.15.90'),(117,'00003700',53,'2021-12-12 11:57:55','49.228.9.171'),(118,'00002747',17,'2021-12-12 11:58:29','202.176.117.103'),(119,'00004806',52,'2021-12-12 11:58:31','124.122.15.90'),(120,'00003700',53,'2021-12-12 12:01:17','49.228.9.171'),(121,'00004806',52,'2021-12-12 12:32:33','124.122.15.90'),(122,'00004190',54,'2021-12-12 12:42:28','49.237.14.7'),(123,'00005152',55,'2021-12-12 13:12:13','1.47.4.103'),(124,'00010585',56,'2021-12-12 13:50:55','49.228.50.100'),(125,'00002747',17,'2021-12-12 13:52:50','202.176.117.103'),(126,'00003700',53,'2021-12-12 13:52:51','49.228.9.171'),(127,'00005036',14,'2021-12-12 14:32:02','49.231.4.10'),(128,'00010407',35,'2021-12-12 14:46:13','223.205.240.173'),(129,'00005152',55,'2021-12-12 14:46:25','1.47.4.103'),(130,'00010407',35,'2021-12-12 14:55:06','49.231.4.10'),(131,'00004135',57,'2021-12-12 15:15:11','1.47.154.130'),(132,'00011144',15,'2021-12-12 15:51:37','182.232.82.136'),(133,'00010844',58,'2021-12-12 16:43:48','1.46.147.120'),(134,'00010238',59,'2021-12-12 16:49:24','182.232.84.101'),(135,'00003700',53,'2021-12-12 17:07:51','1.47.155.47'),(136,'00010529',60,'2021-12-12 17:30:33','49.229.131.128'),(137,'00004596',61,'2021-12-12 17:32:20','27.55.74.151'),(138,'00004565',62,'2021-12-12 17:35:52','27.55.81.136'),(139,'00004861',63,'2021-12-12 18:00:23','1.47.25.226'),(140,'00004861',63,'2021-12-12 18:03:31','1.47.25.226'),(141,'00010938',64,'2021-12-12 18:05:13','182.232.76.250'),(142,'00004565',62,'2021-12-12 18:37:58','27.55.81.136'),(143,'00010990',65,'2021-12-12 18:51:41','1.47.143.226'),(144,'00011047',48,'2021-12-12 19:02:03','223.24.190.236'),(145,'00010407',35,'2021-12-12 19:28:21','49.231.4.10'),(146,'00005195',66,'2021-12-12 19:31:11','1.46.150.37'),(147,'00010732',67,'2021-12-12 19:42:37','49.231.4.10'),(148,'00010938',64,'2021-12-12 19:42:43','182.232.76.250'),(149,'00010732',67,'2021-12-12 19:43:38','49.231.4.10'),(150,'00010888',36,'2021-12-12 19:48:38','49.237.16.37'),(151,'00010722',68,'2021-12-12 19:50:51','49.230.116.76'),(152,'00004861',63,'2021-12-12 19:55:41','1.47.25.226'),(153,'00010693',69,'2021-12-12 20:01:11','49.231.4.10'),(154,'00004189',43,'2021-12-12 20:08:08','182.232.73.11'),(155,'00003925',49,'2021-12-12 20:19:16','223.205.236.103'),(156,'00010732',67,'2021-12-12 20:50:43','49.231.4.10'),(157,'00010805',70,'2021-12-12 20:54:44','27.55.79.23'),(158,'00005088',71,'2021-12-12 20:55:02','1.46.140.218'),(159,'00010693',69,'2021-12-12 20:56:47','49.231.4.10'),(160,'00004189',43,'2021-12-12 21:12:46','182.232.73.11'),(161,'00004189',43,'2021-12-12 21:18:58','182.232.73.11'),(162,'00011158',72,'2021-12-12 21:41:30','223.205.228.42'),(163,'00010529',60,'2021-12-12 22:23:35','182.232.73.26'),(164,'00009955',73,'2021-12-12 22:40:44','49.230.120.135'),(165,'00009955',73,'2021-12-12 22:42:18','49.230.120.135'),(166,'00009955',73,'2021-12-12 22:44:02','49.230.120.135'),(167,'00009955',73,'2021-12-12 22:52:46','49.230.120.135'),(168,'00009955',73,'2021-12-12 22:56:12','49.230.120.135'),(169,'00004077',74,'2021-12-12 23:04:58','223.205.245.40'),(170,'00005327',75,'2021-12-12 23:09:24','49.230.116.135'),(171,'00005327',75,'2021-12-12 23:15:29','49.230.116.135'),(172,'00010732',67,'2021-12-12 23:22:06','49.231.4.10'),(173,'00011047',48,'2021-12-12 23:22:29','27.55.71.177'),(174,'00005327',75,'2021-12-12 23:43:19','49.230.116.135'),(175,'00004659',18,'2021-12-13 00:11:55','27.55.81.41'),(176,'00011146',46,'2021-12-13 01:53:00','27.55.77.79'),(177,'00004596',61,'2021-12-13 03:46:14','223.24.164.176'),(178,'00009837',76,'2021-12-13 04:23:14','49.231.4.10'),(179,'00005289',77,'2021-12-13 06:47:28','171.5.130.238'),(180,'00009955',73,'2021-12-13 07:07:35','49.230.120.135'),(181,'00004594',78,'2021-12-13 08:14:14','182.232.79.152'),(182,'00010523',44,'2021-12-13 08:18:51','49.231.4.10'),(183,'00004594',78,'2021-12-13 08:22:19','182.232.79.152'),(184,'00010309',79,'2021-12-13 08:22:51','49.229.131.72'),(185,'00010529',60,'2021-12-13 08:33:02','49.229.129.47'),(186,'00004146',24,'2021-12-13 08:57:58','14.207.178.181'),(187,'00000152',80,'2021-12-13 09:01:29','182.232.72.22'),(188,'00005036',14,'2021-12-13 09:07:54','49.231.4.10'),(189,'00011156',81,'2021-12-13 09:21:01','1.47.137.12'),(190,'00010520',82,'2021-12-13 09:23:46','49.231.4.10'),(191,'00011142',83,'2021-12-13 09:26:57','49.231.4.10'),(192,'00011156',81,'2021-12-13 09:28:00','1.47.137.12'),(193,'00010952',84,'2021-12-13 09:30:18','49.231.4.10'),(194,'00009602',85,'2021-12-13 09:42:00','49.229.128.0'),(195,'00004189',43,'2021-12-13 09:46:28','182.232.73.11'),(196,'00004659',18,'2021-12-13 09:47:53','27.55.81.41'),(197,'00005152',55,'2021-12-13 09:48:38','1.47.4.103'),(198,'00010408',86,'2021-12-13 09:55:09','1.46.23.123'),(199,'00009837',76,'2021-12-13 10:02:14','49.228.10.206'),(200,'00009925',87,'2021-12-13 10:02:40','1.46.136.100'),(201,'00010888',36,'2021-12-13 10:05:25','27.145.136.105'),(202,'00004189',43,'2021-12-13 10:28:28','182.232.73.11'),(203,'00005327',75,'2021-12-13 10:29:48','182.232.77.94'),(204,'00005327',75,'2021-12-13 10:30:34','182.232.77.94'),(205,'00010238',59,'2021-12-13 10:33:07','49.229.131.8'),(206,'00010826',40,'2021-12-13 10:33:15','27.55.73.109'),(207,'00010920',88,'2021-12-13 10:33:52','49.228.10.114'),(208,'00005327',75,'2021-12-13 10:34:45','182.232.77.94'),(209,'00005223',89,'2021-12-13 10:36:57','182.232.84.213'),(210,'00004383',90,'2021-12-13 10:37:42','223.24.93.65'),(211,'00003287',91,'2021-12-13 10:37:44','1.46.158.125'),(212,'00005223',89,'2021-12-13 10:38:15','182.232.84.213'),(213,'00005005',92,'2021-12-13 10:39:23','1.46.24.200'),(214,'00003287',91,'2021-12-13 10:40:43','1.46.158.125'),(215,'00010523',44,'2021-12-13 10:41:19','49.231.4.10'),(216,'00010496',34,'2021-12-13 10:42:00','1.46.11.86'),(217,'00010826',40,'2021-12-13 10:42:05','27.55.73.109'),(218,'00010529',60,'2021-12-13 10:45:32','49.229.130.9'),(219,'00004783',93,'2021-12-13 10:47:52','27.55.69.126'),(220,'00003626',47,'2021-12-13 10:48:20','182.232.83.243'),(221,'00010309',79,'2021-12-13 10:54:51','124.122.15.156'),(222,'00011048',94,'2021-12-13 10:55:03','49.237.22.67'),(223,'00005169',95,'2021-12-13 10:56:28','1.46.28.158'),(224,'00011048',94,'2021-12-13 10:57:40','49.237.22.67'),(225,'00011156',81,'2021-12-13 11:01:42','1.47.137.12'),(226,'00004686',96,'2021-12-13 11:05:34','182.232.74.207'),(227,'00005169',95,'2021-12-13 11:12:35','1.46.28.158'),(228,'00004120',97,'2021-12-13 11:22:34','1.47.136.123'),(229,'00011144',15,'2021-12-13 11:25:12','182.232.70.156'),(230,'00010407',35,'2021-12-13 11:38:10','49.231.4.10'),(231,'00011048',94,'2021-12-13 11:45:03','49.237.22.67'),(232,'00003308',37,'2021-12-13 12:59:47','27.55.92.196'),(233,'00010496',34,'2021-12-13 13:10:04','1.46.11.86'),(234,'00009955',73,'2021-12-13 13:29:09','49.230.120.135'),(235,'00009955',73,'2021-12-13 13:30:06','49.230.120.135'),(236,'00002747',17,'2021-12-13 13:36:00','223.24.154.51'),(237,'00010407',35,'2021-12-13 14:19:33','49.231.4.10'),(238,'00005195',66,'2021-12-13 14:38:05','1.47.6.122'),(239,'00010990',65,'2021-12-13 14:38:15','223.205.238.36'),(240,'00010496',34,'2021-12-13 14:38:25','1.46.11.86'),(241,'00010920',88,'2021-12-13 14:42:47','27.55.83.76'),(242,'00005133',51,'2021-12-13 14:44:41','1.46.8.90'),(243,'00004565',62,'2021-12-13 14:46:36','49.228.50.206'),(244,'00010990',65,'2021-12-13 14:47:30','223.205.238.36'),(245,'00005289',77,'2021-12-13 14:49:50','49.230.119.135'),(246,'00002489',98,'2021-12-13 14:52:58','223.205.225.241'),(247,'00002489',98,'2021-12-13 14:53:38','223.205.225.241'),(248,'00002489',98,'2021-12-13 14:55:42','223.205.225.241'),(249,'00002489',98,'2021-12-13 15:02:28','223.205.225.241'),(250,'00011014',29,'2021-12-13 15:02:58','49.230.117.118'),(251,'00004434',99,'2021-12-13 15:09:18','223.205.225.241'),(252,'00002489',98,'2021-12-13 15:14:18','223.205.225.241'),(253,'00002489',98,'2021-12-13 15:19:40','223.205.225.241'),(254,'00004189',43,'2021-12-13 15:32:48','182.232.73.11'),(255,'00004652',38,'2021-12-13 15:49:17','182.232.66.246'),(256,'00005327',75,'2021-12-13 15:52:50','182.232.77.122'),(257,'00002747',17,'2021-12-13 15:55:53','223.24.154.51'),(258,'00005248',30,'2021-12-13 15:59:21','182.232.80.18'),(259,'00002489',98,'2021-12-13 16:04:00','124.122.63.232'),(260,'00004190',54,'2021-12-13 16:05:42','223.24.62.105'),(261,'00010805',70,'2021-12-13 16:31:45','27.55.74.173'),(262,'00010805',70,'2021-12-13 16:38:49','27.55.74.173'),(263,'00010805',100,'2021-12-13 16:41:14','27.55.74.173'),(264,'00010407',35,'2021-12-13 16:48:07','49.231.4.10'),(265,'00009955',73,'2021-12-13 17:42:55','49.230.121.211'),(266,'00011144',15,'2021-12-13 18:10:50','182.232.80.162'),(267,'00011144',15,'2021-12-13 18:31:04','182.232.80.162'),(268,'00002489',98,'2021-12-13 18:48:37','124.122.63.232'),(269,'00002489',98,'2021-12-13 18:56:55','124.122.63.232'),(270,'00002489',98,'2021-12-13 18:57:17','124.122.63.232'),(271,'00009796',101,'2021-12-13 19:33:19','49.237.32.8'),(272,'00009796',101,'2021-12-13 19:36:50','49.237.32.8'),(273,'00009796',101,'2021-12-13 19:38:32','49.237.32.8'),(274,'00011156',81,'2021-12-13 20:00:13','1.47.145.151'),(275,'00009796',101,'2021-12-13 20:02:16','49.237.32.8'),(276,'00002489',98,'2021-12-13 20:19:33','124.122.63.232'),(277,'00003700',53,'2021-12-13 20:44:53','49.228.50.223'),(278,'00005036',14,'2021-12-13 20:52:40','223.204.18.20'),(279,'00004783',93,'2021-12-13 21:25:51','171.96.158.4'),(280,'00011048',94,'2021-12-14 00:00:09','27.55.81.28'),(281,'00010872',39,'2021-12-14 00:02:22','1.47.133.12'),(282,'00002489',98,'2021-12-14 01:15:25','171.96.156.37'),(283,'00002489',98,'2021-12-14 01:19:33','171.96.156.37'),(284,'00002489',98,'2021-12-14 02:03:38','171.96.156.37'),(285,'00002489',98,'2021-12-14 02:10:44','171.96.156.37'),(286,'00002489',98,'2021-12-14 02:19:20','171.96.156.37'),(287,'00010722',68,'2021-12-14 02:35:57','49.229.131.164'),(288,'00002489',98,'2021-12-14 02:36:20','171.96.156.37'),(289,'00004998',102,'2021-12-14 02:44:24','49.231.4.10'),(290,'00002489',98,'2021-12-14 03:00:07','171.96.156.37'),(291,'00002489',98,'2021-12-14 03:05:18','171.96.156.37'),(292,'00004998',102,'2021-12-14 03:22:03','27.55.66.172'),(293,'00002489',98,'2021-12-14 03:39:30','171.96.156.37'),(294,'00002489',98,'2021-12-14 04:27:26','171.96.156.37'),(295,'00004870',19,'2021-12-14 05:18:08','49.229.130.79'),(296,'00005013',103,'2021-12-14 06:23:09','27.55.94.104'),(297,'00009955',73,'2021-12-14 06:25:58','49.230.119.126'),(298,'00009796',101,'2021-12-14 06:59:44','223.205.224.185'),(299,'00005248',30,'2021-12-14 08:24:28','182.232.80.223'),(300,'00004870',19,'2021-12-14 08:32:48','182.232.64.115'),(301,'00009925',87,'2021-12-14 08:45:21','49.228.51.168'),(302,'00011144',15,'2021-12-14 08:57:34','182.232.71.232'),(303,'00010407',35,'2021-12-14 09:19:00','49.231.4.10'),(304,'00011048',94,'2021-12-14 09:33:38','27.55.80.116'),(305,'00005013',103,'2021-12-14 10:01:44','27.145.208.86'),(306,'00005195',66,'2021-12-14 10:26:21','1.47.158.204'),(307,'00011000',31,'2021-12-14 10:34:39','182.232.72.182'),(308,'00004652',38,'2021-12-14 10:35:09','49.229.131.163'),(309,'00003700',53,'2021-12-14 11:01:33','49.228.10.176'),(310,'00005036',14,'2021-12-14 11:07:10','223.204.18.20'),(311,'00011144',15,'2021-12-14 11:19:06','49.230.117.2'),(312,'00011144',15,'2021-12-14 11:21:17','49.230.117.2'),(313,'00011144',15,'2021-12-14 11:23:09','49.230.117.2'),(314,'00011144',15,'2021-12-14 11:24:58','49.230.117.2'),(315,'00009796',101,'2021-12-14 12:24:58','49.237.9.210'),(316,'00004659',18,'2021-12-14 12:56:50','49.237.22.150'),(317,'00011156',81,'2021-12-14 12:57:00','1.47.140.156'),(318,'00010407',35,'2021-12-14 13:39:17','49.231.4.10'),(319,'00010407',104,'2021-12-14 13:53:03','1.46.14.130'),(320,'00010407',104,'2021-12-14 13:56:46','1.46.14.130'),(321,'00010407',104,'2021-12-14 14:02:04','1.46.14.130'),(322,'00004485',33,'2021-12-14 14:19:38','1.46.5.36'),(323,'00002852',105,'2021-12-14 14:27:16','49.231.4.10'),(324,'00002852',105,'2021-12-14 14:29:52','49.231.4.10'),(325,'00010844',58,'2021-12-14 14:57:12','1.46.147.120'),(326,'00004135',57,'2021-12-14 15:11:44','49.231.4.10'),(327,'00011014',29,'2021-12-14 15:25:37','49.230.116.161'),(328,'00004135',57,'2021-12-14 16:07:34','49.231.4.10'),(329,'00011144',15,'2021-12-14 16:46:18','182.232.66.113'),(330,'00004135',57,'2021-12-14 16:47:24','49.231.4.10'),(331,'00004686',96,'2021-12-14 17:18:13','182.232.65.3'),(332,'00005088',71,'2021-12-14 17:55:21','1.47.158.211'),(333,'00010722',68,'2021-12-14 18:20:51','182.232.68.128'),(334,'00002489',98,'2021-12-14 19:10:39','171.96.156.37'),(335,'00010844',58,'2021-12-14 19:35:17','1.46.147.120'),(336,'00003626',47,'2021-12-14 20:50:23','49.230.119.186'),(337,'00011144',15,'2021-12-14 20:59:18','182.232.77.203'),(338,'00011156',81,'2021-12-14 21:20:59','124.122.63.78'),(339,'00009955',73,'2021-12-14 21:43:34','49.230.119.126'),(340,'00010407',104,'2021-12-14 22:37:15','1.46.14.130'),(341,'00010407',104,'2021-12-14 22:39:07','1.46.14.130'),(342,'00011156',81,'2021-12-14 23:57:19','124.122.63.78'),(343,'00011144',15,'2021-12-15 00:10:26','182.232.74.111'),(344,'00002489',98,'2021-12-15 00:21:35','171.96.156.37'),(345,'00003287',91,'2021-12-15 06:09:55','1.46.156.60'),(346,'00010407',104,'2021-12-15 07:01:41','1.46.14.130'),(347,'00010872',39,'2021-12-15 08:14:22','1.47.133.12'),(348,'00000152',80,'2021-12-15 08:23:12','182.232.72.22'),(349,'00004120',97,'2021-12-15 08:44:19','49.231.4.10'),(350,'00004998',102,'2021-12-15 08:45:17','223.24.168.97'),(351,'00010407',106,'2021-12-15 08:53:42','49.231.4.10'),(352,'00011014',29,'2021-12-15 09:00:06','49.230.116.104'),(353,'00004378',108,'2021-12-15 09:02:49','1.46.153.114'),(354,'00005060',107,'2021-12-15 09:03:25','182.232.74.107'),(355,'00009671',109,'2021-12-15 09:07:01','182.232.67.224'),(356,'00010407',106,'2021-12-15 09:07:43','49.231.4.10'),(357,'00005157',110,'2021-12-15 09:09:23','182.232.82.147'),(358,'00011156',81,'2021-12-15 09:10:46','1.46.158.138'),(359,'00010833',111,'2021-12-15 09:15:10','49.237.13.153'),(360,'00010407',106,'2021-12-15 09:19:13','49.231.4.10'),(361,'00005013',103,'2021-12-15 09:20:32','27.55.74.68'),(362,'00010833',111,'2021-12-15 10:24:41','49.237.13.153'),(363,'00002221',113,'2021-12-15 11:34:00','49.229.128.51'),(364,'00003459',114,'2021-12-15 11:34:05','49.229.128.29'),(365,'00002221',113,'2021-12-15 11:34:55','49.229.128.51'),(366,'00004928',115,'2021-12-15 11:37:28','223.24.186.28'),(367,'00002221',113,'2021-12-15 11:39:55','49.229.128.51'),(368,'00003459',114,'2021-12-15 11:43:12','49.229.128.29'),(369,'00004491',2,'2021-12-15 12:18:27','49.230.116.103'),(370,'00004491',2,'2021-12-15 12:18:58','49.230.116.103'),(371,'00005060',5,'2021-12-15 13:12:19','182.232.74.61'),(372,'00004378',6,'2021-12-15 13:13:14','1.47.14.243'),(373,'00004378',6,'2021-12-23 12:33:51','1.47.4.164'),(374,'00004378',6,'2022-01-05 13:43:49','1.47.12.71'),(375,'00004491',11,'2022-01-14 09:46:48','182.232.75.91'),(376,'00004491',11,'2022-01-14 09:47:11','182.232.75.91'),(377,'00004491',21,'2022-01-24 14:45:36','14.207.178.148'),(378,'00004491',21,'2022-01-24 14:46:48','14.207.178.148'),(379,'00004491',21,'2022-01-31 12:51:52','49.228.9.29'),(380,'etnmode4',41,'2022-02-24 14:53:05','183.89.187.91'),(381,'etnmode4',41,'2022-02-24 15:17:47','183.89.187.91'),(382,'etnmode4',42,'2022-02-24 16:13:27','183.89.187.91'),(383,'00004491',21,'2022-02-25 08:29:56','49.230.121.146'),(384,'etnmode4',42,'2022-02-25 12:10:33','1.47.29.114'),(385,'00005060',5,'2022-02-25 16:27:13','182.232.85.102'),(386,'etnmode4',42,'2022-02-28 14:21:48','183.89.187.91'),(387,'etnmode4',44,'2022-02-28 15:14:56','183.89.187.91'),(388,'etnmode4',44,'2022-02-28 16:04:36','183.89.187.91'),(389,'etnmode4',44,'2022-02-28 16:05:31','183.89.187.91'),(390,'etnmode4',44,'2022-02-28 16:56:02','183.89.187.91'),(391,'etnmode4',44,'2022-02-28 17:18:50','183.89.187.91'),(392,'etnmode4',44,'2022-03-01 17:51:37','183.89.187.91'),(393,'etnmode4',44,'2022-03-01 17:55:07','183.89.187.91'),(394,'00004491',21,'2022-03-08 16:53:02','182.232.77.172'),(395,'00004491',49,'2022-03-08 17:06:46','182.232.77.172'),(396,'00004491',49,'2022-03-08 17:08:06','182.232.77.172'),(397,'00004491',49,'2022-03-08 17:08:35','182.232.77.172'),(398,'00004491',49,'2022-03-08 17:09:24','182.232.77.172'),(399,'00004491',49,'2022-03-08 17:09:50','182.232.77.172'),(400,'00004491',49,'2022-03-08 17:10:07','182.232.77.172'),(401,'00004491',49,'2022-03-08 17:10:43','182.232.77.172'),(402,'00004491',50,'2022-03-08 17:17:36','182.232.77.172'),(403,'00004491',50,'2022-03-08 17:19:15','182.232.77.172'),(404,'00004491',51,'2022-03-14 11:03:04','49.230.180.137'),(405,'00004491',51,'2022-03-14 11:24:24','49.230.180.137'),(406,'00004491',51,'2022-03-14 11:27:21','49.230.180.137'),(407,'00004491',51,'2022-03-14 11:43:19','49.230.180.137'),(408,'00004491',52,'2022-03-15 09:43:23','182.232.70.142'),(409,'00004491',53,'2022-03-18 14:22:10','49.230.122.71'),(410,'00004491',53,'2022-03-18 14:35:40','49.230.122.71'),(411,'00004491',53,'2022-03-18 14:40:22','49.230.122.71'),(412,'00004491',53,'2022-03-18 15:09:24','49.230.122.71'),(413,'00004491',53,'2022-03-21 10:11:42','182.232.64.105'),(414,'00004491',53,'2022-03-21 16:28:28','182.232.64.105'),(415,'00004491',53,'2022-03-22 14:23:41','182.232.84.181'),(416,'etnmode1',55,'2022-04-06 22:22:38','37.228.245.116'),(417,'00004491',53,'2022-04-19 13:58:44','182.232.72.182'),(418,'00004491',53,'2022-05-06 08:21:33','182.232.79.85'),(419,'00005367',59,'2022-05-17 12:17:01','223.24.144.142'),(420,'00003171',60,'2022-05-17 12:32:05','1.46.151.25'),(421,'00002232',61,'2022-05-17 12:32:31','49.230.121.104'),(422,'00002949',62,'2022-05-17 12:32:53','49.230.177.222'),(423,'00003089',63,'2022-05-17 12:34:35','49.230.122.9'),(424,'00003089',63,'2022-05-17 12:39:04','49.230.122.9'),(425,'00002799',64,'2022-05-17 12:44:55','183.89.81.126'),(426,'00003089',63,'2022-05-17 12:45:04','49.230.122.9'),(427,'00000873',65,'2022-05-17 13:03:24','182.232.178.250'),(428,'00000873',65,'2022-05-17 13:06:34','182.232.178.250'),(429,'00002539',66,'2022-05-17 13:15:19','182.232.80.107'),(430,'00004408',67,'2022-05-17 13:17:35','182.232.83.173'),(431,'00003076',68,'2022-05-17 13:31:50','182.232.2.104'),(432,'00003076',68,'2022-05-17 14:09:43','182.232.2.104'),(433,'00002799',64,'2022-05-17 14:24:13','183.89.81.126'),(434,'00002799',64,'2022-05-17 14:33:24','183.89.81.126'),(435,'00004408',67,'2022-05-17 14:46:44','124.122.16.170'),(436,'00005367',59,'2022-05-17 15:50:25','223.24.150.180'),(437,'00003171',60,'2022-05-18 04:03:13','171.96.157.206'),(438,'00002799',64,'2022-05-18 14:17:53','183.89.82.186'),(439,'00004408',67,'2022-05-18 15:03:35','124.122.16.170'),(440,'00005367',59,'2022-05-19 11:07:12','223.24.153.239'),(441,'00005367',59,'2022-05-19 13:06:13','223.24.153.239'),(442,'00004408',67,'2022-05-19 14:35:52','27.145.208.60'),(443,'00003089',63,'2022-05-19 15:31:26','49.229.129.254'),(444,'00005367',59,'2022-05-19 16:02:36','223.24.153.244'),(445,'00002799',64,'2022-05-20 11:56:22','183.89.82.186'),(446,'00002799',64,'2022-05-21 08:11:05','171.5.143.254'),(447,'00000873',65,'2022-05-22 17:51:24','49.230.116.209'),(448,'00000873',65,'2022-05-23 06:34:21','49.230.116.5'),(449,'00002799',64,'2022-05-23 12:11:35','183.89.82.186'),(450,'00002539',66,'2022-05-23 12:25:17','49.230.118.137'),(451,'00003823',69,'2022-05-23 12:47:11','111.84.138.1'),(452,'00003171',60,'2022-05-23 12:56:43','1.47.153.149'),(453,'00003823',69,'2022-05-23 12:57:07','111.84.138.1'),(454,'00003823',69,'2022-05-23 12:59:31','111.84.138.1'),(455,'00002539',66,'2022-05-23 13:02:58','49.230.118.137'),(456,'00005367',59,'2022-05-24 14:28:08','223.24.92.61'),(457,'00005357',70,'2022-05-24 14:59:02','49.237.8.203'),(458,'00004356',71,'2022-05-24 15:00:04','183.89.82.186'),(459,'00004356',71,'2022-05-24 15:00:50','183.89.82.186'),(460,'00005367',59,'2022-05-25 14:02:40','223.24.166.94'),(461,'00005367',59,'2022-05-25 14:35:47','223.24.166.94'),(462,'00005367',59,'2022-05-25 21:20:22','27.55.92.33'),(463,'00005367',59,'2022-05-26 08:39:10','27.55.83.55'),(464,'00000873',65,'2022-05-26 09:38:03','182.232.83.151'),(465,'00004408',67,'2022-05-26 13:00:04','182.232.87.24'),(466,'00000873',65,'2022-05-26 17:26:11','182.232.86.46'),(467,'00003823',69,'2022-05-28 13:06:59','171.96.158.93'),(468,'00004491',73,'2022-05-30 14:46:49','49.230.4.255'),(469,'00004491',73,'2022-05-30 14:47:02','49.230.4.255'),(470,'00004356',71,'2022-05-30 21:24:16','223.205.238.199'),(471,'00004408',67,'2022-06-01 08:37:38','182.232.87.159'),(472,'00000873',65,'2022-06-01 08:58:02','182.232.82.245'),(473,'00000873',65,'2022-06-04 11:26:45','49.230.122.15'),(474,'00003823',69,'2022-06-04 20:49:25','49.228.37.118'),(475,'etnmode1',75,'2022-06-06 10:41:49','180.183.155.90'),(476,'etnmode1',76,'2022-06-06 10:59:41','180.183.155.90'),(477,'00003089',63,'2022-06-06 18:48:49','49.228.49.196'),(478,'etnmode1',78,'2022-06-06 22:14:52','198.27.180.116'),(479,'etnmode1',80,'2022-06-07 16:02:59','42.3.86.12'),(480,'etnmode1',81,'2022-06-07 16:04:17','42.3.86.12'),(481,'00004378',6,'2022-06-08 13:49:05','1.46.21.3'),(482,'00004491',73,'2022-06-08 13:50:25','49.230.176.30'),(483,'00004378',6,'2022-06-08 14:12:32','1.46.21.3'),(484,'00004491',73,'2022-06-08 15:23:24','49.230.176.30'),(485,'00004408',67,'2022-06-09 06:57:56','171.98.69.194'),(486,'00003171',60,'2022-06-09 10:40:38','1.46.144.31'),(487,'00004491',73,'2022-06-09 14:22:11','49.230.117.195'),(488,'00004491',83,'2022-06-10 08:38:36','49.230.119.144'),(489,'00005367',59,'2022-06-10 08:40:25','223.24.190.138'),(490,'00000873',65,'2022-06-10 14:57:43','49.230.122.78'),(491,'00003823',69,'2022-06-11 14:05:36','171.98.70.125'),(492,'00005357',70,'2022-06-11 20:27:00','27.55.78.228'),(493,'00002799',64,'2022-06-13 04:34:06','223.204.16.195'),(494,'00003076',84,'2022-06-13 14:03:08','49.229.217.148'),(495,'00003076',84,'2022-06-13 14:05:15','49.229.217.148'),(496,'00003823',69,'2022-06-13 21:13:58','111.84.138.1'),(497,'00003171',60,'2022-06-14 06:16:56','171.98.72.150'),(498,'00004408',67,'2022-06-15 06:24:01','27.145.208.247'),(499,'00000873',65,'2022-06-16 10:00:17','49.230.123.101'),(500,'00003171',60,'2022-06-16 16:03:44','1.46.145.49'),(501,'00000873',65,'2022-06-16 19:47:52','49.230.123.66'),(502,'00002799',64,'2022-06-17 12:43:02','14.207.177.48'),(503,'00002539',66,'2022-06-17 12:44:27','49.230.179.136'),(504,'00003823',69,'2022-06-22 16:27:06','27.145.136.207'),(505,'00003823',69,'2022-06-23 16:04:04','111.84.138.3'),(506,'00004408',67,'2022-06-23 16:10:41','182.232.80.188'),(507,'00003823',69,'2022-06-23 22:51:42','27.145.136.207'),(508,'00004408',67,'2022-06-25 11:45:36','182.232.79.209'),(509,'00005367',59,'2022-06-27 11:24:05','27.55.64.166'),(510,'00002232',61,'2022-06-27 11:49:58','49.230.221.77'),(511,'00000873',65,'2022-06-28 08:29:46','49.230.122.53'),(512,'00004408',67,'2022-06-30 02:05:06','115.84.72.155'),(513,'00003171',60,'2022-06-30 09:04:53','1.46.159.132'),(514,'00004408',67,'2022-07-01 02:40:29','171.96.158.175'),(515,'00004408',67,'2022-07-01 02:54:52','171.96.158.175'),(516,'00005367',59,'2022-07-01 05:59:33','223.24.166.154'),(517,'00005367',59,'2022-07-01 08:22:57','223.24.166.154'),(518,'00003823',69,'2022-07-01 14:30:09','111.84.138.1'),(519,'00004356',71,'2022-07-01 21:34:03','171.96.158.123'),(520,'00004408',67,'2022-07-01 22:43:59','171.96.157.153'),(521,'00003171',60,'2022-07-02 20:08:50','1.47.25.157'),(522,'00004356',71,'2022-07-03 19:34:06','171.96.157.106'),(523,'00003089',63,'2022-07-04 14:00:01','49.229.144.83'),(524,'00005367',59,'2022-07-04 14:03:39','223.24.169.23'),(525,'00005367',59,'2022-07-04 14:14:55','223.24.169.23'),(526,'00005367',59,'2022-07-04 14:17:41','223.24.169.23'),(527,'00002539',66,'2022-07-04 20:07:19','171.5.141.216'),(528,'00003171',60,'2022-07-04 20:13:29','1.46.13.77'),(529,'00005367',59,'2022-07-07 15:28:49','27.55.73.106'),(530,'00000873',65,'2022-07-09 10:40:15','182.232.86.110'),(531,'00004408',67,'2022-07-10 00:54:43','124.122.15.142'),(532,'00002949',62,'2022-07-15 17:29:05','223.205.242.34'),(533,'00002949',62,'2022-07-15 21:31:40','223.205.242.34'),(534,'00004408',67,'2022-07-15 23:31:36','124.122.16.204'),(535,'00004356',71,'2022-07-17 20:03:53','171.96.158.103');
/*!40000 ALTER TABLE `loguseapplication` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logwithdrawtransbankerror`
--

DROP TABLE IF EXISTS `logwithdrawtransbankerror`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logwithdrawtransbankerror` (
  `id_withdrawtransbankerr` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_no` char(8) NOT NULL,
  `id_userlogin` mediumint(8) NOT NULL,
  `transaction_date` datetime NOT NULL,
  `amt_transfer` decimal(15,2) NOT NULL,
  `penalty_amt` decimal(15,2) DEFAULT 0.00,
  `fee_amt` decimal(15,2) DEFAULT 0.00,
  `deptaccount_no` varchar(15) NOT NULL,
  `response_code` char(6) DEFAULT NULL,
  `response_message` longtext DEFAULT NULL,
  PRIMARY KEY (`id_withdrawtransbankerr`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logwithdrawtransbankerror`
--

LOCK TABLES `logwithdrawtransbankerror` WRITE;
/*!40000 ALTER TABLE `logwithdrawtransbankerror` DISABLE KEYS */;
INSERT INTO `logwithdrawtransbankerror` VALUES (1,'00004491',3,'2021-12-08 22:08:26',100.00,0.00,0.00,'0000015551','CD0032','Bad Request'),(2,'00005367',59,'2022-05-19 11:08:00',88.00,0.00,7.00,'0000016937','WS0037','ชำระค่าธรรมเนียมไม่สำเร็จ / Insert DPDEPTSLIP ค่าปรับ ไม่ได้INSERT INTO DPDEPTSLIP(DEPTSLIP_NO,COOP_ID,DEPTACCOUNT_NO,DEPTTYPE_CODE,   \r\n														deptcoop_id,DEPTGROUP_CODE,MEMBCAT_CODE,DEPTSLIP_DATE,RECPPAYTYPE_CODE,DEPTSLIP_AMT,CASH_TYPE,\r\n														PRNCBAL,WITHDRAWABLE_AMT,CHECKPEND_AMT,ENTRY_ID,ENTRY_DATE, \r\n														DPSTM_NO,DEPTITEMTYPE_CODE,CALINT_FROM,CALINT_TO,ITEM_STATUS,\r\n														NOBOOK_FLAG,CHEQUE_SEND_FLAG,TOFROM_ACCID,PAYFEE_METH,REFER_SLIPNO,DUE_FLAG,DEPTAMT_OTHER,DEPTSLIP_NETAMT,REFER_APP,\r\n														POSTTOVC_FLAG,TAX_AMT,INT_BFYEAR,ACCID_FLAG,GENVC_FLAG,PEROID_DEPT,CHECKCLEAR_STATUS,   \r\n														TELLER_FLAG,OPERATE_TIME) \r\n														VALUES(?,?,?,?,?,?,?,CONVERT(VARCHAR(10),GETDATE(),20),?,\r\n														?,?,?,?,?,\'MOBILE\',CONVERT(VARCHAR(10),?,20),?,?,CONVERT(VARCHAR(10),?,20),CONVERT(VARCHAR(10),GETDATE(),20),\r\n														1,0,0,?,2,?,0,0,?,\'DEP\',0,0,0,1,1,0,1,1,\r\n														CONVERT(VARCHAR(19),?,20))\n[\"0000000000001\",\"073001\",\"0000016937\",\"00\",\"073001\",\"00\",\"10\",\"FEE\",7,\"TRN\",1830.14,1830.14,\".00\",\"2022-05-19 11:08:00\",14,\"FEE\",\"2022-03-31 00:00:00\",\"42080000\",\"DEP6500185773\",7,\"2022-05-19 11:08:00\"]'),(3,'00005367',59,'2022-05-19 13:06:30',88.00,0.00,7.00,'0000016937','WS0037','ชำระค่าธรรมเนียมไม่สำเร็จ / Insert DPDEPTSLIP ค่าปรับ ไม่ได้INSERT INTO DPDEPTSLIP(DEPTSLIP_NO,COOP_ID,DEPTACCOUNT_NO,DEPTTYPE_CODE,   \r\n														deptcoop_id,DEPTGROUP_CODE,MEMBCAT_CODE,DEPTSLIP_DATE,RECPPAYTYPE_CODE,DEPTSLIP_AMT,CASH_TYPE,\r\n														PRNCBAL,WITHDRAWABLE_AMT,CHECKPEND_AMT,ENTRY_ID,ENTRY_DATE, \r\n														DPSTM_NO,DEPTITEMTYPE_CODE,CALINT_FROM,CALINT_TO,ITEM_STATUS,\r\n														NOBOOK_FLAG,CHEQUE_SEND_FLAG,TOFROM_ACCID,PAYFEE_METH,REFER_SLIPNO,DUE_FLAG,DEPTAMT_OTHER,DEPTSLIP_NETAMT,REFER_APP,\r\n														POSTTOVC_FLAG,TAX_AMT,INT_BFYEAR,ACCID_FLAG,GENVC_FLAG,PEROID_DEPT,CHECKCLEAR_STATUS,   \r\n														TELLER_FLAG,OPERATE_TIME) \r\n														VALUES(?,?,?,?,?,?,?,CONVERT(VARCHAR(10),GETDATE(),20),?,\r\n														?,?,?,?,?,\'MOBILE\',CONVERT(VARCHAR(10),?,20),?,?,CONVERT(VARCHAR(10),?,20),CONVERT(VARCHAR(10),GETDATE(),20),\r\n														1,0,0,?,2,?,0,0,?,\'DEP\',0,0,0,1,1,0,1,1,\r\n														CONVERT(VARCHAR(19),?,20))\n[\"0000000000001\",\"073001\",\"0000016937\",\"00\",\"073001\",\"00\",\"10\",\"FEE\",7,\"TRN\",1830.14,1830.14,\".00\",\"2022-05-19 13:06:30\",14,\"FEE\",\"2022-03-31 00:00:00\",\"42080000\",\"DEP6500185792\",7,\"2022-05-19 13:06:30\"]'),(4,'00003171',60,'2022-05-23 12:57:24',367.00,0.00,7.00,'0000005977','WS0037','ชำระค่าธรรมเนียมไม่สำเร็จ / Insert DPDEPTSLIP ค่าปรับ ไม่ได้INSERT INTO DPDEPTSLIP(DEPTSLIP_NO,COOP_ID,DEPTACCOUNT_NO,DEPTTYPE_CODE,   \r\n														deptcoop_id,DEPTGROUP_CODE,MEMBCAT_CODE,DEPTSLIP_DATE,RECPPAYTYPE_CODE,DEPTSLIP_AMT,CASH_TYPE,\r\n														PRNCBAL,WITHDRAWABLE_AMT,CHECKPEND_AMT,ENTRY_ID,ENTRY_DATE, \r\n														DPSTM_NO,DEPTITEMTYPE_CODE,CALINT_FROM,CALINT_TO,ITEM_STATUS,\r\n														NOBOOK_FLAG,CHEQUE_SEND_FLAG,TOFROM_ACCID,PAYFEE_METH,REFER_SLIPNO,DUE_FLAG,DEPTAMT_OTHER,DEPTSLIP_NETAMT,REFER_APP,\r\n														POSTTOVC_FLAG,TAX_AMT,INT_BFYEAR,ACCID_FLAG,GENVC_FLAG,PEROID_DEPT,CHECKCLEAR_STATUS,   \r\n														TELLER_FLAG,OPERATE_TIME) \r\n														VALUES(?,?,?,?,?,?,?,CONVERT(VARCHAR(10),GETDATE(),20),?,\r\n														?,?,?,?,?,\'MOBILE\',CONVERT(VARCHAR(10),?,20),?,?,CONVERT(VARCHAR(10),?,20),CONVERT(VARCHAR(10),GETDATE(),20),\r\n														1,0,0,?,2,?,0,0,?,\'DEP\',0,0,0,1,1,0,1,1,\r\n														CONVERT(VARCHAR(19),?,20))\n[\"0000000000001\",\"073001\",\"0000005977\",\"00\",\"073001\",\"00\",\"10\",\"FEE\",7,\"TRN\",209.48000000000002,209.48000000000002,\".00\",\"2022-05-23 12:57:24\",283,\"FEE\",\"2022-04-11 00:00:00\",\"42080000\",\"DEP6500186016\",7,\"2022-05-23 12:57:24\"]'),(5,'00003171',60,'2022-05-23 12:58:10',300.00,0.00,7.00,'0000005977','WS0037','ชำระค่าธรรมเนียมไม่สำเร็จ / Insert DPDEPTSLIP ค่าปรับ ไม่ได้INSERT INTO DPDEPTSLIP(DEPTSLIP_NO,COOP_ID,DEPTACCOUNT_NO,DEPTTYPE_CODE,   \r\n														deptcoop_id,DEPTGROUP_CODE,MEMBCAT_CODE,DEPTSLIP_DATE,RECPPAYTYPE_CODE,DEPTSLIP_AMT,CASH_TYPE,\r\n														PRNCBAL,WITHDRAWABLE_AMT,CHECKPEND_AMT,ENTRY_ID,ENTRY_DATE, \r\n														DPSTM_NO,DEPTITEMTYPE_CODE,CALINT_FROM,CALINT_TO,ITEM_STATUS,\r\n														NOBOOK_FLAG,CHEQUE_SEND_FLAG,TOFROM_ACCID,PAYFEE_METH,REFER_SLIPNO,DUE_FLAG,DEPTAMT_OTHER,DEPTSLIP_NETAMT,REFER_APP,\r\n														POSTTOVC_FLAG,TAX_AMT,INT_BFYEAR,ACCID_FLAG,GENVC_FLAG,PEROID_DEPT,CHECKCLEAR_STATUS,   \r\n														TELLER_FLAG,OPERATE_TIME) \r\n														VALUES(?,?,?,?,?,?,?,CONVERT(VARCHAR(10),GETDATE(),20),?,\r\n														?,?,?,?,?,\'MOBILE\',CONVERT(VARCHAR(10),?,20),?,?,CONVERT(VARCHAR(10),?,20),CONVERT(VARCHAR(10),GETDATE(),20),\r\n														1,0,0,?,2,?,0,0,?,\'DEP\',0,0,0,1,1,0,1,1,\r\n														CONVERT(VARCHAR(19),?,20))\n[\"0000000000001\",\"073001\",\"0000005977\",\"00\",\"073001\",\"00\",\"10\",\"FEE\",7,\"TRN\",276.48,276.48,\".00\",\"2022-05-23 12:58:10\",283,\"FEE\",\"2022-04-11 00:00:00\",\"42080000\",\"DEP6500186018\",7,\"2022-05-23 12:58:10\"]'),(6,'00005367',59,'2022-05-24 14:28:28',100.00,0.00,7.00,'0000016937','WS0037','ชำระค่าธรรมเนียมไม่สำเร็จ / Insert DPDEPTSLIP ค่าปรับ ไม่ได้INSERT INTO DPDEPTSLIP(DEPTSLIP_NO,COOP_ID,DEPTACCOUNT_NO,DEPTTYPE_CODE,   \r\n														deptcoop_id,DEPTGROUP_CODE,MEMBCAT_CODE,DEPTSLIP_DATE,RECPPAYTYPE_CODE,DEPTSLIP_AMT,CASH_TYPE,\r\n														PRNCBAL,WITHDRAWABLE_AMT,CHECKPEND_AMT,ENTRY_ID,ENTRY_DATE, \r\n														DPSTM_NO,DEPTITEMTYPE_CODE,CALINT_FROM,CALINT_TO,ITEM_STATUS,OTHER_AMT,\r\n														NOBOOK_FLAG,CHEQUE_SEND_FLAG,TOFROM_ACCID,PAYFEE_METH,REFER_SLIPNO,DUE_FLAG,DEPTAMT_OTHER,DEPTSLIP_NETAMT,REFER_APP,\r\n														POSTTOVC_FLAG,TAX_AMT,INT_BFYEAR,ACCID_FLAG,GENVC_FLAG,PEROID_DEPT,CHECKCLEAR_STATUS,   \r\n														TELLER_FLAG,OPERATE_TIME) \r\n														VALUES(?,?,?,?,?,?,?,CONVERT(VARCHAR(10),GETDATE(),20),?,\r\n														?,?,?,?,?,\'MOBILE\',CONVERT(VARCHAR(10),?,20),?,?,CONVERT(VARCHAR(10),?,20),CONVERT(VARCHAR(10),GETDATE(),20),\r\n														1,?,0,0,?,2,?,0,0,?,\'DEP\',0,0,0,1,1,0,1,1,\r\n														CONVERT(VARCHAR(19),?,20))\r\n[false,\"073001\",\"0000016937\",\"00\",\"073001\",\"00\",\"10\",\"FEM\",7,\"CBT\",1906.14,1906.14,\".00\",\"2022-05-24 14:28:28\",15,\"FEM\",\"2022-03-31 00:00:00\",7,\"42080000\",\"TNX6400000002\",7,\"2022-05-24 14:28:28\"]'),(7,'00005367',59,'2022-05-25 14:04:35',50.00,0.00,7.00,'0000016937','WS0037','Citizen Id Not Match With Payee Account');
/*!40000 ALTER TABLE `logwithdrawtransbankerror` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsconstantdept`
--

DROP TABLE IF EXISTS `smsconstantdept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smsconstantdept` (
  `id_smsconstantdept` smallint(5) NOT NULL AUTO_INCREMENT,
  `dept_itemtype_code` char(3) NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `allow_smsconstantdept` enum('0','1','-9') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_smsconstantdept`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsconstantdept`
--

LOCK TABLES `smsconstantdept` WRITE;
/*!40000 ALTER TABLE `smsconstantdept` DISABLE KEYS */;
/*!40000 ALTER TABLE `smsconstantdept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsconstantloan`
--

DROP TABLE IF EXISTS `smsconstantloan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smsconstantloan` (
  `id_smsconstantloan` smallint(5) NOT NULL AUTO_INCREMENT,
  `loan_itemtype_code` char(3) NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `allow_smsconstantloan` enum('0','1','-9') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_smsconstantloan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsconstantloan`
--

LOCK TABLES `smsconstantloan` WRITE;
/*!40000 ALTER TABLE `smsconstantloan` DISABLE KEYS */;
/*!40000 ALTER TABLE `smsconstantloan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsconstantperson`
--

DROP TABLE IF EXISTS `smsconstantperson`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smsconstantperson` (
  `id_smscsperson` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `smscsp_account` varchar(20) NOT NULL,
  `smscsp_member_no` char(8) NOT NULL,
  `smscsp_mindeposit` varchar(20) NOT NULL DEFAULT '0',
  `smscsp_minwithdraw` varchar(20) NOT NULL DEFAULT '0',
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_use` enum('0','1') NOT NULL DEFAULT '1',
  `is_mindeposit` enum('0','1') NOT NULL DEFAULT '1',
  `is_minwithdraw` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_smscsperson`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsconstantperson`
--

LOCK TABLES `smsconstantperson` WRITE;
/*!40000 ALTER TABLE `smsconstantperson` DISABLE KEYS */;
/*!40000 ALTER TABLE `smsconstantperson` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsconstantshare`
--

DROP TABLE IF EXISTS `smsconstantshare`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smsconstantshare` (
  `id_smsconstantshare` smallint(5) NOT NULL AUTO_INCREMENT,
  `share_itemtype_code` char(3) NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `allow_smsconstantshare` enum('0','1','-9') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_smsconstantshare`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsconstantshare`
--

LOCK TABLES `smsconstantshare` WRITE;
/*!40000 ALTER TABLE `smsconstantshare` DISABLE KEYS */;
/*!40000 ALTER TABLE `smsconstantshare` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsconstantsystem`
--

DROP TABLE IF EXISTS `smsconstantsystem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smsconstantsystem` (
  `id_smscssystem` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `smscs_name` varchar(50) NOT NULL,
  `smscs_desc` varchar(200) NOT NULL,
  `smscs_value` varchar(20) NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_use` enum('0','1','-9') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_smscssystem`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsconstantsystem`
--

LOCK TABLES `smsconstantsystem` WRITE;
/*!40000 ALTER TABLE `smsconstantsystem` DISABLE KEYS */;
INSERT INTO `smsconstantsystem` VALUES (1,'limit_dept_send_free','จำนวนที่จะส่ง SMS ฟรีเมื่อมีการทำรายการฝากเงินฝาก (บาท)','4000','2019-12-11 13:50:07','2020-01-14 11:10:00','1'),(2,'limit_period_idle','จำนวนวันที่รายการเคลื่อนไหวบัญชีไม่ขยับจะส่ง SMS ฟรี (วัน)','180','2019-12-11 13:50:07','2019-12-11 16:45:54','1'),(3,'limit_withdraw_send_free','จำนวนที่จะส่ง SMS ฟรีเมื่อมีการทำรายการถอนเงินฝาก (บาท)','4000','2020-01-14 11:10:21','2020-01-14 11:10:21','1'),(4,'sms_fee_amt_per_trans','ค่าบริการ SMS ต่อ/ข้อความ (บาท)','0.50','2020-06-13 11:28:54','2020-06-24 23:36:15','1');
/*!40000 ALTER TABLE `smsconstantsystem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsgroupmember`
--

DROP TABLE IF EXISTS `smsgroupmember`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smsgroupmember` (
  `id_groupmember` mediumint(8) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `group_member` longtext NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_use` enum('0','1','-9') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_groupmember`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsgroupmember`
--

LOCK TABLES `smsgroupmember` WRITE;
/*!40000 ALTER TABLE `smsgroupmember` DISABLE KEYS */;
/*!40000 ALTER TABLE `smsgroupmember` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smslogwassent`
--

DROP TABLE IF EXISTS `smslogwassent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smslogwassent` (
  `id_logsent` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sms_message` text NOT NULL,
  `member_no` char(8) DEFAULT NULL,
  `tel_mobile` char(10) NOT NULL,
  `send_date` datetime NOT NULL DEFAULT current_timestamp(),
  `send_by` varchar(20) NOT NULL,
  `id_smstemplate` smallint(5) unsigned DEFAULT NULL,
  `is_sendahead` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_logsent`),
  KEY `FK_SEND_SMS_BY_USER` (`send_by`),
  KEY `FK_LOG_SENT_SMS_FROM_TEMPLATE` (`id_smstemplate`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smslogwassent`
--

LOCK TABLES `smslogwassent` WRITE;
/*!40000 ALTER TABLE `smslogwassent` DISABLE KEYS */;
INSERT INTO `smslogwassent` VALUES (1,' OTP : 387039 (Ref. : CMyinw) หมดอายุเมื่อ : 08 มี.ค. 2565 17:10:41 น.','00004491','0634561953','2022-03-08 17:05:42','system',NULL,'0'),(2,' OTP : 816995 (Ref. : ETU104) หมดอายุเมื่อ : 17 พ.ค. 2565 12:21:40 น.','00005367','0897176694','2022-05-17 12:16:41','system',NULL,'0'),(3,' OTP : 305925 (Ref. : Msep9D) หมดอายุเมื่อ : 17 พ.ค. 2565 12:36:20 น.','00003171','0815933618','2022-05-17 12:31:21','system',NULL,'0'),(4,' OTP : 617165 (Ref. : 99qidV) หมดอายุเมื่อ : 17 พ.ค. 2565 12:36:39 น.','00002232','0898460260','2022-05-17 12:31:40','system',NULL,'0'),(5,' OTP : 341021 (Ref. : sZmhif) หมดอายุเมื่อ : 17 พ.ค. 2565 12:36:45 น.','00002949','0898650747','2022-05-17 12:31:45','system',NULL,'0'),(6,' OTP : 710107 (Ref. : Wr7Kve) หมดอายุเมื่อ : 17 พ.ค. 2565 12:38:36 น.','00003089','0895824224','2022-05-17 12:33:37','system',NULL,'0'),(7,' OTP : 692930 (Ref. : a1P5ZK) หมดอายุเมื่อ : 17 พ.ค. 2565 12:46:13 น.','00002799','0840363699','2022-05-17 12:41:15','system',NULL,'0'),(8,' OTP : 356348 (Ref. : jyf9xM) หมดอายุเมื่อ : 17 พ.ค. 2565 13:06:50 น.','00000873','0899469141','2022-05-17 13:01:51','system',NULL,'0'),(9,' OTP : 100972 (Ref. : r1G0zx) หมดอายุเมื่อ : 17 พ.ค. 2565 13:19:18 น.','00002539','0610284878','2022-05-17 13:14:18','system',NULL,'0'),(10,' OTP : 313035 (Ref. : LGlcPT) หมดอายุเมื่อ : 17 พ.ค. 2565 13:21:56 น.','00004408','0880248888','2022-05-17 13:16:58','system',NULL,'0'),(11,' OTP : 445954 (Ref. : KtEUpb) หมดอายุเมื่อ : 17 พ.ค. 2565 13:35:47 น.','00003076','0898485927','2022-05-17 13:30:48','system',NULL,'0'),(12,' OTP : 068198 (Ref. : X9YPDw) หมดอายุเมื่อ : 23 พ.ค. 2565 12:50:56 น.','00003823','0992645259','2022-05-23 12:45:57','system',NULL,'0'),(13,' OTP : 724560 (Ref. : ixuaDz) หมดอายุเมื่อ : 24 พ.ค. 2565 15:03:49 น.','00005357','0821528248','2022-05-24 14:58:50','system',NULL,'0'),(14,' OTP : 196563 (Ref. : jF66CI) หมดอายุเมื่อ : 24 พ.ค. 2565 15:04:07 น.','00004356','0810729174','2022-05-24 14:59:07','system',NULL,'0');
/*!40000 ALTER TABLE `smslogwassent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsquery`
--

DROP TABLE IF EXISTS `smsquery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smsquery` (
  `id_smsquery` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `sms_query` text DEFAULT NULL,
  `column_selected` text DEFAULT NULL,
  `target_field` varchar(200) DEFAULT NULL,
  `condition_target` varchar(200) DEFAULT NULL,
  `is_stampflag` enum('0','1') NOT NULL DEFAULT '0',
  `stamp_table` varchar(50) DEFAULT NULL,
  `where_stamp` varchar(200) DEFAULT NULL,
  `set_column` varchar(200) DEFAULT NULL,
  `is_bind_param` enum('0','1') NOT NULL DEFAULT '0',
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `create_by` varchar(20) NOT NULL,
  PRIMARY KEY (`id_smsquery`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsquery`
--

LOCK TABLES `smsquery` WRITE;
/*!40000 ALTER TABLE `smsquery` DISABLE KEYS */;
/*!40000 ALTER TABLE `smsquery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smssendahead`
--

DROP TABLE IF EXISTS `smssendahead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smssendahead` (
  `id_sendahead` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `send_topic` varchar(100) NOT NULL,
  `send_message` text DEFAULT NULL,
  `destination` longtext NOT NULL,
  `destination_revoke` longtext DEFAULT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_use` enum('0','1','-9') NOT NULL DEFAULT '1',
  `send_date` datetime NOT NULL,
  `create_by` varchar(20) NOT NULL,
  `is_import` enum('0','1') NOT NULL DEFAULT '0',
  `id_smsquery` smallint(5) unsigned DEFAULT NULL,
  `id_smstemplate` smallint(5) unsigned DEFAULT NULL,
  `send_platform` enum('1','2') NOT NULL DEFAULT '1',
  `send_image` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_sendahead`),
  KEY `FK_QUERY_AHEAD` (`id_smsquery`),
  CONSTRAINT `FK_QUERY_AHEAD` FOREIGN KEY (`id_smsquery`) REFERENCES `smsquery` (`id_smsquery`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smssendahead`
--

LOCK TABLES `smssendahead` WRITE;
/*!40000 ALTER TABLE `smssendahead` DISABLE KEYS */;
/*!40000 ALTER TABLE `smssendahead` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smssystemtemplate`
--

DROP TABLE IF EXISTS `smssystemtemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smssystemtemplate` (
  `id_systemplate` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(100) NOT NULL,
  `body` text NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_use` enum('0','1','-9') NOT NULL DEFAULT '1',
  `seq_no` mediumint(8) unsigned NOT NULL,
  `component_system` varchar(100) NOT NULL,
  PRIMARY KEY (`id_systemplate`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smssystemtemplate`
--

LOCK TABLES `smssystemtemplate` WRITE;
/*!40000 ALTER TABLE `smssystemtemplate` DISABLE KEYS */;
INSERT INTO `smssystemtemplate` VALUES (1,'OTP ยืนยัน',' OTP : ${RANDOM_NUMBER} (Ref. : ${RANDOM_ALL}) หมดอายุเมื่อ : ${DATE_EXPIRE}','2019-12-09 13:07:20','2020-04-30 15:24:53','1',1,'OTPChecker'),(2,'ทำรายการโอนเงินสำเร็จ','ทำรายการโอนเงินจากบัญชี : ${DEPTACCOUNT} เป็นจำนวนเงิน ${AMT_TRANSFER} บาท เมื่อวันที่ ${DATETIME}','2020-01-20 17:25:22','2020-02-14 17:28:40','1',1,'TransferDepInsideCoop'),(3,'ถอนเงินผ่านโมบาย','ถอนเงินบัญชี : ${DEPTACCOUNT} จำนวน : ${AMT_TRANSFER} บาท เมื่อวันที่ ${DATETIME}','2020-02-01 18:11:11','2020-02-14 17:28:06','1',1,'TransactionWithdrawDeposit'),(4,'ทำรายการโอนเงินสำเร็จ','ทำรายการโอนเงินจากบัญชี : ${DEPTACCOUNT} เป็นจำนวนเงิน ${AMT_TRANSFER} บาท เมื่อวันที่ ${DATETIME}','2020-01-20 17:25:22','2020-02-14 17:28:38','1',1,'TransferSelfDepInsideCoop'),(5,'ฝากเงินผ่านโมบาย','ฝากเงินเข้าบัญชี : ${DEPTACCOUNT} จำนวน : ${AMT_TRANSFER} บาท เมื่อวันที่ ${DATETIME}','2020-02-01 18:11:11','2020-02-14 17:28:12','1',1,'TransactionDeposit'),(6,'${ITEMTYPE_DESC}','${ITEMTYPE_DESC} บัญชี ${DEPTACCOUNT_NO} \r\n จำนวน : ${AMOUNT} บาท เมื่อวันที่ ${DATETIME}','2020-02-17 15:19:59','2020-02-17 15:19:59','1',1,'DepositInfo'),(7,'${ITEMTYPE_DESC}','${ITEMTYPE_DESC} ${LOANCONTRACT_NO} จำนวน : ${PRINCIPAL_PAYMENT}/${INTEREST_PAYMENT} คงเหลือ : ${PRINCIPAL_BALANCE} เมื่อวันที่ ${DATETIME}','2020-02-17 16:17:12','2020-02-17 16:17:12','1',1,'LoanInfo'),(8,'ลืมรหัสผ่าน','<!DOCTYPE HTML>\n<html>\n<head>\n  <meta charset=\"UTF-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n  <style>\n	body {\n		margin: 0 auto;\n	}\n	p {\n		margin: 3px;\n	}\n	.body-content {\n		margin: auto;\n		position: relative;\n	}\n	.header-content {\n		width: 100%;\n		height: auto;\n		display: flex;\n		align-items: center;\n		color: #271942;\n        border-bottom: 1px #271942 solid;\n        padding-bottom: 10px;\n	}\n	.footer-content {\n		width: 100%;\n		background: #271942;\n		color: white;\n		font-size: 13px;\n	}\n	.content {\n		font-size: 20px;\n		padding: 20px 10px;\n	}\n  </style>\n</head>\n\n<body>\n<div class=\"body-content\">\n<div class=\"header-content\">\n<img src=\"https://cdn.thaicoop.co/coop/sps.png\" style=\"width:70px;height:70px;margin-left: 10px;\">\n<div style=\"margin-left: 30px;\">\n<div style=\"font-weight:bold;font-size: 16px;\">สหกรณ์ออมทรัพย์โรงพยาบาลสรรพสิทธิประสงค์อุบลราชธานี จำกัด</div>\n<div style=\"font-size: 14px;\">Sunpasittiprasong Hospital Savings And Credit Co-Operative, Limited</div>\n</div>\n</div>\n<div class=\"content\">\n<p style=\"font-weight:bold;font-size: 16px;\">เรียน ${FULL_NAME}</p>\n<div style=\"background:#f3d60e;padding:5px;font-size:14px;\">\n<p>ตามที่ท่านได้ขอรีเซ็ตรหัสผ่าน ท่านจะได้รับรหัสผ่านชั่วคราวเป็นเลข 6 หลักในการใช้เข้าสู่ระบบแทนรหัสผ่านเดิม</p>\n<p>ท่านได้ขอรีเซ็ตรหัสผ่านบน ${DEVICE_NAME} เมื่อวันที่ ${REQUEST_DATE}</p>\n<p>รหัสผ่านชั่วคราว : <p style=\"background: #d86717;color: white;padding:5px;\">${TEMP_PASSWORD}</p<</p>\n</div>\n<p style=\"font-weight:bold;font-size: 16px;margin-top:10px;\">สอบถามข้อมูลเพิ่มเติม : <a href=\"mailto:sps.mobilesupport@gensoft.co.th\">sps.mobilesupport@gensoft.co.th</a></p>\n<p style=\"font-weight:bold;font-size: 14px;\">สหกรณ์ออมทรัพย์โรงพยาบาลสรรพสิทธิประสงค์อุบลราชธานี จำกัด ขอแสดงความนับถือ</p>\n</div>\n<div class=\"footer-content\">\n<div style=\"padding: 0 10px;padding-top: 10px;\">247/1 ถ.สรรพสิทธิ์ ต.ในเมือง อ.เมืองอุบลราชธานี จ.อุบลราชธานี 34000</div>\n<div style=\"padding: 0 10px;\">โทรศัพท์ : 045-255838-9  , 089-7203212</div>\n<div style=\"padding: 0 10px;\">โทรสาร : 045-255838-9 ต่อ 15</div>\n</div>\n</div>\n</body>\n</html>\n\n','2020-03-02 11:37:30','2022-01-31 13:11:35','1',1,'ForgetPassword'),(9,'ค้ำประกัน','ท่านได้ค้ำประกันเงินกู้ประเภท ${LOAN_TYPE} ${LOANCONTRACT_NO} ให้กับ ${FULL_NAME} เป็นจำนวน ${AMOUNT} บาท เมื่อ ${APPROVE_DATE} หากท่านไม่ได้ค้ำประกันกรุณาติดต่อสหกรณ์','2020-04-30 15:24:13','2020-04-30 15:24:13','1',1,'GuaranteeInfo'),(10,'${ITEMTYPE_DESC}','${ITEMTYPE_DESC} : ${AMOUNT} บาท / คงเหลือ ${SHARE_BALANCE} บาท วันที่ ${DATETIME}','2020-04-30 15:24:27','2020-04-30 15:24:27','1',1,'ShareInfo'),(11,'คำขอ e-Statement ของคุณ','<!DOCTYPE HTML>\n<html>\n<head>\n  <meta charset=\"UTF-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n  <style>\n	body {\n		margin: 0 auto;\n	}\n	p {\n		margin: 3px;\n	}\n	.body-content {\n		margin: auto;\n		position: relative;\n	}\n	.header-content {\n		width: 100%;\n		height: auto;\n		display: flex;\n		align-items: center;\n		color: #271942;\n        border-bottom: 1px #271942 solid;\n        padding-bottom: 10px;\n	}\n	.footer-content {\n		width: 100%;\n		background: #271942;\n		color: white;\n		font-size: 13px;\n	}\n	.content {\n		font-size: 20px;\n		padding: 20px 10px;\n	}\n  </style>\n</head>\n\n<body>\n<div class=\"body-content\">\n<div class=\"header-content\">\n<img src=\"https://cdn.thaicoop.co/coop/sps.png\" style=\"width:70px;height:70px;margin-left: 10px;\">\n<div style=\"margin-left: 30px;\">\n<div style=\"font-weight:bold;font-size: 16px;\">สหกรณ์ออมทรัพย์โรงพยาบาลสรรพสิทธิประสงค์อุบลราชธานี จำกัด</div>\n<div style=\"font-size: 14px;\">Sunpasittiprasong Hospital Savings And Credit Co-Operative, Limited</div>\n</div>\n</div>\n<div class=\"content\">\n<p style=\"font-weight:bold;font-size: 16px;\">เรียน สมาชิกที่ทำรายการขอ e-Statement</p>\n<div style=\"background:#f3d60e;padding:5px;font-size:14px;\">\n<p>ตามที่ท่านได้ประสงค์ขอรายการเดินบัญชีเงินฝากของบัญชี ${ACCOUNT_NO} โดยรูปแบบ PDF ท่านสามารถดูรายละเอียดได้ในไฟล์แนบ โดยไฟล์มีการเข้ารหัสไว้เพื่อความปลอดภัยของข้อมูลส่วนตัวของท่านเอง รหัสผ่านจะเป็นเลขบัตรประจำตัวประชาชน 13 หลักของท่าน ตัวอย่าง 1500900111222</p>\n</div>\n<p style=\"font-weight:bold;font-size: 16px;margin-top:10px;\">สอบถามข้อมูลเพิ่มเติม : <a href=\"mailto:sps.mobilesupport@gensoft.co.th\">sps.mobilesupport@gensoft.co.th</a></p>\n<p style=\"font-weight:bold;font-size: 14px;\">สหกรณ์ออมทรัพย์โรงพยาบาลสรรพสิทธิประสงค์อุบลราชธานี จำกัด ขอแสดงความนับถือ</p>\n</div>\n<div class=\"footer-content\">\n<div style=\"padding: 0 10px;padding-top: 10px;\">247/1 ถ.สรรพสิทธิ์ ต.ในเมือง อ.เมืองอุบลราชธานี จ.อุบลราชธานี 34000</div>\n<div style=\"padding: 0 10px;\">โทรศัพท์ : 045-255838-9  , 089-7203212</div>\n<div style=\"padding: 0 10px;\">โทรสาร : 045-255838-9 ต่อ 15</div>\n</div>\n</div>\n</body>\n</html>','2020-04-30 15:24:40','2022-02-01 14:04:45','1',1,'DepositStatement'),(12,'ชำระหนี้สำเร็จ','บัญชี : ${DEPTACCOUNT} มีการชำระหนี้สัญญา ${CONTRACT_NO} จำนวน : ${AMOUNT} บาท ดอกเบี้ย ${INT_PAY} บาท/เงินต้น ${PRIN_PAY} บาท เมื่อ ${OPERATE_DATE}','2020-06-21 13:48:02','2020-06-21 13:48:02','1',1,'TransferDepPayLoan'),(17,'ซื้อหุ้นสำเร็จ','${FULL_NAME} มีการซื้อหุ้นเพิ่มจำนวน ${AMOUNT} บาท เมื่อ ${OPERATE_DATE}','2020-06-21 13:56:45','2020-06-21 13:56:45','1',1,'TransferDepBuyShare'),(18,'เปลี่ยนแปลงรหัสผ่าน','บัญชีของท่านมีการเปลี่ยนรหัสผ่านเข้าใช้งานบนอุปกรณ์ ${DEVICE_NAME} เมื่อวันที่ ${OPERATE_DATE}','2020-06-24 20:55:53','2020-06-24 20:55:53','1',1,'SettingChangePassword'),(19,'คำขอกู้ของท่าน${REQ_STATUS_DESC}','ใบคำขอเลขที่ ${LOANDOC_NO} ${REQ_STATUS_DESC} ท่านสามารถตรวจสอบใบคำขอกู้ได้ที่เมนูตรวจสอบสถานะใบคำขอกู้','2020-10-26 10:03:25','2020-10-26 10:03:25','1',1,'LoanRequestForm'),(20,'ทำรายการรับเงินกู้สำเร็จ','ทำรายการรับเงินกู้สัญญา ${CONTRACT_NO} เข้าบัญชี : ${DEPTACCOUNT} เป็นจำนวนเงิน ${AMT_TRANSFER} บาท เมื่อวันที่ ${DATETIME}','2021-06-30 20:09:53','2021-06-30 20:09:53','1',1,'LoanReceive'),(21,'รับรหัสผ่านชั่วคราวผ่าน SMS','รหัสชั่วคราวคือ ${TEMP_PASSWORD} โปรดเก็บเป็นความลับและเปลี่ยนเมื่อเข้าสู่ระบบ','2022-03-08 16:32:52','2022-03-08 16:32:52','1',1,'ForgetPasswordSMS'),(22,'ฝากเงินธนาคาร','มีการชำระบิลเข้ามา จำนวนเงิน : ${AMT_TRANSFER} บาท เมื่อวันที่ ${OPERATE_DATE}','2022-06-13 14:57:29','2022-06-13 14:57:29','1',1,'Billpayment');
/*!40000 ALTER TABLE `smssystemtemplate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smstemplate`
--

DROP TABLE IF EXISTS `smstemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smstemplate` (
  `id_smstemplate` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `smstemplate_name` varchar(100) NOT NULL,
  `smstemplate_body` text NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_use` enum('0','1','-9') NOT NULL DEFAULT '1',
  `create_by` varchar(20) NOT NULL,
  `id_smsquery` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id_smstemplate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smstemplate`
--

LOCK TABLES `smstemplate` WRITE;
/*!40000 ALTER TABLE `smstemplate` DISABLE KEYS */;
/*!40000 ALTER TABLE `smstemplate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smstopicmatchtemplate`
--

DROP TABLE IF EXISTS `smstopicmatchtemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smstopicmatchtemplate` (
  `id_matching` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id_submenu` mediumint(8) unsigned NOT NULL,
  `id_smstemplate` smallint(5) unsigned NOT NULL,
  `is_use` enum('0','1','-9') NOT NULL DEFAULT '1',
  `matching_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_matching`),
  KEY `FK_MATCH_TEMPLATE` (`id_smstemplate`),
  KEY `FK_SUBMENU_TOPIC` (`id_submenu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smstopicmatchtemplate`
--

LOCK TABLES `smstopicmatchtemplate` WRITE;
/*!40000 ALTER TABLE `smstopicmatchtemplate` DISABLE KEYS */;
/*!40000 ALTER TABLE `smstopicmatchtemplate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smstranwassent`
--

DROP TABLE IF EXISTS `smstranwassent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smstranwassent` (
  `id_smssent` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sms_message` text NOT NULL,
  `member_no` char(8) DEFAULT NULL,
  `tel_mobile` char(10) NOT NULL,
  `payment_keep` enum('0','1') NOT NULL DEFAULT '1',
  `process_flag` enum('0','1') NOT NULL DEFAULT '0',
  `send_date` datetime NOT NULL DEFAULT current_timestamp(),
  `send_by` varchar(20) NOT NULL,
  `id_smstemplate` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id_smssent`),
  KEY `FK_SMS_TEMPLATE_SENT` (`id_smstemplate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smstranwassent`
--

LOCK TABLES `smstranwassent` WRITE;
/*!40000 ALTER TABLE `smstranwassent` DISABLE KEYS */;
/*!40000 ALTER TABLE `smstranwassent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smswasnotsent`
--

DROP TABLE IF EXISTS `smswasnotsent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smswasnotsent` (
  `id_smsnotsent` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `member_no` char(8) DEFAULT NULL,
  `send_platform` enum('sms','mobile_app') NOT NULL DEFAULT 'mobile_app',
  `tel_mobile` char(10) DEFAULT NULL,
  `fcm_token` text DEFAULT NULL,
  `send_date` datetime NOT NULL DEFAULT current_timestamp(),
  `cause_notsent` text DEFAULT NULL,
  `send_by` varchar(20) NOT NULL,
  `id_smstemplate` smallint(5) unsigned DEFAULT NULL,
  `is_sendahead` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_smsnotsent`),
  KEY `FK_NOT_SEND_BY_USER` (`send_by`),
  KEY `FK_SMS_TEMPLATE_SEND` (`id_smstemplate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smswasnotsent`
--

LOCK TABLES `smswasnotsent` WRITE;
/*!40000 ALTER TABLE `smswasnotsent` DISABLE KEYS */;
/*!40000 ALTER TABLE `smswasnotsent` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-18  0:01:12
